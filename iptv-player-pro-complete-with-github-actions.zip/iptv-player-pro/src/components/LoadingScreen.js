import React from 'react';

const LoadingScreen = ({ message = 'Carregando...' }) => {
  return (
    <div className="fixed inset-0 bg-netflix-black flex flex-col items-center justify-center z-50">
      {/* Logo */}
      <div className="mb-8 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-gradient mb-2">
          IPTV Player Pro
        </h1>
        <p className="text-netflix-gray-light text-lg">
          Reprodutor IPTV Profissional
        </p>
      </div>

      {/* Spinner animado */}
      <div className="relative mb-6">
        <div className="w-16 h-16 border-4 border-netflix-gray-dark rounded-full animate-spin">
          <div className="absolute top-0 left-0 w-16 h-16 border-4 border-transparent border-t-netflix-red rounded-full animate-spin"></div>
        </div>
      </div>

      {/* Mensagem de carregamento */}
      <p className="text-netflix-gray-light text-base animate-pulse">
        {message}
      </p>

      {/* Barra de progresso animada */}
      <div className="mt-8 w-64 h-1 bg-netflix-gray-dark rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-netflix-red to-red-400 rounded-full animate-pulse"></div>
      </div>

      {/* Versão */}
      <div className="absolute bottom-8 text-center">
        <p className="text-netflix-gray-light text-sm">
          Versão 1.0.0
        </p>
      </div>
    </div>
  );
};

export default LoadingScreen;

