import React, { useState } from 'react';
import { 
  X, 
  User, 
  Settings, 
  Shield, 
  Monitor, 
  Volume2, 
  Globe, 
  LogOut,
  Save,
  Eye,
  EyeOff
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { clearAuthData } from '../utils/auth';

const SettingsScreen = ({ onClose, onLogout }) => {
  const { settings, updateSettings, user } = useApp();
  const [activeTab, setActiveTab] = useState('general');
  const [localSettings, setLocalSettings] = useState(settings);
  const [parentalPin, setParentalPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const handleSettingChange = (key, value) => {
    setLocalSettings(prev => ({
      ...prev,
      [key]: value
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    updateSettings(localSettings);
    setHasChanges(false);
  };

  const handleLogout = () => {
    clearAuthData();
    onLogout();
  };

  const tabs = [
    { id: 'general', label: 'Geral', icon: Settings },
    { id: 'video', label: 'Vídeo', icon: Monitor },
    { id: 'audio', label: 'Áudio', icon: Volume2 },
    { id: 'parental', label: 'Controle Parental', icon: Shield },
    { id: 'account', label: 'Conta', icon: User }
  ];

  const TabButton = ({ tab, isActive, onClick }) => {
    const Icon = tab.icon;
    return (
      <button
        onClick={() => onClick(tab.id)}
        className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
          isActive 
            ? 'bg-netflix-red text-white' 
            : 'text-netflix-gray-light hover:text-white hover:bg-netflix-gray-dark'
        }`}
      >
        <Icon className="w-5 h-5" />
        <span>{tab.label}</span>
      </button>
    );
  };

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Configurações Gerais</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-netflix-gray-light mb-2">
            Idioma
          </label>
          <select
            value={localSettings.language}
            onChange={(e) => handleSettingChange('language', e.target.value)}
            className="input-netflix w-full max-w-xs"
          >
            <option value="pt-BR">Português (Brasil)</option>
            <option value="en-US">English (US)</option>
            <option value="es-ES">Español</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-netflix-gray-light mb-2">
            Tema
          </label>
          <select
            value={localSettings.theme}
            onChange={(e) => handleSettingChange('theme', e.target.value)}
            className="input-netflix w-full max-w-xs"
          >
            <option value="dark">Escuro</option>
            <option value="light">Claro</option>
            <option value="auto">Automático</option>
          </select>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-white">
              Reprodução Automática
            </label>
            <p className="text-sm text-netflix-gray-light">
              Iniciar reprodução automaticamente ao selecionar conteúdo
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={localSettings.autoplay}
              onChange={(e) => handleSettingChange('autoplay', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-netflix-gray-dark peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-netflix-red"></div>
          </label>
        </div>
      </div>
    </div>
  );

  const renderVideoSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Configurações de Vídeo</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-netflix-gray-light mb-2">
            Qualidade Padrão
          </label>
          <select
            value={localSettings.quality}
            onChange={(e) => handleSettingChange('quality', e.target.value)}
            className="input-netflix w-full max-w-xs"
          >
            <option value="auto">Automática</option>
            <option value="1080p">1080p (Full HD)</option>
            <option value="720p">720p (HD)</option>
            <option value="480p">480p (SD)</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-netflix-gray-light mb-2">
            Modo de Tela
          </label>
          <select
            value={localSettings.screenMode || 'windowed'}
            onChange={(e) => handleSettingChange('screenMode', e.target.value)}
            className="input-netflix w-full max-w-xs"
          >
            <option value="windowed">Janela</option>
            <option value="fullscreen">Tela Cheia</option>
            <option value="borderless">Sem Bordas</option>
          </select>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-white">
              Aceleração de Hardware
            </label>
            <p className="text-sm text-netflix-gray-light">
              Usar GPU para melhor performance de vídeo
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={localSettings.hardwareAcceleration || true}
              onChange={(e) => handleSettingChange('hardwareAcceleration', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-netflix-gray-dark peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-netflix-red"></div>
          </label>
        </div>
      </div>
    </div>
  );

  const renderAudioSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Configurações de Áudio</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-netflix-gray-light mb-2">
            Dispositivo de Áudio
          </label>
          <select
            value={localSettings.audioDevice || 'default'}
            onChange={(e) => handleSettingChange('audioDevice', e.target.value)}
            className="input-netflix w-full max-w-xs"
          >
            <option value="default">Padrão do Sistema</option>
            <option value="speakers">Alto-falantes</option>
            <option value="headphones">Fones de Ouvido</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-netflix-gray-light mb-2">
            Volume Padrão
          </label>
          <div className="flex items-center space-x-4">
            <input
              type="range"
              min="0"
              max="100"
              value={localSettings.defaultVolume || 50}
              onChange={(e) => handleSettingChange('defaultVolume', parseInt(e.target.value))}
              className="flex-1 max-w-xs"
            />
            <span className="text-white w-12 text-right">
              {localSettings.defaultVolume || 50}%
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-white">
              Normalização de Volume
            </label>
            <p className="text-sm text-netflix-gray-light">
              Manter volume consistente entre diferentes conteúdos
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={localSettings.volumeNormalization || false}
              onChange={(e) => handleSettingChange('volumeNormalization', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-netflix-gray-dark peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-netflix-red"></div>
          </label>
        </div>
      </div>
    </div>
  );

  const renderParentalSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Controle Parental</h2>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <label className="block text-sm font-medium text-white">
              Ativar Controle Parental
            </label>
            <p className="text-sm text-netflix-gray-light">
              Restringir acesso a conteúdo inadequado
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={localSettings.parentalControl}
              onChange={(e) => handleSettingChange('parentalControl', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-netflix-gray-dark peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-netflix-red"></div>
          </label>
        </div>

        {localSettings.parentalControl && (
          <div className="space-y-4 pl-4 border-l-2 border-netflix-red">
            <div>
              <label className="block text-sm font-medium text-netflix-gray-light mb-2">
                PIN de Acesso
              </label>
              <div className="relative max-w-xs">
                <input
                  type={showPin ? 'text' : 'password'}
                  value={parentalPin}
                  onChange={(e) => setParentalPin(e.target.value)}
                  placeholder="Digite um PIN de 4 dígitos"
                  maxLength="4"
                  className="input-netflix pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-netflix-gray-light hover:text-white"
                >
                  {showPin ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-netflix-gray-light mb-2">
                Classificação Máxima
              </label>
              <select
                value={localSettings.maxRating || 'PG-13'}
                onChange={(e) => handleSettingChange('maxRating', e.target.value)}
                className="input-netflix w-full max-w-xs"
              >
                <option value="G">Livre</option>
                <option value="PG">10 anos</option>
                <option value="PG-13">12 anos</option>
                <option value="R">14 anos</option>
                <option value="NC-17">16 anos</option>
                <option value="X">18 anos</option>
              </select>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderAccountSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Informações da Conta</h2>
      
      <div className="space-y-4">
        <div className="bg-netflix-gray-dark rounded-lg p-4">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-netflix-red rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-white font-semibold">
                {user?.username || 'Usuário'}
              </h3>
              <p className="text-netflix-gray-light text-sm">
                {user?.serverUrl || 'Servidor não configurado'}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center py-2">
            <span className="text-netflix-gray-light">Status da Conta</span>
            <span className="text-green-400">Ativa</span>
          </div>
          
          <div className="flex justify-between items-center py-2">
            <span className="text-netflix-gray-light">Último Login</span>
            <span className="text-white">Hoje</span>
          </div>
          
          <div className="flex justify-between items-center py-2">
            <span className="text-netflix-gray-light">Versão do App</span>
            <span className="text-white">1.0.0</span>
          </div>
        </div>

        <div className="pt-4 border-t border-netflix-gray-dark">
          <button
            onClick={handleLogout}
            className="flex items-center space-x-2 text-red-400 hover:text-red-300 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Sair da Conta</span>
          </button>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return renderGeneralSettings();
      case 'video':
        return renderVideoSettings();
      case 'audio':
        return renderAudioSettings();
      case 'parental':
        return renderParentalSettings();
      case 'account':
        return renderAccountSettings();
      default:
        return renderGeneralSettings();
    }
  };

  return (
    <div className="fixed inset-0 bg-netflix-black z-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-netflix-black-light border-r border-netflix-gray-dark p-6">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-xl font-bold text-white">Configurações</h1>
          <button
            onClick={onClose}
            className="text-netflix-gray-light hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="space-y-2">
          {tabs.map(tab => (
            <TabButton
              key={tab.id}
              tab={tab}
              isActive={activeTab === tab.id}
              onClick={setActiveTab}
            />
          ))}
        </nav>
      </div>

      {/* Conteúdo principal */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-8">
          {renderTabContent()}
          
          {/* Botões de ação */}
          {hasChanges && (
            <div className="fixed bottom-8 right-8 flex space-x-4">
              <button
                onClick={() => {
                  setLocalSettings(settings);
                  setHasChanges(false);
                }}
                className="btn-secondary px-6 py-3"
              >
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="btn-netflix px-6 py-3 flex items-center"
              >
                <Save className="w-5 h-5 mr-2" />
                Salvar Alterações
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SettingsScreen;

