import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Settings, 
  User, 
  LogOut, 
  Play, 
  Plus, 
  Heart,
  Clock,
  Star,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import contentService from '../services/contentService';

const MainScreen = ({ user, onPlayContent, onOpenSettings, onLogout }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [content, setContent] = useState({
    featured: null,
    liveChannels: [],
    movies: [],
    series: [],
    favorites: [],
    history: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadContent();
  }, []);

  const loadContent = async () => {
    try {
      setLoading(true);
      setError(null);

      const [mainContent, favorites, history] = await Promise.all([
        contentService.getMainScreenContent(),
        contentService.getFavorites(user?.username || 'guest'),
        contentService.getHistory(user?.username || 'guest')
      ]);

      setContent({
        ...mainContent,
        favorites,
        history
      });
    } catch (error) {
      console.error('Erro ao carregar conteúdo:', error);
      setError('Erro ao carregar conteúdo. Verifique sua conexão.');
      
      // Usar dados mock em caso de erro
      loadMockContent();
    } finally {
      setLoading(false);
    }
  };

  const loadMockContent = () => {
    // Dados simulados para demonstração
    const mockData = {
      featured: {
        id: 'featured-1',
        name: 'Canal Premium',
        description: 'Assista aos melhores filmes e séries em alta qualidade.\nConteúdo exclusivo disponível 24 horas por dia.',
        poster: 'https://via.placeholder.com/1920x1080/e50914/ffffff?text=Canal+Premium',
        type: 'live',
        category: 'Premium',
        isLive: true
      },
      liveChannels: Array.from({ length: 12 }, (_, i) => ({
        id: i + 1,
        name: `Canal ${i + 1}`,
        poster: `https://via.placeholder.com/300x400/333/fff?text=Canal+${i + 1}`,
        category: 'TV ao Vivo',
        type: 'live',
        isLive: true,
        quality: i % 3 === 0 ? 'HD' : 'SD'
      })),
      movies: Array.from({ length: 10 }, (_, i) => ({
        id: i + 100,
        name: `Filme ${i + 1}`,
        poster: `https://via.placeholder.com/300x450/e50914/fff?text=Filme+${i + 1}`,
        category: 'Filmes',
        type: 'vod',
        year: 2020 + (i % 4),
        rating: (4 + Math.random()).toFixed(1)
      })),
      series: Array.from({ length: 8 }, (_, i) => ({
        id: i + 200,
        name: `Série ${i + 1}`,
        poster: `https://via.placeholder.com/300x450/1a1a1a/fff?text=Série+${i + 1}`,
        category: 'Séries',
        type: 'series',
        seasons: Math.floor(Math.random() * 5) + 1,
        rating: (4 + Math.random()).toFixed(1)
      })),
      favorites: [],
      history: []
    };

    setContent(mockData);
  };

  const handleSearch = async (query) => {
    if (!query.trim()) return;

    try {
      const results = await contentService.searchContent(query);
      console.log('Resultados da busca:', results);
      // Implementar exibição dos resultados
    } catch (error) {
      console.error('Erro na busca:', error);
    }
  };

  const handlePlayContent = async (contentItem) => {
    try {
      // Adicionar ao histórico
      await contentService.addToHistory(
        user?.username || 'guest',
        contentItem,
        0,
        contentItem.duration || 0
      );

      onPlayContent(contentItem);
    } catch (error) {
      console.error('Erro ao reproduzir conteúdo:', error);
      // Continuar mesmo com erro no histórico
      onPlayContent(contentItem);
    }
  };

  const handleToggleFavorite = async (contentItem) => {
    try {
      const userId = user?.username || 'guest';
      const isFavorite = content.favorites.some(fav => 
        fav.id === contentItem.id && fav.type === contentItem.type
      );

      if (isFavorite) {
        await contentService.removeFromFavorites(userId, contentItem.id, contentItem.type);
      } else {
        await contentService.addToFavorites(userId, contentItem);
      }

      // Recarregar favoritos
      const updatedFavorites = await contentService.getFavorites(userId);
      setContent(prev => ({ ...prev, favorites: updatedFavorites }));
    } catch (error) {
      console.error('Erro ao gerenciar favorito:', error);
    }
  };

  const isFavorite = (contentItem) => {
    return content.favorites.some(fav => 
      fav.id === contentItem.id && fav.type === contentItem.type
    );
  };

  const ContentCard = ({ item, showProgress = false }) => (
    <div className="content-card group min-w-[200px] max-w-[200px] cursor-pointer">
      <div className="relative aspect-poster overflow-hidden rounded-lg bg-netflix-gray-dark">
        <img 
          src={item.poster || 'https://via.placeholder.com/300x450/333/fff?text=Sem+Imagem'}
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/300x450/333/fff?text=Sem+Imagem';
          }}
        />
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex gap-2">
          {item.isLive && (
            <span className="bg-red-600 text-white text-xs px-2 py-1 rounded">
              AO VIVO
            </span>
          )}
          {item.quality && (
            <span className="bg-netflix-gray text-white text-xs px-2 py-1 rounded">
              {item.quality}
            </span>
          )}
        </div>
        
        {/* Progress bar para "Continuar Assistindo" */}
        {showProgress && item.progress && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-netflix-gray">
            <div 
              className="h-full bg-netflix-red transition-all duration-300"
              style={{ width: `${item.progress}%` }}
            />
          </div>
        )}
        
        {/* Overlay com controles */}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="flex space-x-2">
            <button
              onClick={() => handlePlayContent(item)}
              className="bg-white text-black p-2 rounded-full hover:bg-netflix-gray-light transition-colors"
              title="Reproduzir"
            >
              <Play className="w-5 h-5" fill="currentColor" />
            </button>
            <button
              onClick={() => handleToggleFavorite(item)}
              className={`p-2 rounded-full transition-colors ${
                isFavorite(item) 
                  ? 'bg-netflix-red text-white' 
                  : 'bg-netflix-gray-dark text-white hover:bg-netflix-gray-medium'
              }`}
              title={isFavorite(item) ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
            >
              <Heart className="w-5 h-5" fill={isFavorite(item) ? 'currentColor' : 'none'} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-3">
        <h3 className="font-semibold text-sm text-white truncate">
          {item.name}
        </h3>
        <div className="flex items-center gap-2 mt-1">
          {item.year && (
            <span className="text-netflix-gray-light text-xs">{item.year}</span>
          )}
          {item.rating && (
            <div className="flex items-center gap-1">
              <Star size={12} className="text-yellow-500" fill="currentColor" />
              <span className="text-netflix-gray-light text-xs">{item.rating}</span>
            </div>
          )}
          {item.seasons && (
            <span className="text-netflix-gray-light text-xs">
              {item.seasons} temp{item.seasons > 1 ? 's' : ''}
            </span>
          )}
        </div>
      </div>
    </div>
  );

  const CategorySection = ({ title, items, showProgress = false, icon: Icon }) => {
    if (!items || items.length === 0) return null;

    return (
      <div className="category-section mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="category-title flex items-center text-xl font-semibold text-white">
            <Icon className="w-6 h-6 mr-2 text-netflix-red" />
            {title}
          </h2>
          {items.length > 6 && (
            <button className="text-netflix-gray-light hover:text-white text-sm transition-colors">
              Ver todos
            </button>
          )}
        </div>
        
        <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
          {items.slice(0, 12).map(item => (
            <ContentCard key={`${item.id}-${item.type}`} item={item} showProgress={showProgress} />
          ))}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-netflix-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-netflix-red mx-auto mb-4"></div>
          <p className="text-white">Carregando conteúdo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-netflix-black text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-b from-netflix-black to-transparent">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold text-netflix-red">
                IPTV Player Pro
              </h1>
              
              {/* Navegação */}
              <nav className="hidden md:flex space-x-6">
                <button className="text-white hover:text-netflix-gray-light transition-colors">
                  Início
                </button>
                <button className="text-netflix-gray-light hover:text-white transition-colors">
                  TV ao Vivo
                </button>
                <button className="text-netflix-gray-light hover:text-white transition-colors">
                  Filmes
                </button>
                <button className="text-netflix-gray-light hover:text-white transition-colors">
                  Séries
                </button>
              </nav>
            </div>

            {/* Controles do usuário */}
            <div className="flex items-center space-x-4">
              {/* Busca */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-netflix-gray-light" />
                <input
                  type="text"
                  placeholder="Buscar..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch(searchQuery)}
                  className="bg-netflix-gray-dark border border-netflix-gray-medium rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-netflix-red transition-colors w-64"
                />
              </div>

              {/* Menu do usuário */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={onOpenSettings}
                  className="p-2 hover:bg-netflix-gray-dark rounded-full transition-colors"
                  title="Configurações"
                >
                  <Settings className="w-5 h-5" />
                </button>
                <button
                  onClick={onLogout}
                  className="p-2 hover:bg-netflix-gray-dark rounded-full transition-colors"
                  title="Sair"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo principal */}
      <main className="pt-20">
        {/* Banner em destaque */}
        {content.featured && (
          <section className="relative h-[70vh] mb-8">
            <div className="absolute inset-0">
              <img 
                src={content.featured.poster}
                alt={content.featured.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
            </div>
            
            <div className="relative container mx-auto px-4 h-full flex items-center">
              <div className="max-w-lg">
                <h1 className="text-5xl font-bold mb-4">
                  {content.featured.name}
                </h1>
                <p className="text-lg text-netflix-gray-light mb-6 leading-relaxed">
                  {content.featured.description}
                </p>
                
                <div className="flex space-x-4">
                  <button
                    onClick={() => handlePlayContent(content.featured)}
                    className="bg-white text-black px-8 py-3 text-lg flex items-center rounded hover:bg-netflix-gray-light transition-colors"
                  >
                    <Play className="w-6 h-6 mr-2" fill="currentColor" />
                    Assistir
                  </button>
                  <button
                    onClick={() => handleToggleFavorite(content.featured)}
                    className="bg-netflix-gray text-white px-8 py-3 text-lg flex items-center rounded hover:bg-netflix-gray-light transition-colors"
                  >
                    <Plus className="w-6 h-6 mr-2" />
                    Minha Lista
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Seções de conteúdo */}
        <div className="container mx-auto px-4 space-y-8 pb-8">
          {/* Continuar Assistindo */}
          <CategorySection
            title="Continuar Assistindo"
            items={content.history}
            showProgress={true}
            icon={Clock}
          />

          {/* Favoritos */}
          <CategorySection
            title="Meus Favoritos"
            items={content.favorites}
            icon={Heart}
          />

          {/* TV ao Vivo */}
          <CategorySection
            title="TV ao Vivo"
            items={content.liveChannels}
            icon={Play}
          />

          {/* Filmes */}
          <CategorySection
            title="Filmes"
            items={content.movies}
            icon={Star}
          />

          {/* Séries */}
          <CategorySection
            title="Séries"
            items={content.series}
            icon={Star}
          />
        </div>
      </main>

      {error && (
        <div className="fixed bottom-4 right-4 bg-red-600 text-white px-4 py-2 rounded shadow-lg">
          {error}
        </div>
      )}
    </div>
  );
};

export default MainScreen;

