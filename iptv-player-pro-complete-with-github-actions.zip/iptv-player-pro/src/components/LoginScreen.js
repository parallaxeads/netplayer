import React, { useState } from 'react';
import { Eye, EyeOff, Wifi, User, Lock, Server, QrCode } from 'lucide-react';
import QRCode from 'react-qr-code';
import authService from '../services/authService';

const LoginScreen = ({ onLogin, appVersion }) => {
  const [loginMethod, setLoginMethod] = useState('credentials'); // 'credentials' ou 'qrcode'
  const [formData, setFormData] = useState({
    serverUrl: '',
    username: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [qrCodeData, setQrCodeData] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Limpar erro do campo quando usuário começar a digitar
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    setIsLoading(true);
    setErrors({});

    try {
      const result = await authService.loginWithCredentials(formData);
      
      if (result.success) {
        onLogin(result.user);
      }
    } catch (error) {
      setErrors({
        general: error.message || 'Erro ao conectar com o servidor. Verifique suas credenciais.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateQRCode = () => {
    const qrData = authService.generateQRCode({
      serverUrl: 'http://demo.server.com:8080',
      username: 'demo_user',
      password: 'demo123'
    });
    setQrCodeData(qrData);
  };

  const handleQRLogin = async () => {
    if (!qrCodeData) return;

    setIsLoading(true);
    setErrors({});

    try {
      const result = await authService.loginWithQRCode(qrCodeData);
      
      if (result.success) {
        onLogin(result.user);
      }
    } catch (error) {
      setErrors({
        general: error.message || 'Erro no login via QR Code.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-netflix-black via-netflix-black-light to-netflix-gray-dark flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-repeat" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gradient mb-2">
            IPTV Player Pro
          </h1>
          <p className="text-netflix-gray-light">
            Entre na sua conta
          </p>
        </div>

        {/* Card de Login */}
        <div className="glass-effect rounded-2xl p-8 shadow-2xl">
          {/* Seletor de método de login */}
          <div className="flex mb-6 bg-netflix-gray-dark rounded-lg p-1">
            <button
              type="button"
              onClick={() => setLoginMethod('credentials')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 ${
                loginMethod === 'credentials'
                  ? 'bg-netflix-red text-white shadow-lg'
                  : 'text-netflix-gray-light hover:text-white'
              }`}
            >
              <User className="w-4 h-4 inline mr-2" />
              Credenciais
            </button>
            <button
              type="button"
              onClick={() => setLoginMethod('qrcode')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 ${
                loginMethod === 'qrcode'
                  ? 'bg-netflix-red text-white shadow-lg'
                  : 'text-netflix-gray-light hover:text-white'
              }`}
            >
              <QrCode className="w-4 h-4 inline mr-2" />
              QR Code
            </button>
          </div>

          {loginMethod === 'credentials' ? (
            /* Formulário de Credenciais */
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Erro geral */}
              {errors.general && (
                <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-3 text-red-400 text-sm">
                  {errors.general}
                </div>
              )}

              {/* URL do Servidor */}
              <div>
                <label className="block text-sm font-medium text-netflix-gray-light mb-2">
                  URL do Servidor
                </label>
                <div className="relative">
                  <Server className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-netflix-gray-light" />
                  <input
                    type="url"
                    name="serverUrl"
                    value={formData.serverUrl}
                    onChange={handleInputChange}
                    placeholder="http://servidor.com:8080"
                    className={`input-netflix pl-10 w-full ${
                      errors.serverUrl ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : ''
                    }`}
                  />
                </div>
                {errors.serverUrl && (
                  <p className="mt-1 text-sm text-red-400">{errors.serverUrl}</p>
                )}
              </div>

              {/* Nome de Usuário */}
              <div>
                <label className="block text-sm font-medium text-netflix-gray-light mb-2">
                  Nome de Usuário
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-netflix-gray-light" />
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleInputChange}
                    placeholder="Seu nome de usuário"
                    className={`input-netflix pl-10 w-full ${
                      errors.username ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : ''
                    }`}
                  />
                </div>
                {errors.username && (
                  <p className="mt-1 text-sm text-red-400">{errors.username}</p>
                )}
              </div>

              {/* Senha */}
              <div>
                <label className="block text-sm font-medium text-netflix-gray-light mb-2">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-netflix-gray-light" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Sua senha"
                    className={`input-netflix pl-10 pr-10 w-full ${
                      errors.password ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : ''
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-netflix-gray-light hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="mt-1 text-sm text-red-400">{errors.password}</p>
                )}
              </div>

              {/* Botão de Login */}
              <button
                type="submit"
                disabled={isLoading}
                className="btn-netflix w-full py-3 text-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Conectando...
                  </>
                ) : (
                  <>
                    <Wifi className="w-5 h-5 mr-2" />
                    Entrar
                  </>
                )}
              </button>
            </form>
          ) : (
            /* Login via QR Code */
            <div className="text-center space-y-6">
              <div className="bg-white p-4 rounded-lg inline-block">
                {qrCodeData ? (
                  <QRCode value={qrCodeData} size={200} />
                ) : (
                  <div className="w-[200px] h-[200px] bg-netflix-gray-dark rounded flex items-center justify-center">
                    <QrCode className="w-16 h-16 text-netflix-gray-light" />
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <p className="text-netflix-gray-light text-sm">
                  Escaneie o QR Code com seu celular para fazer login automaticamente
                </p>

                {!qrCodeData ? (
                  <button
                    onClick={generateQRCode}
                    className="btn-netflix w-full py-3"
                  >
                    <QrCode className="w-5 h-5 mr-2" />
                    Gerar QR Code
                  </button>
                ) : (
                  <button
                    onClick={handleQRLogin}
                    className="btn-secondary w-full py-3"
                  >
                    Simular Login via QR
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Informações adicionais */}
        <div className="text-center mt-6 space-y-2">
          <p className="text-netflix-gray-light text-sm">
            Versão {appVersion}
          </p>
          <p className="text-netflix-gray-light text-xs">
            © 2024 IPTV Player Pro. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;

