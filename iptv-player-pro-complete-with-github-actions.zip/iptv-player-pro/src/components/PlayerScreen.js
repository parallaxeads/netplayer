import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize,
  Settings,
  SkipBack,
  SkipForward,
  RotateCcw,
  Subtitles,
  Volume1
} from 'lucide-react';
import videoPlayerService from '../services/videoPlayerService';
import contentService from '../services/contentService';

const PlayerScreen = ({ user, onBack, content: initialContent }) => {
  const playerContainerRef = useRef(null);
  const controlsTimeoutRef = useRef(null);
  
  const [content, setContent] = useState(initialContent);
  const [playerState, setPlayerState] = useState({
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 1,
    playbackRate: 1,
    isFullscreen: false,
    subtitles: [],
    audioTracks: [],
    currentSubtitle: -1,
    currentAudioTrack: 0
  });
  
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [epgData, setEpgData] = useState(null);

  useEffect(() => {
    initializePlayer();
    
    return () => {
      videoPlayerService.destroy();
    };
  }, []);

  useEffect(() => {
    if (initialContent) {
      loadContent(initialContent);
    }
  }, [initialContent]);

  const initializePlayer = () => {
    // Configurar listeners do player
    videoPlayerService.on('play', () => {
      setPlayerState(prev => ({ ...prev, isPlaying: true }));
    });

    videoPlayerService.on('pause', () => {
      setPlayerState(prev => ({ ...prev, isPlaying: false }));
    });

    videoPlayerService.on('timeupdate', () => {
      const state = videoPlayerService.getState();
      setPlayerState(prev => ({
        ...prev,
        currentTime: state.currentTime,
        duration: state.duration
      }));
    });

    videoPlayerService.on('volumechange', (volume) => {
      setPlayerState(prev => ({ ...prev, volume }));
    });

    videoPlayerService.on('fullscreenchange', (isFullscreen) => {
      setPlayerState(prev => ({ ...prev, isFullscreen }));
    });

    videoPlayerService.on('subtitlesLoaded', (subtitles) => {
      setPlayerState(prev => ({ ...prev, subtitles }));
    });

    videoPlayerService.on('audioTracksLoaded', (audioTracks) => {
      setPlayerState(prev => ({ ...prev, audioTracks }));
    });

    videoPlayerService.on('error', (errorData) => {
      console.error('Player error:', errorData);
      setError(`Erro no player: ${errorData.message || 'Erro desconhecido'}`);
      setLoading(false);
    });

    videoPlayerService.on('mediaLoaded', () => {
      setLoading(false);
      setError(null);
    });

    videoPlayerService.on('ended', () => {
      // Conteúdo terminou, voltar para tela principal
      setTimeout(() => {
        onBack();
      }, 3000);
    });
  };

  const loadContent = async (contentItem) => {
    try {
      setLoading(true);
      setError(null);
      setContent(contentItem);

      // Carregar EPG se for canal ao vivo
      if (contentItem.type === 'live' && contentItem.stream_id) {
        try {
          const epg = await contentService.getChannelEpg(contentItem.stream_id);
          setEpgData(epg);
        } catch (epgError) {
          console.warn('Erro ao carregar EPG:', epgError);
        }
      }

      // Carregar mídia no player
      await videoPlayerService.loadMedia(contentItem, playerContainerRef.current);
      
      // Adicionar ao histórico
      if (user) {
        await contentService.addToHistory(user.username, contentItem, 0, contentItem.duration || 0);
      }

    } catch (error) {
      console.error('Erro ao carregar conteúdo:', error);
      setError('Erro ao carregar conteúdo. Verifique sua conexão.');
      setLoading(false);
    }
  };

  const handlePlayPause = () => {
    videoPlayerService.togglePlayPause();
  };

  const handleSeek = (time) => {
    videoPlayerService.seek(time);
  };

  const handleVolumeChange = (volume) => {
    videoPlayerService.setVolume(volume);
  };

  const handleMute = () => {
    videoPlayerService.toggleMute();
  };

  const handleFullscreen = () => {
    videoPlayerService.toggleFullscreen();
  };

  const handlePlaybackRate = (rate) => {
    videoPlayerService.setPlaybackRate(rate);
    setPlayerState(prev => ({ ...prev, playbackRate: rate }));
  };

  const handleSubtitleChange = (index) => {
    videoPlayerService.setSubtitle(index);
    setPlayerState(prev => ({ ...prev, currentSubtitle: index }));
  };

  const handleAudioTrackChange = (index) => {
    videoPlayerService.setAudioTrack(index);
    setPlayerState(prev => ({ ...prev, currentAudioTrack: index }));
  };

  const handleSkipBack = () => {
    handleSeek(playerState.currentTime - 10);
  };

  const handleSkipForward = () => {
    handleSeek(playerState.currentTime + 10);
  };

  const handleRestart = () => {
    handleSeek(0);
  };

  const showControlsTemporarily = () => {
    setShowControls(true);
    
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    
    controlsTimeoutRef.current = setTimeout(() => {
      if (playerState.isPlaying) {
        setShowControls(false);
      }
    }, 3000);
  };

  const formatTime = (seconds) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgressPercentage = () => {
    if (!playerState.duration) return 0;
    return (playerState.currentTime / playerState.duration) * 100;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-netflix-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-netflix-red mx-auto mb-4"></div>
          <p className="text-white">Carregando player...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-netflix-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={onBack}
            className="bg-netflix-red text-white px-6 py-2 rounded hover:bg-red-700 transition-colors"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="relative min-h-screen bg-black text-white overflow-hidden"
      onMouseMove={showControlsTemporarily}
      onClick={showControlsTemporarily}
    >
      {/* Container do player */}
      <div 
        ref={playerContainerRef}
        className="absolute inset-0 flex items-center justify-center"
      >
        {/* O elemento de vídeo será inserido aqui pelo videoPlayerService */}
      </div>

      {/* Overlay com controles */}
      <div 
        className={`absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/50 transition-opacity duration-300 ${
          showControls ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              
              <div>
                <h1 className="text-xl font-semibold">{content?.name}</h1>
                {content?.category && (
                  <p className="text-netflix-gray-light text-sm">{content.category}</p>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {content?.isLive && (
                <span className="bg-red-600 text-white text-sm px-3 py-1 rounded">
                  AO VIVO
                </span>
              )}
              
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* EPG Info (para canais ao vivo) */}
        {epgData && epgData.epg_listings && epgData.epg_listings.length > 0 && (
          <div className="absolute top-20 left-6 right-6">
            <div className="bg-black/60 rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">Programação Atual</h3>
              {epgData.epg_listings.slice(0, 3).map((program, index) => (
                <div key={index} className="flex justify-between items-center py-1">
                  <span className="text-sm">{program.title}</span>
                  <span className="text-xs text-netflix-gray-light">
                    {formatTime(program.start_timestamp)} - {formatTime(program.stop_timestamp)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Controles centrais */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="flex items-center space-x-8">
            <button
              onClick={handleRestart}
              className="p-3 hover:bg-white/20 rounded-full transition-colors"
              title="Reiniciar"
            >
              <RotateCcw className="w-8 h-8" />
            </button>
            
            <button
              onClick={handleSkipBack}
              className="p-3 hover:bg-white/20 rounded-full transition-colors"
              title="Voltar 10s"
            >
              <SkipBack className="w-8 h-8" />
            </button>
            
            <button
              onClick={handlePlayPause}
              className="p-4 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
              title={playerState.isPlaying ? 'Pausar' : 'Reproduzir'}
            >
              {playerState.isPlaying ? (
                <Pause className="w-10 h-10" />
              ) : (
                <Play className="w-10 h-10" />
              )}
            </button>
            
            <button
              onClick={handleSkipForward}
              className="p-3 hover:bg-white/20 rounded-full transition-colors"
              title="Avançar 10s"
            >
              <SkipForward className="w-8 h-8" />
            </button>
            
            <button
              onClick={handleFullscreen}
              className="p-3 hover:bg-white/20 rounded-full transition-colors"
              title={playerState.isFullscreen ? 'Sair da tela cheia' : 'Tela cheia'}
            >
              {playerState.isFullscreen ? (
                <Minimize className="w-8 h-8" />
              ) : (
                <Maximize className="w-8 h-8" />
              )}
            </button>
          </div>
        </div>

        {/* Controles inferiores */}
        <div className="absolute bottom-0 left-0 right-0 p-6">
          {/* Barra de progresso */}
          {!content?.isLive && playerState.duration > 0 && (
            <div className="mb-4">
              <div className="relative">
                <div className="w-full h-1 bg-white/30 rounded-full">
                  <div 
                    className="h-full bg-netflix-red rounded-full transition-all duration-200"
                    style={{ width: `${getProgressPercentage()}%` }}
                  />
                </div>
                
                <input
                  type="range"
                  min="0"
                  max={playerState.duration}
                  value={playerState.currentTime}
                  onChange={(e) => handleSeek(parseFloat(e.target.value))}
                  className="absolute inset-0 w-full h-1 opacity-0 cursor-pointer"
                />
              </div>
              
              <div className="flex justify-between text-sm text-netflix-gray-light mt-2">
                <span>{formatTime(playerState.currentTime)}</span>
                <span>{formatTime(playerState.duration)}</span>
              </div>
            </div>
          )}

          {/* Controles de volume e configurações */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {/* Volume */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleMute}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  {playerState.volume === 0 ? (
                    <VolumeX className="w-5 h-5" />
                  ) : playerState.volume < 0.5 ? (
                    <Volume1 className="w-5 h-5" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                </button>
                
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={playerState.volume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="w-20 accent-netflix-red"
                />
              </div>

              {/* Velocidade (apenas para VOD) */}
              {!content?.isLive && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm">Velocidade:</span>
                  <select
                    value={playerState.playbackRate}
                    onChange={(e) => handlePlaybackRate(parseFloat(e.target.value))}
                    className="bg-white/20 text-white text-sm px-2 py-1 rounded"
                  >
                    <option value={0.5}>0.5x</option>
                    <option value={0.75}>0.75x</option>
                    <option value={1}>1x</option>
                    <option value={1.25}>1.25x</option>
                    <option value={1.5}>1.5x</option>
                    <option value={2}>2x</option>
                  </select>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-4">
              {/* Legendas */}
              {playerState.subtitles.length > 0 && (
                <div className="flex items-center space-x-2">
                  <Subtitles className="w-5 h-5" />
                  <select
                    value={playerState.currentSubtitle}
                    onChange={(e) => handleSubtitleChange(parseInt(e.target.value))}
                    className="bg-white/20 text-white text-sm px-2 py-1 rounded"
                  >
                    <option value={-1}>Sem legendas</option>
                    {playerState.subtitles.map((subtitle, index) => (
                      <option key={index} value={index}>
                        {subtitle.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Áudio */}
              {playerState.audioTracks.length > 1 && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm">Áudio:</span>
                  <select
                    value={playerState.currentAudioTrack}
                    onChange={(e) => handleAudioTrackChange(parseInt(e.target.value))}
                    className="bg-white/20 text-white text-sm px-2 py-1 rounded"
                  >
                    {playerState.audioTracks.map((track, index) => (
                      <option key={index} value={index}>
                        {track.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Painel de configurações */}
      {showSettings && (
        <div className="absolute top-20 right-6 bg-black/90 rounded-lg p-4 min-w-64">
          <h3 className="text-lg font-semibold mb-4">Configurações do Player</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Qualidade</label>
              <select className="w-full bg-white/20 text-white text-sm px-3 py-2 rounded">
                <option>Auto</option>
                <option>1080p</option>
                <option>720p</option>
                <option>480p</option>
              </select>
            </div>

            {playerState.subtitles.length > 0 && (
              <div>
                <label className="block text-sm font-medium mb-2">Legendas</label>
                <select 
                  value={playerState.currentSubtitle}
                  onChange={(e) => handleSubtitleChange(parseInt(e.target.value))}
                  className="w-full bg-white/20 text-white text-sm px-3 py-2 rounded"
                >
                  <option value={-1}>Desabilitadas</option>
                  {playerState.subtitles.map((subtitle, index) => (
                    <option key={index} value={index}>
                      {subtitle.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {playerState.audioTracks.length > 1 && (
              <div>
                <label className="block text-sm font-medium mb-2">Faixa de Áudio</label>
                <select 
                  value={playerState.currentAudioTrack}
                  onChange={(e) => handleAudioTrackChange(parseInt(e.target.value))}
                  className="w-full bg-white/20 text-white text-sm px-3 py-2 rounded"
                >
                  {playerState.audioTracks.map((track, index) => (
                    <option key={index} value={index}>
                      {track.label}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <button
            onClick={() => setShowSettings(false)}
            className="mt-4 w-full bg-netflix-red text-white py-2 rounded hover:bg-red-700 transition-colors"
          >
            Fechar
          </button>
        </div>
      )}
    </div>
  );
};

export default PlayerScreen;

