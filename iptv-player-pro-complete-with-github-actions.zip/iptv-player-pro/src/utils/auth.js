// Utilitários de autenticação

/**
 * Verifica o status de autenticação do usuário
 * @returns {Promise<boolean>} Status de autenticação
 */
export async function checkAuthStatus() {
  try {
    // Por enquanto, verificar localStorage
    // Depois será implementado com SQLite
    const savedAuth = localStorage.getItem('iptv_auth');
    
    if (!savedAuth) {
      return false;
    }

    const authData = JSON.parse(savedAuth);
    
    // Verificar se o token não expirou
    if (authData.expiresAt && new Date() > new Date(authData.expiresAt)) {
      localStorage.removeItem('iptv_auth');
      return false;
    }

    return true;
  } catch (error) {
    console.error('Erro ao verificar status de autenticação:', error);
    return false;
  }
}

/**
 * Salva dados de autenticação
 * @param {Object} authData - Dados de autenticação
 */
export function saveAuthData(authData) {
  try {
    const dataToSave = {
      ...authData,
      savedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 horas
    };
    
    localStorage.setItem('iptv_auth', JSON.stringify(dataToSave));
  } catch (error) {
    console.error('Erro ao salvar dados de autenticação:', error);
  }
}

/**
 * Recupera dados de autenticação salvos
 * @returns {Object|null} Dados de autenticação ou null
 */
export function getAuthData() {
  try {
    const savedAuth = localStorage.getItem('iptv_auth');
    
    if (!savedAuth) {
      return null;
    }

    const authData = JSON.parse(savedAuth);
    
    // Verificar se não expirou
    if (authData.expiresAt && new Date() > new Date(authData.expiresAt)) {
      localStorage.removeItem('iptv_auth');
      return null;
    }

    return authData;
  } catch (error) {
    console.error('Erro ao recuperar dados de autenticação:', error);
    return null;
  }
}

/**
 * Remove dados de autenticação (logout)
 */
export function clearAuthData() {
  try {
    localStorage.removeItem('iptv_auth');
  } catch (error) {
    console.error('Erro ao limpar dados de autenticação:', error);
  }
}

/**
 * Valida formato de URL do servidor
 * @param {string} url - URL para validar
 * @returns {boolean} Se a URL é válida
 */
export function validateServerUrl(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Valida credenciais básicas
 * @param {Object} credentials - Credenciais para validar
 * @returns {Object} Resultado da validação
 */
export function validateCredentials(credentials) {
  const errors = {};

  if (!credentials.serverUrl || !credentials.serverUrl.trim()) {
    errors.serverUrl = 'URL do servidor é obrigatória';
  } else if (!validateServerUrl(credentials.serverUrl)) {
    errors.serverUrl = 'URL do servidor inválida';
  }

  if (!credentials.username || !credentials.username.trim()) {
    errors.username = 'Nome de usuário é obrigatório';
  }

  if (!credentials.password || !credentials.password.trim()) {
    errors.password = 'Senha é obrigatória';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

/**
 * Gera um token de sessão simples
 * @returns {string} Token de sessão
 */
export function generateSessionToken() {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

/**
 * Criptografa dados sensíveis (implementação básica)
 * @param {string} data - Dados para criptografar
 * @returns {string} Dados criptografados
 */
export function encryptData(data) {
  // Implementação básica - em produção usar crypto mais robusto
  return btoa(data);
}

/**
 * Descriptografa dados sensíveis (implementação básica)
 * @param {string} encryptedData - Dados criptografados
 * @returns {string} Dados descriptografados
 */
export function decryptData(encryptedData) {
  try {
    return atob(encryptedData);
  } catch {
    return null;
  }
}

