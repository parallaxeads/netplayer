import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Configuração global para desenvolvimento
if (process.env.NODE_ENV === 'development') {
  // Habilitar logs detalhados em desenvolvimento
  console.log('IPTV Player Pro - Modo de Desenvolvimento');
}

// Criar root do React 18
const root = ReactDOM.createRoot(document.getElementById('root'));

// Renderizar aplicação
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Remover tela de carregamento inicial após React carregar
setTimeout(() => {
  const loadingScreen = document.getElementById('loading-screen');
  if (loadingScreen) {
    loadingScreen.style.opacity = '0';
    loadingScreen.style.transition = 'opacity 0.5s ease-out';
    setTimeout(() => {
      loadingScreen.remove();
    }, 500);
  }
}, 100);

