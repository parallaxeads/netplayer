import { useEffect, useRef, useState } from 'react';
import navigationService from '../services/navigationService';

/**
 * Hook para integração com o sistema de navegação
 */
export const useNavigation = (options = {}) => {
  const {
    autoFocus = false,
    focusOnMount = false,
    restoreFocus = false,
    shortcuts = {},
    onFocusChange = null,
    onActivate = null
  } = options;

  const elementRef = useRef(null);
  const [currentFocus, setCurrentFocus] = useState(null);
  const [navigationMode, setNavigationMode] = useState('mouse');

  useEffect(() => {
    // Listener para mudanças de foco
    const handleFocusChange = ({ element }) => {
      setCurrentFocus(element);
      if (onFocusChange) {
        onFocusChange(element);
      }
    };

    // Listener para mudanças de modo de navegação
    const handleModeChange = ({ mode }) => {
      setNavigationMode(mode);
    };

    // Listener para ativação de elementos
    const handleElementActivated = ({ element }) => {
      if (onActivate) {
        onActivate(element);
      }
    };

    navigationService.on('focus-change', handleFocusChange);
    navigationService.on('navigation-mode-change', handleModeChange);
    navigationService.on('element-activated', handleElementActivated);

    // Configurar atalhos personalizados
    Object.entries(shortcuts).forEach(([key, action]) => {
      navigationService.addShortcut(key, action);
    });

    // Foco inicial
    if (focusOnMount && elementRef.current) {
      navigationService.setFocus(elementRef.current);
    }

    // Estado inicial
    setCurrentFocus(navigationService.getCurrentFocus());
    setNavigationMode(navigationService.getNavigationMode());

    return () => {
      navigationService.off('focus-change', handleFocusChange);
      navigationService.off('navigation-mode-change', handleModeChange);
      navigationService.off('element-activated', handleElementActivated);

      // Remover atalhos personalizados
      Object.keys(shortcuts).forEach(key => {
        navigationService.removeShortcut(key);
      });

      // Restaurar foco se necessário
      if (restoreFocus && currentFocus) {
        navigationService.setFocus(currentFocus);
      }
    };
  }, []);

  const setFocus = (element) => {
    navigationService.setFocus(element);
  };

  const navigateNext = () => {
    navigationService.navigateNext();
  };

  const navigatePrevious = () => {
    navigationService.navigatePrevious();
  };

  const navigateUp = () => {
    navigationService.navigateUp();
  };

  const navigateDown = () => {
    navigationService.navigateDown();
  };

  const navigateLeft = () => {
    navigationService.navigateLeft();
  };

  const navigateRight = () => {
    navigationService.navigateRight();
  };

  return {
    elementRef,
    currentFocus,
    navigationMode,
    setFocus,
    navigateNext,
    navigatePrevious,
    navigateUp,
    navigateDown,
    navigateLeft,
    navigateRight,
    isKeyboardMode: navigationMode === 'keyboard',
    isMouseMode: navigationMode === 'mouse',
    isRemoteMode: navigationMode === 'remote'
  };
};

/**
 * Hook para elementos focáveis
 */
export const useFocusable = (options = {}) => {
  const {
    autoFocus = false,
    onFocus = null,
    onBlur = null,
    onActivate = null,
    disabled = false
  } = options;

  const elementRef = useRef(null);
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    const element = elementRef.current;
    if (!element || disabled) return;

    // Adicionar classes necessárias
    element.classList.add('focusable');
    if (!element.hasAttribute('tabindex')) {
      element.setAttribute('tabindex', '0');
    }

    // Auto focus se solicitado
    if (autoFocus) {
      navigationService.setFocus(element);
    }

    // Listeners de foco
    const handleFocus = () => {
      setIsFocused(true);
      if (onFocus) onFocus();
    };

    const handleBlur = () => {
      setIsFocused(false);
      if (onBlur) onBlur();
    };

    const handleClick = () => {
      if (onActivate) onActivate();
    };

    const handleKeyDown = (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        if (onActivate) onActivate();
      }
    };

    element.addEventListener('focus', handleFocus);
    element.addEventListener('blur', handleBlur);
    element.addEventListener('click', handleClick);
    element.addEventListener('keydown', handleKeyDown);

    return () => {
      element.removeEventListener('focus', handleFocus);
      element.removeEventListener('blur', handleBlur);
      element.removeEventListener('click', handleClick);
      element.removeEventListener('keydown', handleKeyDown);
      
      element.classList.remove('focusable');
    };
  }, [disabled, autoFocus, onFocus, onBlur, onActivate]);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    if (disabled) {
      element.classList.add('disabled');
      element.setAttribute('aria-disabled', 'true');
    } else {
      element.classList.remove('disabled');
      element.removeAttribute('aria-disabled');
    }
  }, [disabled]);

  return {
    elementRef,
    isFocused,
    focus: () => {
      if (elementRef.current && !disabled) {
        navigationService.setFocus(elementRef.current);
      }
    }
  };
};

/**
 * Hook para atalhos de teclado
 */
export const useShortcuts = (shortcuts) => {
  useEffect(() => {
    // Adicionar atalhos
    Object.entries(shortcuts).forEach(([key, action]) => {
      navigationService.addShortcut(key, action);
    });

    return () => {
      // Remover atalhos
      Object.keys(shortcuts).forEach(key => {
        navigationService.removeShortcut(key);
      });
    };
  }, [shortcuts]);
};

/**
 * Hook para navegação direcional em grids
 */
export const useGridNavigation = (options = {}) => {
  const {
    columns = 1,
    rows = null,
    wrap = true,
    onNavigate = null
  } = options;

  const gridRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const navigateInGrid = (direction) => {
    const grid = gridRef.current;
    if (!grid) return;

    const items = Array.from(grid.children);
    const totalItems = items.length;
    
    if (totalItems === 0) return;

    let newIndex = currentIndex;

    switch (direction) {
      case 'up':
        newIndex = currentIndex - columns;
        if (newIndex < 0 && wrap) {
          newIndex = Math.floor((totalItems - 1) / columns) * columns + (currentIndex % columns);
          if (newIndex >= totalItems) {
            newIndex -= columns;
          }
        }
        break;

      case 'down':
        newIndex = currentIndex + columns;
        if (newIndex >= totalItems && wrap) {
          newIndex = currentIndex % columns;
        }
        break;

      case 'left':
        if (currentIndex % columns === 0 && wrap) {
          newIndex = Math.min(currentIndex + columns - 1, totalItems - 1);
        } else {
          newIndex = currentIndex - 1;
        }
        break;

      case 'right':
        if ((currentIndex + 1) % columns === 0 && wrap) {
          newIndex = currentIndex - (columns - 1);
        } else {
          newIndex = Math.min(currentIndex + 1, totalItems - 1);
        }
        break;
    }

    if (newIndex >= 0 && newIndex < totalItems && newIndex !== currentIndex) {
      setCurrentIndex(newIndex);
      navigationService.setFocus(items[newIndex]);
      
      if (onNavigate) {
        onNavigate(newIndex, items[newIndex]);
      }
    }
  };

  useShortcuts({
    'ArrowUp': () => navigateInGrid('up'),
    'ArrowDown': () => navigateInGrid('down'),
    'ArrowLeft': () => navigateInGrid('left'),
    'ArrowRight': () => navigateInGrid('right')
  });

  return {
    gridRef,
    currentIndex,
    setCurrentIndex,
    navigateInGrid
  };
};

export default useNavigation;

