import React, { createContext, useContext, useReducer, useRef } from 'react';

// Estado inicial do player
const initialState = {
  isPlaying: false,
  isPaused: false,
  isMuted: false,
  isFullscreen: false,
  volume: 50,
  currentTime: 0,
  duration: 0,
  progress: 0,
  buffered: 0,
  quality: 'auto',
  availableQualities: [],
  subtitles: [],
  currentSubtitle: null,
  audioTracks: [],
  currentAudioTrack: null,
  playbackRate: 1,
  error: null,
  loading: false,
  currentContent: null,
  playlist: [],
  currentIndex: 0
};

// Tipos de ações do player
const PlayerActionTypes = {
  SET_PLAYING: 'SET_PLAYING',
  SET_PAUSED: 'SET_PAUSED',
  SET_MUTED: 'SET_MUTED',
  SET_FULLSCREEN: 'SET_FULLSCREEN',
  SET_VOLUME: 'SET_VOLUME',
  SET_CURRENT_TIME: 'SET_CURRENT_TIME',
  SET_DURATION: 'SET_DURATION',
  SET_PROGRESS: 'SET_PROGRESS',
  SET_BUFFERED: 'SET_BUFFERED',
  SET_QUALITY: 'SET_QUALITY',
  SET_AVAILABLE_QUALITIES: 'SET_AVAILABLE_QUALITIES',
  SET_SUBTITLES: 'SET_SUBTITLES',
  SET_CURRENT_SUBTITLE: 'SET_CURRENT_SUBTITLE',
  SET_AUDIO_TRACKS: 'SET_AUDIO_TRACKS',
  SET_CURRENT_AUDIO_TRACK: 'SET_CURRENT_AUDIO_TRACK',
  SET_PLAYBACK_RATE: 'SET_PLAYBACK_RATE',
  SET_ERROR: 'SET_ERROR',
  CLEAR_ERROR: 'CLEAR_ERROR',
  SET_LOADING: 'SET_LOADING',
  SET_CURRENT_CONTENT: 'SET_CURRENT_CONTENT',
  SET_PLAYLIST: 'SET_PLAYLIST',
  SET_CURRENT_INDEX: 'SET_CURRENT_INDEX',
  RESET_PLAYER: 'RESET_PLAYER'
};

// Reducer do player
function playerReducer(state, action) {
  switch (action.type) {
    case PlayerActionTypes.SET_PLAYING:
      return { ...state, isPlaying: action.payload, isPaused: !action.payload };
    
    case PlayerActionTypes.SET_PAUSED:
      return { ...state, isPaused: action.payload, isPlaying: !action.payload };
    
    case PlayerActionTypes.SET_MUTED:
      return { ...state, isMuted: action.payload };
    
    case PlayerActionTypes.SET_FULLSCREEN:
      return { ...state, isFullscreen: action.payload };
    
    case PlayerActionTypes.SET_VOLUME:
      return { ...state, volume: Math.max(0, Math.min(100, action.payload)) };
    
    case PlayerActionTypes.SET_CURRENT_TIME:
      const currentTime = action.payload;
      const progress = state.duration > 0 ? (currentTime / state.duration) * 100 : 0;
      return { ...state, currentTime, progress };
    
    case PlayerActionTypes.SET_DURATION:
      return { ...state, duration: action.payload };
    
    case PlayerActionTypes.SET_PROGRESS:
      return { ...state, progress: Math.max(0, Math.min(100, action.payload)) };
    
    case PlayerActionTypes.SET_BUFFERED:
      return { ...state, buffered: Math.max(0, Math.min(100, action.payload)) };
    
    case PlayerActionTypes.SET_QUALITY:
      return { ...state, quality: action.payload };
    
    case PlayerActionTypes.SET_AVAILABLE_QUALITIES:
      return { ...state, availableQualities: action.payload };
    
    case PlayerActionTypes.SET_SUBTITLES:
      return { ...state, subtitles: action.payload };
    
    case PlayerActionTypes.SET_CURRENT_SUBTITLE:
      return { ...state, currentSubtitle: action.payload };
    
    case PlayerActionTypes.SET_AUDIO_TRACKS:
      return { ...state, audioTracks: action.payload };
    
    case PlayerActionTypes.SET_CURRENT_AUDIO_TRACK:
      return { ...state, currentAudioTrack: action.payload };
    
    case PlayerActionTypes.SET_PLAYBACK_RATE:
      return { ...state, playbackRate: action.payload };
    
    case PlayerActionTypes.SET_ERROR:
      return { ...state, error: action.payload, loading: false };
    
    case PlayerActionTypes.CLEAR_ERROR:
      return { ...state, error: null };
    
    case PlayerActionTypes.SET_LOADING:
      return { ...state, loading: action.payload };
    
    case PlayerActionTypes.SET_CURRENT_CONTENT:
      return { ...state, currentContent: action.payload };
    
    case PlayerActionTypes.SET_PLAYLIST:
      return { ...state, playlist: action.payload };
    
    case PlayerActionTypes.SET_CURRENT_INDEX:
      return { ...state, currentIndex: action.payload };
    
    case PlayerActionTypes.RESET_PLAYER:
      return {
        ...initialState,
        volume: state.volume, // Manter volume
        isMuted: state.isMuted // Manter estado de mute
      };
    
    default:
      return state;
  }
}

// Criar contexto
const PlayerContext = createContext();

// Provider do contexto
export function PlayerProvider({ children }) {
  const [state, dispatch] = useReducer(playerReducer, initialState);
  const playerRef = useRef(null);
  const videoRef = useRef(null);

  // Actions do player
  const actions = {
    // Controles básicos
    play: () => {
      if (videoRef.current) {
        videoRef.current.play();
        dispatch({ type: PlayerActionTypes.SET_PLAYING, payload: true });
      }
    },

    pause: () => {
      if (videoRef.current) {
        videoRef.current.pause();
        dispatch({ type: PlayerActionTypes.SET_PAUSED, payload: true });
      }
    },

    togglePlayPause: () => {
      if (state.isPlaying) {
        actions.pause();
      } else {
        actions.play();
      }
    },

    stop: () => {
      if (videoRef.current) {
        videoRef.current.pause();
        videoRef.current.currentTime = 0;
        dispatch({ type: PlayerActionTypes.SET_PLAYING, payload: false });
        dispatch({ type: PlayerActionTypes.SET_CURRENT_TIME, payload: 0 });
      }
    },

    // Controles de volume
    setVolume: (volume) => {
      if (videoRef.current) {
        const normalizedVolume = Math.max(0, Math.min(100, volume));
        videoRef.current.volume = normalizedVolume / 100;
        dispatch({ type: PlayerActionTypes.SET_VOLUME, payload: normalizedVolume });
        
        // Desmute automaticamente se volume > 0
        if (normalizedVolume > 0 && state.isMuted) {
          actions.unmute();
        }
      }
    },

    mute: () => {
      if (videoRef.current) {
        videoRef.current.muted = true;
        dispatch({ type: PlayerActionTypes.SET_MUTED, payload: true });
      }
    },

    unmute: () => {
      if (videoRef.current) {
        videoRef.current.muted = false;
        dispatch({ type: PlayerActionTypes.SET_MUTED, payload: false });
      }
    },

    toggleMute: () => {
      if (state.isMuted) {
        actions.unmute();
      } else {
        actions.mute();
      }
    },

    // Controles de tempo
    seek: (time) => {
      if (videoRef.current && state.duration > 0) {
        const seekTime = Math.max(0, Math.min(state.duration, time));
        videoRef.current.currentTime = seekTime;
        dispatch({ type: PlayerActionTypes.SET_CURRENT_TIME, payload: seekTime });
      }
    },

    seekToProgress: (progress) => {
      if (state.duration > 0) {
        const time = (progress / 100) * state.duration;
        actions.seek(time);
      }
    },

    // Controles de tela cheia
    enterFullscreen: async () => {
      try {
        if (playerRef.current && playerRef.current.requestFullscreen) {
          await playerRef.current.requestFullscreen();
          dispatch({ type: PlayerActionTypes.SET_FULLSCREEN, payload: true });
        } else if (window.electronAPI) {
          // Usar API do Electron para tela cheia
          await window.electronAPI.windowFullscreen();
          dispatch({ type: PlayerActionTypes.SET_FULLSCREEN, payload: true });
        }
      } catch (error) {
        console.error('Erro ao entrar em tela cheia:', error);
      }
    },

    exitFullscreen: async () => {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
          dispatch({ type: PlayerActionTypes.SET_FULLSCREEN, payload: false });
        } else if (window.electronAPI) {
          // Usar API do Electron para sair da tela cheia
          await window.electronAPI.windowFullscreen();
          dispatch({ type: PlayerActionTypes.SET_FULLSCREEN, payload: false });
        }
      } catch (error) {
        console.error('Erro ao sair da tela cheia:', error);
      }
    },

    toggleFullscreen: () => {
      if (state.isFullscreen) {
        actions.exitFullscreen();
      } else {
        actions.enterFullscreen();
      }
    },

    // Controles de qualidade e faixas
    setQuality: (quality) => {
      dispatch({ type: PlayerActionTypes.SET_QUALITY, payload: quality });
      // Implementar mudança de qualidade no player real
    },

    setSubtitle: (subtitle) => {
      dispatch({ type: PlayerActionTypes.SET_CURRENT_SUBTITLE, payload: subtitle });
      // Implementar mudança de legenda no player real
    },

    setAudioTrack: (track) => {
      dispatch({ type: PlayerActionTypes.SET_CURRENT_AUDIO_TRACK, payload: track });
      // Implementar mudança de faixa de áudio no player real
    },

    setPlaybackRate: (rate) => {
      if (videoRef.current) {
        videoRef.current.playbackRate = rate;
        dispatch({ type: PlayerActionTypes.SET_PLAYBACK_RATE, payload: rate });
      }
    },

    // Controles de conteúdo
    loadContent: (content) => {
      dispatch({ type: PlayerActionTypes.SET_LOADING, payload: true });
      dispatch({ type: PlayerActionTypes.SET_CURRENT_CONTENT, payload: content });
      dispatch({ type: PlayerActionTypes.CLEAR_ERROR });
      
      if (videoRef.current && content.url) {
        videoRef.current.src = content.url;
        videoRef.current.load();
      }
    },

    // Controles de playlist
    setPlaylist: (playlist, startIndex = 0) => {
      dispatch({ type: PlayerActionTypes.SET_PLAYLIST, payload: playlist });
      dispatch({ type: PlayerActionTypes.SET_CURRENT_INDEX, payload: startIndex });
      
      if (playlist.length > startIndex) {
        actions.loadContent(playlist[startIndex]);
      }
    },

    playNext: () => {
      const nextIndex = state.currentIndex + 1;
      if (nextIndex < state.playlist.length) {
        dispatch({ type: PlayerActionTypes.SET_CURRENT_INDEX, payload: nextIndex });
        actions.loadContent(state.playlist[nextIndex]);
      }
    },

    playPrevious: () => {
      const prevIndex = state.currentIndex - 1;
      if (prevIndex >= 0) {
        dispatch({ type: PlayerActionTypes.SET_CURRENT_INDEX, payload: prevIndex });
        actions.loadContent(state.playlist[prevIndex]);
      }
    },

    // Utilitários
    setError: (error) => dispatch({ type: PlayerActionTypes.SET_ERROR, payload: error }),
    clearError: () => dispatch({ type: PlayerActionTypes.CLEAR_ERROR }),
    setLoading: (loading) => dispatch({ type: PlayerActionTypes.SET_LOADING, payload: loading }),
    resetPlayer: () => dispatch({ type: PlayerActionTypes.RESET_PLAYER }),

    // Refs
    setPlayerRef: (ref) => { playerRef.current = ref; },
    setVideoRef: (ref) => { videoRef.current = ref; }
  };

  const value = {
    ...state,
    ...actions,
    playerRef,
    videoRef
  };

  return (
    <PlayerContext.Provider value={value}>
      {children}
    </PlayerContext.Provider>
  );
}

// Hook para usar o contexto
export function usePlayer() {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayer deve ser usado dentro de um PlayerProvider');
  }
  return context;
}

export { PlayerActionTypes };

