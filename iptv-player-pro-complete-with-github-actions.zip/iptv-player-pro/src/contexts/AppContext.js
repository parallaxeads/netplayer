import React, { createContext, useContext, useReducer, useEffect } from 'react';

// Estado inicial da aplicação
const initialState = {
  user: null,
  isAuthenticated: false,
  serverConfig: null,
  channels: [],
  categories: [],
  movies: [],
  series: [],
  favorites: [],
  watchHistory: [],
  currentContent: null,
  loading: false,
  error: null,
  notifications: [],
  settings: {
    theme: 'dark',
    language: 'pt-BR',
    autoplay: true,
    quality: 'auto',
    parentalControl: false,
    parentalPin: null
  }
};

// Tipos de ações
const ActionTypes = {
  SET_LOADING: 'SET_LOADING',
  SET_ERROR: 'SET_ERROR',
  CLEAR_ERROR: 'CLEAR_ERROR',
  SET_USER: 'SET_USER',
  SET_AUTHENTICATED: 'SET_AUTHENTICATED',
  SET_SERVER_CONFIG: 'SET_SERVER_CONFIG',
  SET_CHANNELS: 'SET_CHANNELS',
  SET_CATEGORIES: 'SET_CATEGORIES',
  SET_MOVIES: 'SET_MOVIES',
  SET_SERIES: 'SET_SERIES',
  SET_FAVORITES: 'SET_FAVORITES',
  ADD_FAVORITE: 'ADD_FAVORITE',
  REMOVE_FAVORITE: 'REMOVE_FAVORITE',
  SET_WATCH_HISTORY: 'SET_WATCH_HISTORY',
  ADD_TO_HISTORY: 'ADD_TO_HISTORY',
  SET_CURRENT_CONTENT: 'SET_CURRENT_CONTENT',
  UPDATE_SETTINGS: 'UPDATE_SETTINGS',
  ADD_NOTIFICATION: 'ADD_NOTIFICATION',
  REMOVE_NOTIFICATION: 'REMOVE_NOTIFICATION',
  LOGOUT: 'LOGOUT'
};

// Reducer da aplicação
function appReducer(state, action) {
  switch (action.type) {
    case ActionTypes.SET_LOADING:
      return { ...state, loading: action.payload };
    
    case ActionTypes.SET_ERROR:
      return { ...state, error: action.payload, loading: false };
    
    case ActionTypes.CLEAR_ERROR:
      return { ...state, error: null };
    
    case ActionTypes.SET_USER:
      return { ...state, user: action.payload };
    
    case ActionTypes.SET_AUTHENTICATED:
      return { ...state, isAuthenticated: action.payload };
    
    case ActionTypes.SET_SERVER_CONFIG:
      return { ...state, serverConfig: action.payload };
    
    case ActionTypes.SET_CHANNELS:
      return { ...state, channels: action.payload };
    
    case ActionTypes.SET_CATEGORIES:
      return { ...state, categories: action.payload };
    
    case ActionTypes.SET_MOVIES:
      return { ...state, movies: action.payload };
    
    case ActionTypes.SET_SERIES:
      return { ...state, series: action.payload };
    
    case ActionTypes.SET_FAVORITES:
      return { ...state, favorites: action.payload };
    
    case ActionTypes.ADD_FAVORITE:
      return { 
        ...state, 
        favorites: [...state.favorites, action.payload] 
      };
    
    case ActionTypes.REMOVE_FAVORITE:
      return { 
        ...state, 
        favorites: state.favorites.filter(item => item.id !== action.payload) 
      };
    
    case ActionTypes.SET_WATCH_HISTORY:
      return { ...state, watchHistory: action.payload };
    
    case ActionTypes.ADD_TO_HISTORY:
      const existingIndex = state.watchHistory.findIndex(
        item => item.id === action.payload.id
      );
      
      let newHistory;
      if (existingIndex >= 0) {
        // Atualizar item existente
        newHistory = [...state.watchHistory];
        newHistory[existingIndex] = { 
          ...action.payload, 
          lastWatched: new Date().toISOString() 
        };
      } else {
        // Adicionar novo item
        newHistory = [
          { ...action.payload, lastWatched: new Date().toISOString() },
          ...state.watchHistory.slice(0, 49) // Manter apenas 50 itens
        ];
      }
      
      return { ...state, watchHistory: newHistory };
    
    case ActionTypes.SET_CURRENT_CONTENT:
      return { ...state, currentContent: action.payload };
    
    case ActionTypes.UPDATE_SETTINGS:
      return { 
        ...state, 
        settings: { ...state.settings, ...action.payload } 
      };
    
    case ActionTypes.ADD_NOTIFICATION:
      return { 
        ...state, 
        notifications: [...state.notifications, action.payload] 
      };
    
    case ActionTypes.REMOVE_NOTIFICATION:
      return { 
        ...state, 
        notifications: state.notifications.filter(n => n.id !== action.payload) 
      };
    
    case ActionTypes.LOGOUT:
      return {
        ...initialState,
        settings: state.settings // Manter configurações
      };
    
    default:
      return state;
  }
}

// Criar contexto
const AppContext = createContext();

// Provider do contexto
export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Carregar dados persistidos ao inicializar
  useEffect(() => {
    loadPersistedData();
  }, []);

  // Salvar dados importantes quando mudarem
  useEffect(() => {
    savePersistedData();
  }, [state.favorites, state.watchHistory, state.settings]);

  const loadPersistedData = async () => {
    try {
      // Carregar dados do localStorage (temporário, depois será SQLite)
      const savedFavorites = localStorage.getItem('iptv_favorites');
      const savedHistory = localStorage.getItem('iptv_history');
      const savedSettings = localStorage.getItem('iptv_settings');

      if (savedFavorites) {
        dispatch({ type: ActionTypes.SET_FAVORITES, payload: JSON.parse(savedFavorites) });
      }

      if (savedHistory) {
        dispatch({ type: ActionTypes.SET_WATCH_HISTORY, payload: JSON.parse(savedHistory) });
      }

      if (savedSettings) {
        dispatch({ type: ActionTypes.UPDATE_SETTINGS, payload: JSON.parse(savedSettings) });
      }
    } catch (error) {
      console.error('Erro ao carregar dados persistidos:', error);
    }
  };

  const savePersistedData = () => {
    try {
      localStorage.setItem('iptv_favorites', JSON.stringify(state.favorites));
      localStorage.setItem('iptv_history', JSON.stringify(state.watchHistory));
      localStorage.setItem('iptv_settings', JSON.stringify(state.settings));
    } catch (error) {
      console.error('Erro ao salvar dados:', error);
    }
  };

  // Actions
  const actions = {
    setLoading: (loading) => dispatch({ type: ActionTypes.SET_LOADING, payload: loading }),
    setError: (error) => dispatch({ type: ActionTypes.SET_ERROR, payload: error }),
    clearError: () => dispatch({ type: ActionTypes.CLEAR_ERROR }),
    setUser: (user) => dispatch({ type: ActionTypes.SET_USER, payload: user }),
    setAuthenticated: (auth) => dispatch({ type: ActionTypes.SET_AUTHENTICATED, payload: auth }),
    setServerConfig: (config) => dispatch({ type: ActionTypes.SET_SERVER_CONFIG, payload: config }),
    setChannels: (channels) => dispatch({ type: ActionTypes.SET_CHANNELS, payload: channels }),
    setCategories: (categories) => dispatch({ type: ActionTypes.SET_CATEGORIES, payload: categories }),
    setMovies: (movies) => dispatch({ type: ActionTypes.SET_MOVIES, payload: movies }),
    setSeries: (series) => dispatch({ type: ActionTypes.SET_SERIES, payload: series }),
    addFavorite: (item) => dispatch({ type: ActionTypes.ADD_FAVORITE, payload: item }),
    removeFavorite: (id) => dispatch({ type: ActionTypes.REMOVE_FAVORITE, payload: id }),
    addToHistory: (item) => dispatch({ type: ActionTypes.ADD_TO_HISTORY, payload: item }),
    setCurrentContent: (content) => dispatch({ type: ActionTypes.SET_CURRENT_CONTENT, payload: content }),
    updateSettings: (settings) => dispatch({ type: ActionTypes.UPDATE_SETTINGS, payload: settings }),
    addNotification: (notification) => {
      const id = Date.now().toString();
      dispatch({ 
        type: ActionTypes.ADD_NOTIFICATION, 
        payload: { ...notification, id } 
      });
      
      // Auto-remover notificação após 5 segundos
      setTimeout(() => {
        dispatch({ type: ActionTypes.REMOVE_NOTIFICATION, payload: id });
      }, 5000);
    },
    removeNotification: (id) => dispatch({ type: ActionTypes.REMOVE_NOTIFICATION, payload: id }),
    logout: () => dispatch({ type: ActionTypes.LOGOUT })
  };

  const value = {
    ...state,
    ...actions
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

// Hook para usar o contexto
export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp deve ser usado dentro de um AppProvider');
  }
  return context;
}

export { ActionTypes };

