import React, { useState, useEffect } from 'react';
import './index.css';

// Componentes principais
import LoginScreen from './components/LoginScreen';
import MainScreen from './components/MainScreen';
import PlayerScreen from './components/PlayerScreen';
import SettingsScreen from './components/SettingsScreen';
import LoadingScreen from './components/LoadingScreen';

// Contextos
import { AppProvider } from './contexts/AppContext';
import { PlayerProvider } from './contexts/PlayerContext';

// Serviços
import authService from './services/authService';
import databaseService from './services/databaseService';

function App() {
  const [currentScreen, setCurrentScreen] = useState('loading');
  const [user, setUser] = useState(null);
  const [currentContent, setCurrentContent] = useState(null);
  const [appVersion, setAppVersion] = useState('1.0.0');
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Inicializar aplicação
    initializeApp();
    
    // Configurar listeners do Electron
    setupElectronListeners();
    
    // Cleanup
    return () => {
      cleanupElectronListeners();
    };
  }, []);

  const initializeApp = async () => {
    try {
      // Verificar se estamos no Electron
      if (window.electronAPI) {
        const version = await window.electronAPI.getAppVersion();
        setAppVersion(version);
      }

      // Inicializar banco de dados
      await databaseService.initialize();

      // Tentar restaurar sessão salva
      const sessionRestored = await authService.restoreSession();
      
      if (sessionRestored) {
        const currentUser = authService.getCurrentUser();
        setUser(currentUser);
        setCurrentScreen('main');
      } else {
        setCurrentScreen('login');
      }

    } catch (error) {
      console.error('Erro ao inicializar aplicação:', error);
      setCurrentScreen('login');
    } finally {
      setIsInitialized(true);
    }
  };

  const setupElectronListeners = () => {
    if (window.electronAPI) {
      // Listener para abrir configurações
      window.electronAPI.onOpenSettings(() => {
        setCurrentScreen('settings');
      });

      // Listeners para controles do player
      window.electronAPI.onPlayerToggle(() => {
        // Será implementado quando o player estiver pronto
        console.log('Toggle player');
      });

      window.electronAPI.onPlayerStop(() => {
        // Será implementado quando o player estiver pronto
        console.log('Stop player');
      });

      window.electronAPI.onPlayerVolumeUp(() => {
        // Será implementado quando o player estiver pronto
        console.log('Volume up');
      });

      window.electronAPI.onPlayerVolumeDown(() => {
        // Será implementado quando o player estiver pronto
        console.log('Volume down');
      });
    }
  };

  const cleanupElectronListeners = () => {
    if (window.electronAPI) {
      window.electronAPI.removeAllListeners('open-settings');
      window.electronAPI.removeAllListeners('player-toggle');
      window.electronAPI.removeAllListeners('player-stop');
      window.electronAPI.removeAllListeners('player-volume-up');
      window.electronAPI.removeAllListeners('player-volume-down');
    }
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setCurrentScreen('main');
  };

  const handleLogout = async () => {
    try {
      await authService.logout();
      setUser(null);
      setCurrentScreen('login');
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    }
  };

  const handlePlayContent = (content) => {
    setCurrentContent(content);
    setCurrentScreen('player');
  };

  const handleBackToMain = () => {
    setCurrentScreen('main');
  };

  const handleOpenSettings = () => {
    setCurrentScreen('settings');
  };

  const handleCloseSettings = () => {
    setCurrentScreen('main');
  };

  const renderCurrentScreen = () => {
    // Mostrar loading enquanto inicializa
    if (!isInitialized) {
      return <LoadingScreen />;
    }

    switch (currentScreen) {
      case 'loading':
        return <LoadingScreen />;
      
      case 'login':
        return (
          <LoginScreen 
            onLogin={handleLogin}
            appVersion={appVersion}
          />
        );
      
      case 'main':
        return (
          <MainScreen 
            user={user}
            onPlayContent={handlePlayContent}
            onOpenSettings={handleOpenSettings}
            onLogout={handleLogout}
          />
        );
      
      case 'player':
        return (
          <PlayerScreen 
            user={user}
            content={currentContent}
            onBack={handleBackToMain}
          />
        );
      
      case 'settings':
        return (
          <SettingsScreen 
            user={user}
            onClose={handleCloseSettings}
            onLogout={handleLogout}
          />
        );
      
      default:
        return <LoadingScreen />;
    }
  };

  return (
    <AppProvider>
      <PlayerProvider>
        <div className="App min-h-screen bg-netflix-black text-white overflow-hidden">
          {renderCurrentScreen()}
        </div>
      </PlayerProvider>
    </AppProvider>
  );
}

export default App;

