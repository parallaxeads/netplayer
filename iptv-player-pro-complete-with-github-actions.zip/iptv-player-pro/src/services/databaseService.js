/**
 * Serviço de banco de dados local usando SQLite
 * Gerencia persistência de dados do usuário, favoritos, histórico e configurações
 */
class DatabaseService {
  constructor() {
    this.db = null;
    this.isInitialized = false;
  }

  /**
   * Inicializa o banco de dados SQLite
   * @returns {Promise<void>}
   */
  async initialize() {
    if (this.isInitialized) {
      return;
    }

    try {
      // No ambiente Electron, usar better-sqlite3
      if (window.electronAPI && window.databaseAPI) {
        this.db = await window.databaseAPI.initialize();
      } else {
        // Fallback para localStorage no navegador
        this.db = {
          type: 'localStorage',
          storage: localStorage
        };
      }

      await this.createTables();
      this.isInitialized = true;
    } catch (error) {
      console.error('Erro ao inicializar banco de dados:', error);
      throw error;
    }
  }

  /**
   * Cria as tabelas necessárias
   * @private
   */
  async createTables() {
    if (this.db.type === 'localStorage') {
      // Para localStorage, não precisamos criar tabelas
      return;
    }

    // SQL para criar tabelas (será implementado quando integrarmos better-sqlite3)
    const tables = [
      `CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_data TEXT NOT NULL,
        session_token TEXT NOT NULL,
        login_method TEXT NOT NULL,
        password TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        content_id TEXT NOT NULL,
        content_type TEXT NOT NULL,
        content_data TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, content_id, content_type)
      )`,
      
      `CREATE TABLE IF NOT EXISTS watch_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        content_id TEXT NOT NULL,
        content_type TEXT NOT NULL,
        content_data TEXT NOT NULL,
        watch_position INTEGER DEFAULT 0,
        watch_duration INTEGER DEFAULT 0,
        last_watched DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        settings_data TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id)
      )`
    ];

    // Executar criação das tabelas (implementar quando integrar SQLite)
    for (const sql of tables) {
      // await this.db.exec(sql);
    }
  }

  /**
   * Salva sessão do usuário
   * @param {Object} sessionData - Dados da sessão
   */
  async saveSession(sessionData) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const data = {
          ...sessionData,
          savedAt: new Date().toISOString()
        };
        this.db.storage.setItem('iptv_session', JSON.stringify(data));
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   INSERT OR REPLACE INTO sessions 
        //   (user_data, session_token, login_method, password, updated_at)
        //   VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        // `);
        // stmt.run(
        //   JSON.stringify(sessionData.user),
        //   sessionData.sessionToken,
        //   sessionData.loginMethod,
        //   sessionData.password
        // );
      }
    } catch (error) {
      console.error('Erro ao salvar sessão:', error);
      throw error;
    }
  }

  /**
   * Recupera sessão salva
   * @returns {Promise<Object|null>} Dados da sessão
   */
  async getSession() {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const data = this.db.storage.getItem('iptv_session');
        return data ? JSON.parse(data) : null;
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   SELECT * FROM sessions ORDER BY updated_at DESC LIMIT 1
        // `);
        // const row = stmt.get();
        // 
        // if (row) {
        //   return {
        //     user: JSON.parse(row.user_data),
        //     sessionToken: row.session_token,
        //     loginMethod: row.login_method,
        //     password: row.password,
        //     savedAt: row.updated_at
        //   };
        // }
        return null;
      }
    } catch (error) {
      console.error('Erro ao recuperar sessão:', error);
      return null;
    }
  }

  /**
   * Limpa sessão salva
   */
  async clearSession() {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        this.db.storage.removeItem('iptv_session');
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare('DELETE FROM sessions');
        // stmt.run();
      }
    } catch (error) {
      console.error('Erro ao limpar sessão:', error);
    }
  }

  /**
   * Salva item nos favoritos
   * @param {string} userId - ID do usuário
   * @param {Object} content - Conteúdo a ser favoritado
   */
  async addFavorite(userId, content) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_favorites_${userId}`;
        const favorites = this.getFavoritesFromStorage(key);
        
        // Verificar se já existe
        const exists = favorites.some(fav => 
          fav.id === content.id && fav.type === content.type
        );
        
        if (!exists) {
          favorites.push({
            ...content,
            addedAt: new Date().toISOString()
          });
          this.db.storage.setItem(key, JSON.stringify(favorites));
        }
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   INSERT OR IGNORE INTO favorites 
        //   (user_id, content_id, content_type, content_data)
        //   VALUES (?, ?, ?, ?)
        // `);
        // stmt.run(userId, content.id, content.type, JSON.stringify(content));
      }
    } catch (error) {
      console.error('Erro ao adicionar favorito:', error);
      throw error;
    }
  }

  /**
   * Remove item dos favoritos
   * @param {string} userId - ID do usuário
   * @param {string} contentId - ID do conteúdo
   * @param {string} contentType - Tipo do conteúdo
   */
  async removeFavorite(userId, contentId, contentType) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_favorites_${userId}`;
        const favorites = this.getFavoritesFromStorage(key);
        
        const filtered = favorites.filter(fav => 
          !(fav.id === contentId && fav.type === contentType)
        );
        
        this.db.storage.setItem(key, JSON.stringify(filtered));
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   DELETE FROM favorites 
        //   WHERE user_id = ? AND content_id = ? AND content_type = ?
        // `);
        // stmt.run(userId, contentId, contentType);
      }
    } catch (error) {
      console.error('Erro ao remover favorito:', error);
      throw error;
    }
  }

  /**
   * Recupera favoritos do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Lista de favoritos
   */
  async getFavorites(userId) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_favorites_${userId}`;
        return this.getFavoritesFromStorage(key);
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   SELECT content_data FROM favorites 
        //   WHERE user_id = ? ORDER BY created_at DESC
        // `);
        // const rows = stmt.all(userId);
        // return rows.map(row => JSON.parse(row.content_data));
        return [];
      }
    } catch (error) {
      console.error('Erro ao recuperar favoritos:', error);
      return [];
    }
  }

  /**
   * Adiciona item ao histórico
   * @param {string} userId - ID do usuário
   * @param {Object} content - Conteúdo assistido
   * @param {number} position - Posição de reprodução
   * @param {number} duration - Duração total
   */
  async addToHistory(userId, content, position = 0, duration = 0) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_history_${userId}`;
        const history = this.getHistoryFromStorage(key);
        
        // Remover item existente se houver
        const filtered = history.filter(item => 
          !(item.id === content.id && item.type === content.type)
        );
        
        // Adicionar no início
        filtered.unshift({
          ...content,
          watchPosition: position,
          watchDuration: duration,
          lastWatched: new Date().toISOString()
        });
        
        // Manter apenas 50 itens
        const limited = filtered.slice(0, 50);
        this.db.storage.setItem(key, JSON.stringify(limited));
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   INSERT OR REPLACE INTO watch_history 
        //   (user_id, content_id, content_type, content_data, watch_position, watch_duration, last_watched)
        //   VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        // `);
        // stmt.run(userId, content.id, content.type, JSON.stringify(content), position, duration);
      }
    } catch (error) {
      console.error('Erro ao adicionar ao histórico:', error);
      throw error;
    }
  }

  /**
   * Recupera histórico do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Lista do histórico
   */
  async getHistory(userId) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_history_${userId}`;
        return this.getHistoryFromStorage(key);
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   SELECT content_data, watch_position, watch_duration, last_watched 
        //   FROM watch_history 
        //   WHERE user_id = ? ORDER BY last_watched DESC LIMIT 50
        // `);
        // const rows = stmt.all(userId);
        // return rows.map(row => ({
        //   ...JSON.parse(row.content_data),
        //   watchPosition: row.watch_position,
        //   watchDuration: row.watch_duration,
        //   lastWatched: row.last_watched
        // }));
        return [];
      }
    } catch (error) {
      console.error('Erro ao recuperar histórico:', error);
      return [];
    }
  }

  /**
   * Salva configurações do usuário
   * @param {string} userId - ID do usuário
   * @param {Object} settings - Configurações
   */
  async saveSettings(userId, settings) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_settings_${userId}`;
        const data = {
          ...settings,
          updatedAt: new Date().toISOString()
        };
        this.db.storage.setItem(key, JSON.stringify(data));
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   INSERT OR REPLACE INTO settings 
        //   (user_id, settings_data, updated_at)
        //   VALUES (?, ?, CURRENT_TIMESTAMP)
        // `);
        // stmt.run(userId, JSON.stringify(settings));
      }
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      throw error;
    }
  }

  /**
   * Recupera configurações do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<Object>} Configurações
   */
  async getSettings(userId) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const key = `iptv_settings_${userId}`;
        const data = this.db.storage.getItem(key);
        return data ? JSON.parse(data) : {};
      } else {
        // Implementar com SQLite
        // const stmt = this.db.prepare(`
        //   SELECT settings_data FROM settings WHERE user_id = ?
        // `);
        // const row = stmt.get(userId);
        // return row ? JSON.parse(row.settings_data) : {};
        return {};
      }
    } catch (error) {
      console.error('Erro ao recuperar configurações:', error);
      return {};
    }
  }

  /**
   * Limpa todos os dados do usuário
   * @param {string} userId - ID do usuário
   */
  async clearUserData(userId) {
    await this.ensureInitialized();

    try {
      if (this.db.type === 'localStorage') {
        const keys = [
          `iptv_favorites_${userId}`,
          `iptv_history_${userId}`,
          `iptv_settings_${userId}`
        ];
        
        keys.forEach(key => {
          this.db.storage.removeItem(key);
        });
      } else {
        // Implementar com SQLite
        // const tables = ['favorites', 'watch_history', 'settings'];
        // for (const table of tables) {
        //   const stmt = this.db.prepare(`DELETE FROM ${table} WHERE user_id = ?`);
        //   stmt.run(userId);
        // }
      }
    } catch (error) {
      console.error('Erro ao limpar dados do usuário:', error);
    }
  }

  /**
   * Utilitário para recuperar favoritos do localStorage
   * @private
   */
  getFavoritesFromStorage(key) {
    try {
      const data = this.db.storage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  /**
   * Utilitário para recuperar histórico do localStorage
   * @private
   */
  getHistoryFromStorage(key) {
    try {
      const data = this.db.storage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  /**
   * Garante que o banco está inicializado
   * @private
   */
  async ensureInitialized() {
    if (!this.isInitialized) {
      await this.initialize();
    }
  }

  /**
   * Fecha conexão com o banco (cleanup)
   */
  async close() {
    if (this.db && this.db.close) {
      this.db.close();
    }
    this.isInitialized = false;
  }
}

// Instância singleton
const databaseService = new DatabaseService();

export default databaseService;

