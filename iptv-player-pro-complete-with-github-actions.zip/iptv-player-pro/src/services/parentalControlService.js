/**
 * Serviço de controle parental
 * Gerencia PIN, bloqueio de conteúdo e restrições
 */
class ParentalControlService {
  constructor() {
    this.isEnabled = false;
    this.pin = null;
    this.isUnlocked = false;
    this.unlockExpiry = null;
    this.unlockDuration = 30 * 60 * 1000; // 30 minutos em ms
    this.maxPinAttempts = 5;
    this.pinAttempts = 0;
    this.lockoutTime = 15 * 60 * 1000; // 15 minutos em ms
    this.lockoutExpiry = null;
    
    this.restrictions = {
      maxRating: 18, // Classificação máxima permitida
      blockedGenres: [], // Gêneros bloqueados
      blockedKeywords: [], // Palavras-chave bloqueadas
      timeRestrictions: {
        enabled: false,
        allowedHours: { start: 6, end: 22 }, // 6h às 22h
        allowedDays: [1, 2, 3, 4, 5, 6, 0] // Todos os dias da semana
      },
      contentTypes: {
        live: true,
        movies: true,
        series: true,
        adult: false
      }
    };

    this.loadSettings();
    this.startUnlockTimer();
  }

  /**
   * Configura o PIN do controle parental
   * @param {string} newPin - Novo PIN (4-6 dígitos)
   * @param {string} currentPin - PIN atual (para validação)
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async setPin(newPin, currentPin = null) {
    try {
      // Validar PIN atual se já existe
      if (this.pin && currentPin) {
        if (!await this.validatePin(currentPin)) {
          throw new Error('PIN atual incorreto');
        }
      }

      // Validar novo PIN
      if (!this.isValidPin(newPin)) {
        throw new Error('PIN deve ter entre 4 e 6 dígitos');
      }

      // Criptografar e salvar PIN
      this.pin = await this.hashPin(newPin);
      this.isEnabled = true;
      this.saveSettings();

      return true;
    } catch (error) {
      console.error('Erro ao definir PIN:', error);
      return false;
    }
  }

  /**
   * Remove o PIN do controle parental
   * @param {string} currentPin - PIN atual para validação
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async removePin(currentPin) {
    try {
      if (!await this.validatePin(currentPin)) {
        throw new Error('PIN incorreto');
      }

      this.pin = null;
      this.isEnabled = false;
      this.isUnlocked = false;
      this.unlockExpiry = null;
      this.resetPinAttempts();
      this.saveSettings();

      return true;
    } catch (error) {
      console.error('Erro ao remover PIN:', error);
      return false;
    }
  }

  /**
   * Valida PIN inserido
   * @param {string} inputPin - PIN inserido pelo usuário
   * @returns {Promise<boolean>} Se o PIN está correto
   */
  async validatePin(inputPin) {
    try {
      // Verificar se está em lockout
      if (this.isInLockout()) {
        throw new Error('Muitas tentativas incorretas. Tente novamente mais tarde.');
      }

      if (!this.pin || !inputPin) {
        return false;
      }

      const hashedInput = await this.hashPin(inputPin);
      const isValid = hashedInput === this.pin;

      if (isValid) {
        this.resetPinAttempts();
        return true;
      } else {
        this.incrementPinAttempts();
        return false;
      }
    } catch (error) {
      console.error('Erro ao validar PIN:', error);
      return false;
    }
  }

  /**
   * Desbloqueia controle parental temporariamente
   * @param {string} pin - PIN para desbloqueio
   * @returns {Promise<boolean>} Sucesso do desbloqueio
   */
  async unlock(pin) {
    try {
      if (!this.isEnabled) {
        return true; // Já desbloqueado se não está habilitado
      }

      if (await this.validatePin(pin)) {
        this.isUnlocked = true;
        this.unlockExpiry = Date.now() + this.unlockDuration;
        return true;
      }

      return false;
    } catch (error) {
      console.error('Erro ao desbloquear:', error);
      return false;
    }
  }

  /**
   * Bloqueia controle parental imediatamente
   */
  lock() {
    this.isUnlocked = false;
    this.unlockExpiry = null;
  }

  /**
   * Verifica se o controle parental está desbloqueado
   * @returns {boolean} Se está desbloqueado
   */
  isCurrentlyUnlocked() {
    if (!this.isEnabled) {
      return true; // Sempre desbloqueado se não está habilitado
    }

    if (!this.isUnlocked) {
      return false;
    }

    // Verificar se o desbloqueio expirou
    if (this.unlockExpiry && Date.now() > this.unlockExpiry) {
      this.lock();
      return false;
    }

    return true;
  }

  /**
   * Verifica se conteúdo é permitido
   * @param {Object} content - Conteúdo a ser verificado
   * @returns {Object} Resultado da verificação
   */
  checkContentAllowed(content) {
    const result = {
      allowed: true,
      reason: null,
      requiresPin: false
    };

    // Se controle parental não está habilitado, permitir tudo
    if (!this.isEnabled) {
      return result;
    }

    // Se está desbloqueado, permitir tudo
    if (this.isCurrentlyUnlocked()) {
      return result;
    }

    // Verificar restrições de horário
    if (!this.isTimeAllowed()) {
      result.allowed = false;
      result.reason = 'Conteúdo não permitido neste horário';
      result.requiresPin = true;
      return result;
    }

    // Verificar tipo de conteúdo
    if (!this.isContentTypeAllowed(content.type)) {
      result.allowed = false;
      result.reason = 'Tipo de conteúdo não permitido';
      result.requiresPin = true;
      return result;
    }

    // Verificar classificação etária
    if (!this.isRatingAllowed(content.rating)) {
      result.allowed = false;
      result.reason = `Classificação ${content.rating}+ não permitida`;
      result.requiresPin = true;
      return result;
    }

    // Verificar gêneros bloqueados
    if (!this.isGenreAllowed(content.genre)) {
      result.allowed = false;
      result.reason = `Gênero "${content.genre}" não permitido`;
      result.requiresPin = true;
      return result;
    }

    // Verificar palavras-chave bloqueadas
    if (!this.isContentSafe(content)) {
      result.allowed = false;
      result.reason = 'Conteúdo contém material restrito';
      result.requiresPin = true;
      return result;
    }

    return result;
  }

  /**
   * Define restrições de classificação etária
   * @param {number} maxRating - Classificação máxima permitida
   */
  setMaxRating(maxRating) {
    this.restrictions.maxRating = maxRating;
    this.saveSettings();
  }

  /**
   * Adiciona gênero à lista de bloqueados
   * @param {string} genre - Gênero a ser bloqueado
   */
  blockGenre(genre) {
    if (!this.restrictions.blockedGenres.includes(genre)) {
      this.restrictions.blockedGenres.push(genre);
      this.saveSettings();
    }
  }

  /**
   * Remove gênero da lista de bloqueados
   * @param {string} genre - Gênero a ser desbloqueado
   */
  unblockGenre(genre) {
    const index = this.restrictions.blockedGenres.indexOf(genre);
    if (index > -1) {
      this.restrictions.blockedGenres.splice(index, 1);
      this.saveSettings();
    }
  }

  /**
   * Adiciona palavra-chave à lista de bloqueadas
   * @param {string} keyword - Palavra-chave a ser bloqueada
   */
  blockKeyword(keyword) {
    const lowerKeyword = keyword.toLowerCase();
    if (!this.restrictions.blockedKeywords.includes(lowerKeyword)) {
      this.restrictions.blockedKeywords.push(lowerKeyword);
      this.saveSettings();
    }
  }

  /**
   * Remove palavra-chave da lista de bloqueadas
   * @param {string} keyword - Palavra-chave a ser desbloqueada
   */
  unblockKeyword(keyword) {
    const lowerKeyword = keyword.toLowerCase();
    const index = this.restrictions.blockedKeywords.indexOf(lowerKeyword);
    if (index > -1) {
      this.restrictions.blockedKeywords.splice(index, 1);
      this.saveSettings();
    }
  }

  /**
   * Configura restrições de horário
   * @param {Object} timeConfig - Configuração de horário
   */
  setTimeRestrictions(timeConfig) {
    this.restrictions.timeRestrictions = {
      ...this.restrictions.timeRestrictions,
      ...timeConfig
    };
    this.saveSettings();
  }

  /**
   * Configura tipos de conteúdo permitidos
   * @param {Object} contentTypes - Tipos de conteúdo
   */
  setContentTypes(contentTypes) {
    this.restrictions.contentTypes = {
      ...this.restrictions.contentTypes,
      ...contentTypes
    };
    this.saveSettings();
  }

  /**
   * Obtém configurações atuais
   * @returns {Object} Configurações do controle parental
   */
  getSettings() {
    return {
      isEnabled: this.isEnabled,
      hasPin: !!this.pin,
      isUnlocked: this.isCurrentlyUnlocked(),
      unlockTimeRemaining: this.getUnlockTimeRemaining(),
      restrictions: { ...this.restrictions },
      isInLockout: this.isInLockout(),
      lockoutTimeRemaining: this.getLockoutTimeRemaining()
    };
  }

  /**
   * Obtém estatísticas de uso
   * @returns {Object} Estatísticas do controle parental
   */
  getUsageStats() {
    const stats = this.loadStats();
    return {
      totalPinAttempts: stats.totalPinAttempts || 0,
      successfulUnlocks: stats.successfulUnlocks || 0,
      blockedAttempts: stats.blockedAttempts || 0,
      lastUnlock: stats.lastUnlock ? new Date(stats.lastUnlock) : null,
      mostBlockedGenre: stats.mostBlockedGenre || null,
      averageUnlockDuration: stats.averageUnlockDuration || 0
    };
  }

  /**
   * Redefine todas as configurações
   * @param {string} currentPin - PIN atual para validação
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async resetSettings(currentPin) {
    try {
      if (this.isEnabled && !await this.validatePin(currentPin)) {
        throw new Error('PIN incorreto');
      }

      this.isEnabled = false;
      this.pin = null;
      this.isUnlocked = false;
      this.unlockExpiry = null;
      this.restrictions = {
        maxRating: 18,
        blockedGenres: [],
        blockedKeywords: [],
        timeRestrictions: {
          enabled: false,
          allowedHours: { start: 6, end: 22 },
          allowedDays: [1, 2, 3, 4, 5, 6, 0]
        },
        contentTypes: {
          live: true,
          movies: true,
          series: true,
          adult: false
        }
      };

      this.resetPinAttempts();
      this.saveSettings();

      return true;
    } catch (error) {
      console.error('Erro ao redefinir configurações:', error);
      return false;
    }
  }

  // Métodos auxiliares privados

  isValidPin(pin) {
    return /^\d{4,6}$/.test(pin);
  }

  async hashPin(pin) {
    // Implementação simples de hash (em produção, usar bcrypt ou similar)
    const encoder = new TextEncoder();
    const data = encoder.encode(pin + 'salt_iptv_player');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  isTimeAllowed() {
    if (!this.restrictions.timeRestrictions.enabled) {
      return true;
    }

    const now = new Date();
    const currentHour = now.getHours();
    const currentDay = now.getDay();

    const { allowedHours, allowedDays } = this.restrictions.timeRestrictions;

    // Verificar dia da semana
    if (!allowedDays.includes(currentDay)) {
      return false;
    }

    // Verificar horário
    if (currentHour < allowedHours.start || currentHour >= allowedHours.end) {
      return false;
    }

    return true;
  }

  isContentTypeAllowed(contentType) {
    return this.restrictions.contentTypes[contentType] !== false;
  }

  isRatingAllowed(rating) {
    if (!rating) return true;
    
    // Extrair número da classificação (ex: "16+" -> 16)
    const numericRating = parseInt(rating.toString().replace(/\D/g, ''));
    return numericRating <= this.restrictions.maxRating;
  }

  isGenreAllowed(genre) {
    if (!genre) return true;
    return !this.restrictions.blockedGenres.some(blocked => 
      genre.toLowerCase().includes(blocked.toLowerCase())
    );
  }

  isContentSafe(content) {
    const searchText = [
      content.name,
      content.title,
      content.description,
      content.keywords
    ].filter(Boolean).join(' ').toLowerCase();

    return !this.restrictions.blockedKeywords.some(keyword =>
      searchText.includes(keyword)
    );
  }

  incrementPinAttempts() {
    this.pinAttempts++;
    if (this.pinAttempts >= this.maxPinAttempts) {
      this.lockoutExpiry = Date.now() + this.lockoutTime;
    }
    this.saveStats({ totalPinAttempts: (this.loadStats().totalPinAttempts || 0) + 1 });
  }

  resetPinAttempts() {
    this.pinAttempts = 0;
    this.lockoutExpiry = null;
  }

  isInLockout() {
    return this.lockoutExpiry && Date.now() < this.lockoutExpiry;
  }

  getLockoutTimeRemaining() {
    if (!this.isInLockout()) return 0;
    return Math.max(0, this.lockoutExpiry - Date.now());
  }

  getUnlockTimeRemaining() {
    if (!this.isUnlocked || !this.unlockExpiry) return 0;
    return Math.max(0, this.unlockExpiry - Date.now());
  }

  startUnlockTimer() {
    setInterval(() => {
      if (this.isUnlocked && this.unlockExpiry && Date.now() > this.unlockExpiry) {
        this.lock();
      }
    }, 60000); // Verificar a cada minuto
  }

  saveSettings() {
    try {
      const settings = {
        isEnabled: this.isEnabled,
        pin: this.pin,
        restrictions: this.restrictions,
        unlockDuration: this.unlockDuration,
        maxPinAttempts: this.maxPinAttempts,
        lockoutTime: this.lockoutTime
      };
      localStorage.setItem('iptv_parental_control', JSON.stringify(settings));
    } catch (error) {
      console.error('Erro ao salvar configurações do controle parental:', error);
    }
  }

  loadSettings() {
    try {
      const saved = localStorage.getItem('iptv_parental_control');
      if (saved) {
        const settings = JSON.parse(saved);
        this.isEnabled = settings.isEnabled || false;
        this.pin = settings.pin || null;
        this.restrictions = { ...this.restrictions, ...settings.restrictions };
        this.unlockDuration = settings.unlockDuration || this.unlockDuration;
        this.maxPinAttempts = settings.maxPinAttempts || this.maxPinAttempts;
        this.lockoutTime = settings.lockoutTime || this.lockoutTime;
      }
    } catch (error) {
      console.error('Erro ao carregar configurações do controle parental:', error);
    }
  }

  saveStats(newStats) {
    try {
      const currentStats = this.loadStats();
      const updatedStats = { ...currentStats, ...newStats };
      localStorage.setItem('iptv_parental_stats', JSON.stringify(updatedStats));
    } catch (error) {
      console.error('Erro ao salvar estatísticas do controle parental:', error);
    }
  }

  loadStats() {
    try {
      const saved = localStorage.getItem('iptv_parental_stats');
      return saved ? JSON.parse(saved) : {};
    } catch (error) {
      console.error('Erro ao carregar estatísticas do controle parental:', error);
      return {};
    }
  }
}

// Instância singleton
const parentalControlService = new ParentalControlService();

export default parentalControlService;

