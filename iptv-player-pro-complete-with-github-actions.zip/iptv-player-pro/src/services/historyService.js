/**
 * Serviço de histórico de reprodução
 * Gerencia histórico de visualização com SQLite
 */
class HistoryService {
  constructor() {
    this.db = null;
    this.isInitialized = false;
    this.maxHistoryItems = 1000;
    this.retentionDays = 90; // Manter histórico por 90 dias
    
    this.initializeDatabase();
  }

  /**
   * Inicializa o banco de dados SQLite
   * @private
   */
  async initializeDatabase() {
    try {
      // Verificar se estamos no Electron
      if (window.electronAPI && window.electronAPI.database) {
        this.db = window.electronAPI.database;
      } else {
        // Fallback para localStorage em ambiente de desenvolvimento
        this.db = new LocalStorageDB();
      }

      await this.createTables();
      await this.cleanupOldEntries();
      
      this.isInitialized = true;
      console.log('HistoryService inicializado com sucesso');
      
    } catch (error) {
      console.error('Erro ao inicializar HistoryService:', error);
      // Fallback para localStorage
      this.db = new LocalStorageDB();
      this.isInitialized = true;
    }
  }

  /**
   * Cria tabelas necessárias
   * @private
   */
  async createTables() {
    const createHistoryTable = `
      CREATE TABLE IF NOT EXISTS watch_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content_id TEXT NOT NULL,
        content_type TEXT NOT NULL,
        content_name TEXT NOT NULL,
        content_poster TEXT,
        content_description TEXT,
        content_genre TEXT,
        content_year INTEGER,
        content_rating REAL,
        stream_url TEXT,
        watch_time INTEGER DEFAULT 0,
        total_duration INTEGER DEFAULT 0,
        watch_percentage REAL DEFAULT 0,
        last_watched DATETIME DEFAULT CURRENT_TIMESTAMP,
        watch_count INTEGER DEFAULT 1,
        is_completed BOOLEAN DEFAULT FALSE,
        user_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    const createIndexes = [
      'CREATE INDEX IF NOT EXISTS idx_content_id ON watch_history(content_id)',
      'CREATE INDEX IF NOT EXISTS idx_content_type ON watch_history(content_type)',
      'CREATE INDEX IF NOT EXISTS idx_last_watched ON watch_history(last_watched)',
      'CREATE INDEX IF NOT EXISTS idx_user_id ON watch_history(user_id)',
      'CREATE INDEX IF NOT EXISTS idx_is_completed ON watch_history(is_completed)'
    ];

    await this.db.exec(createHistoryTable);
    
    for (const index of createIndexes) {
      await this.db.exec(index);
    }
  }

  /**
   * Adiciona item ao histórico
   * @param {Object} content - Conteúdo assistido
   * @param {number} watchTime - Tempo assistido em segundos
   * @param {number} totalDuration - Duração total em segundos
   * @param {string} userId - ID do usuário
   */
  async addToHistory(content, watchTime = 0, totalDuration = 0, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const watchPercentage = totalDuration > 0 ? (watchTime / totalDuration) * 100 : 0;
      const isCompleted = watchPercentage >= 90; // Considerado completo se assistiu 90%+

      // Verificar se já existe entrada para este conteúdo
      const existing = await this.getHistoryItem(content.id, userId);

      if (existing) {
        // Atualizar entrada existente
        await this.updateHistoryItem(existing.id, {
          watch_time: Math.max(existing.watch_time, watchTime),
          total_duration: totalDuration || existing.total_duration,
          watch_percentage: Math.max(existing.watch_percentage, watchPercentage),
          last_watched: new Date().toISOString(),
          watch_count: existing.watch_count + 1,
          is_completed: isCompleted || existing.is_completed
        });
      } else {
        // Criar nova entrada
        await this.createHistoryItem({
          content_id: content.id,
          content_type: content.type || 'unknown',
          content_name: content.name || content.title,
          content_poster: content.poster,
          content_description: content.description,
          content_genre: content.genre,
          content_year: content.year,
          content_rating: content.rating,
          stream_url: content.streamUrl,
          watch_time: watchTime,
          total_duration: totalDuration,
          watch_percentage: watchPercentage,
          is_completed: isCompleted,
          user_id: userId
        });
      }

      // Limitar número de itens no histórico
      await this.limitHistorySize(userId);

    } catch (error) {
      console.error('Erro ao adicionar ao histórico:', error);
    }
  }

  /**
   * Cria novo item no histórico
   * @private
   */
  async createHistoryItem(data) {
    const query = `
      INSERT INTO watch_history (
        content_id, content_type, content_name, content_poster, content_description,
        content_genre, content_year, content_rating, stream_url, watch_time,
        total_duration, watch_percentage, is_completed, user_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const params = [
      data.content_id,
      data.content_type,
      data.content_name,
      data.content_poster,
      data.content_description,
      data.content_genre,
      data.content_year,
      data.content_rating,
      data.stream_url,
      data.watch_time,
      data.total_duration,
      data.watch_percentage,
      data.is_completed,
      data.user_id
    ];

    return await this.db.run(query, params);
  }

  /**
   * Atualiza item do histórico
   * @private
   */
  async updateHistoryItem(id, data) {
    const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
    const query = `UPDATE watch_history SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
    const params = [...Object.values(data), id];

    return await this.db.run(query, params);
  }

  /**
   * Obtém item específico do histórico
   * @private
   */
  async getHistoryItem(contentId, userId) {
    const query = 'SELECT * FROM watch_history WHERE content_id = ? AND user_id = ?';
    return await this.db.get(query, [contentId, userId]);
  }

  /**
   * Obtém histórico completo do usuário
   * @param {string} userId - ID do usuário
   * @param {number} limit - Limite de itens
   * @param {number} offset - Offset para paginação
   * @returns {Promise<Array>} Lista do histórico
   */
  async getHistory(userId = 'default', limit = 50, offset = 0) {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        SELECT * FROM watch_history 
        WHERE user_id = ? 
        ORDER BY last_watched DESC 
        LIMIT ? OFFSET ?
      `;
      
      const results = await this.db.all(query, [userId, limit, offset]);
      return results.map(this.formatHistoryItem);
      
    } catch (error) {
      console.error('Erro ao obter histórico:', error);
      return [];
    }
  }

  /**
   * Obtém conteúdo para continuar assistindo
   * @param {string} userId - ID do usuário
   * @param {number} limit - Limite de itens
   * @returns {Promise<Array>} Lista para continuar assistindo
   */
  async getContinueWatching(userId = 'default', limit = 10) {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        SELECT * FROM watch_history 
        WHERE user_id = ? 
        AND is_completed = FALSE 
        AND watch_percentage > 5 
        AND watch_percentage < 90
        ORDER BY last_watched DESC 
        LIMIT ?
      `;
      
      const results = await this.db.all(query, [userId, limit]);
      return results.map(this.formatHistoryItem);
      
    } catch (error) {
      console.error('Erro ao obter continuar assistindo:', error);
      return [];
    }
  }

  /**
   * Obtém histórico por tipo de conteúdo
   * @param {string} contentType - Tipo de conteúdo (live, movie, series)
   * @param {string} userId - ID do usuário
   * @param {number} limit - Limite de itens
   * @returns {Promise<Array>} Lista filtrada do histórico
   */
  async getHistoryByType(contentType, userId = 'default', limit = 50) {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        SELECT * FROM watch_history 
        WHERE user_id = ? AND content_type = ?
        ORDER BY last_watched DESC 
        LIMIT ?
      `;
      
      const results = await this.db.all(query, [userId, contentType, limit]);
      return results.map(this.formatHistoryItem);
      
    } catch (error) {
      console.error('Erro ao obter histórico por tipo:', error);
      return [];
    }
  }

  /**
   * Obtém estatísticas do histórico
   * @param {string} userId - ID do usuário
   * @returns {Promise<Object>} Estatísticas do histórico
   */
  async getHistoryStats(userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const queries = {
        total: 'SELECT COUNT(*) as count FROM watch_history WHERE user_id = ?',
        completed: 'SELECT COUNT(*) as count FROM watch_history WHERE user_id = ? AND is_completed = TRUE',
        totalWatchTime: 'SELECT SUM(watch_time) as total FROM watch_history WHERE user_id = ?',
        byType: `
          SELECT content_type, COUNT(*) as count, SUM(watch_time) as total_time 
          FROM watch_history WHERE user_id = ? 
          GROUP BY content_type
        `,
        recentActivity: `
          SELECT DATE(last_watched) as date, COUNT(*) as count 
          FROM watch_history WHERE user_id = ? 
          AND last_watched >= date('now', '-30 days')
          GROUP BY DATE(last_watched) 
          ORDER BY date DESC
        `
      };

      const [total, completed, totalWatchTime, byType, recentActivity] = await Promise.all([
        this.db.get(queries.total, [userId]),
        this.db.get(queries.completed, [userId]),
        this.db.get(queries.totalWatchTime, [userId]),
        this.db.all(queries.byType, [userId]),
        this.db.all(queries.recentActivity, [userId])
      ]);

      return {
        totalItems: total.count || 0,
        completedItems: completed.count || 0,
        totalWatchTimeSeconds: totalWatchTime.total || 0,
        totalWatchTimeHours: Math.round((totalWatchTime.total || 0) / 3600 * 100) / 100,
        byType: byType || [],
        recentActivity: recentActivity || []
      };

    } catch (error) {
      console.error('Erro ao obter estatísticas do histórico:', error);
      return {
        totalItems: 0,
        completedItems: 0,
        totalWatchTimeSeconds: 0,
        totalWatchTimeHours: 0,
        byType: [],
        recentActivity: []
      };
    }
  }

  /**
   * Remove item do histórico
   * @param {string} contentId - ID do conteúdo
   * @param {string} userId - ID do usuário
   */
  async removeFromHistory(contentId, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = 'DELETE FROM watch_history WHERE content_id = ? AND user_id = ?';
      await this.db.run(query, [contentId, userId]);
    } catch (error) {
      console.error('Erro ao remover do histórico:', error);
    }
  }

  /**
   * Limpa todo o histórico do usuário
   * @param {string} userId - ID do usuário
   */
  async clearHistory(userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = 'DELETE FROM watch_history WHERE user_id = ?';
      await this.db.run(query, [userId]);
    } catch (error) {
      console.error('Erro ao limpar histórico:', error);
    }
  }

  /**
   * Marca conteúdo como assistido completamente
   * @param {string} contentId - ID do conteúdo
   * @param {string} userId - ID do usuário
   */
  async markAsCompleted(contentId, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        UPDATE watch_history 
        SET is_completed = TRUE, watch_percentage = 100, updated_at = CURRENT_TIMESTAMP
        WHERE content_id = ? AND user_id = ?
      `;
      await this.db.run(query, [contentId, userId]);
    } catch (error) {
      console.error('Erro ao marcar como completo:', error);
    }
  }

  /**
   * Obtém posição de reprodução salva
   * @param {string} contentId - ID do conteúdo
   * @param {string} userId - ID do usuário
   * @returns {Promise<number>} Posição em segundos
   */
  async getWatchPosition(contentId, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const item = await this.getHistoryItem(contentId, userId);
      return item ? item.watch_time : 0;
    } catch (error) {
      console.error('Erro ao obter posição de reprodução:', error);
      return 0;
    }
  }

  /**
   * Formata item do histórico
   * @private
   */
  formatHistoryItem(item) {
    return {
      id: item.content_id,
      type: item.content_type,
      name: item.content_name,
      poster: item.content_poster,
      description: item.content_description,
      genre: item.content_genre,
      year: item.content_year,
      rating: item.content_rating,
      streamUrl: item.stream_url,
      watchTime: item.watch_time,
      totalDuration: item.total_duration,
      watchPercentage: item.watch_percentage,
      lastWatched: new Date(item.last_watched),
      watchCount: item.watch_count,
      isCompleted: Boolean(item.is_completed),
      createdAt: new Date(item.created_at),
      updatedAt: new Date(item.updated_at)
    };
  }

  /**
   * Limita o tamanho do histórico
   * @private
   */
  async limitHistorySize(userId) {
    try {
      const countQuery = 'SELECT COUNT(*) as count FROM watch_history WHERE user_id = ?';
      const count = await this.db.get(countQuery, [userId]);

      if (count.count > this.maxHistoryItems) {
        const deleteQuery = `
          DELETE FROM watch_history 
          WHERE user_id = ? 
          AND id NOT IN (
            SELECT id FROM watch_history 
            WHERE user_id = ? 
            ORDER BY last_watched DESC 
            LIMIT ?
          )
        `;
        await this.db.run(deleteQuery, [userId, userId, this.maxHistoryItems]);
      }
    } catch (error) {
      console.error('Erro ao limitar tamanho do histórico:', error);
    }
  }

  /**
   * Remove entradas antigas
   * @private
   */
  async cleanupOldEntries() {
    try {
      const query = `
        DELETE FROM watch_history 
        WHERE last_watched < date('now', '-${this.retentionDays} days')
      `;
      await this.db.run(query);
    } catch (error) {
      console.error('Erro ao limpar entradas antigas:', error);
    }
  }

  /**
   * Aguarda inicialização
   * @private
   */
  async waitForInitialization() {
    while (!this.isInitialized) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
}

/**
 * Implementação de fallback usando localStorage
 * @private
 */
class LocalStorageDB {
  constructor() {
    this.storageKey = 'iptv_watch_history';
    this.data = this.loadData();
  }

  loadData() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Erro ao carregar dados do localStorage:', error);
      return [];
    }
  }

  saveData() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.data));
    } catch (error) {
      console.error('Erro ao salvar dados no localStorage:', error);
    }
  }

  async exec(query) {
    // Implementação básica para criar tabelas (não faz nada no localStorage)
    return Promise.resolve();
  }

  async run(query, params = []) {
    // Implementação simplificada para INSERT/UPDATE/DELETE
    return Promise.resolve({ lastID: Date.now() });
  }

  async get(query, params = []) {
    // Implementação simplificada para SELECT (retorna primeiro item)
    const results = await this.all(query, params);
    return results[0] || null;
  }

  async all(query, params = []) {
    // Implementação simplificada para SELECT (retorna todos os itens)
    return Promise.resolve(this.data.filter(item => {
      // Filtro básico baseado nos parâmetros
      if (params.length > 0 && params[0]) {
        return item.user_id === params[0];
      }
      return true;
    }));
  }
}

// Instância singleton
const historyService = new HistoryService();

export default historyService;

