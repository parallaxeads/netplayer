import xtreamApi from './xtreamApi';
import databaseService from './databaseService';

/**
 * Serviço de gerenciamento de conteúdo
 * Centraliza o acesso a dados de TV ao vivo, filmes e séries
 */
class ContentService {
  constructor() {
    this.cache = {
      liveCategories: null,
      vodCategories: null,
      seriesCategories: null,
      liveStreams: new Map(),
      vodStreams: new Map(),
      series: new Map(),
      lastUpdate: null
    };
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutos
  }

  /**
   * Verifica se o cache ainda é válido
   * @private
   */
  isCacheValid() {
    if (!this.cache.lastUpdate) return false;
    return Date.now() - this.cache.lastUpdate < this.cacheTimeout;
  }

  /**
   * Limpa o cache
   */
  clearCache() {
    this.cache = {
      liveCategories: null,
      vodCategories: null,
      seriesCategories: null,
      liveStreams: new Map(),
      vodStreams: new Map(),
      series: new Map(),
      lastUpdate: null
    };
  }

  /**
   * Carrega todas as categorias de TV ao vivo
   * @returns {Promise<Array>} Lista de categorias
   */
  async getLiveCategories() {
    if (this.cache.liveCategories && this.isCacheValid()) {
      return this.cache.liveCategories;
    }

    try {
      const categories = await xtreamApi.getLiveCategories();
      this.cache.liveCategories = categories;
      this.cache.lastUpdate = Date.now();
      return categories;
    } catch (error) {
      console.error('Erro ao carregar categorias de TV:', error);
      throw error;
    }
  }

  /**
   * Carrega todas as categorias de VOD (filmes)
   * @returns {Promise<Array>} Lista de categorias
   */
  async getVodCategories() {
    if (this.cache.vodCategories && this.isCacheValid()) {
      return this.cache.vodCategories;
    }

    try {
      const categories = await xtreamApi.getVodCategories();
      this.cache.vodCategories = categories;
      this.cache.lastUpdate = Date.now();
      return categories;
    } catch (error) {
      console.error('Erro ao carregar categorias de filmes:', error);
      throw error;
    }
  }

  /**
   * Carrega todas as categorias de séries
   * @returns {Promise<Array>} Lista de categorias
   */
  async getSeriesCategories() {
    if (this.cache.seriesCategories && this.isCacheValid()) {
      return this.cache.seriesCategories;
    }

    try {
      const categories = await xtreamApi.getSeriesCategories();
      this.cache.seriesCategories = categories;
      this.cache.lastUpdate = Date.now();
      return categories;
    } catch (error) {
      console.error('Erro ao carregar categorias de séries:', error);
      throw error;
    }
  }

  /**
   * Carrega canais de TV ao vivo por categoria
   * @param {string} categoryId - ID da categoria (opcional)
   * @returns {Promise<Array>} Lista de canais
   */
  async getLiveStreams(categoryId = null) {
    const cacheKey = categoryId || 'all';
    
    if (this.cache.liveStreams.has(cacheKey) && this.isCacheValid()) {
      return this.cache.liveStreams.get(cacheKey);
    }

    try {
      const streams = await xtreamApi.getLiveStreams(categoryId);
      
      // Processar e enriquecer dados dos streams
      const processedStreams = streams.map(stream => ({
        ...stream,
        type: 'live',
        streamUrl: xtreamApi.buildLiveStreamUrl(stream.stream_id, 'm3u8'),
        poster: stream.stream_icon || '/placeholder-tv.jpg',
        category: stream.category_name || 'TV ao Vivo',
        isLive: true,
        quality: this.extractQuality(stream.name),
        language: this.extractLanguage(stream.name)
      }));

      this.cache.liveStreams.set(cacheKey, processedStreams);
      return processedStreams;
    } catch (error) {
      console.error('Erro ao carregar canais:', error);
      throw error;
    }
  }

  /**
   * Carrega filmes/VOD por categoria
   * @param {string} categoryId - ID da categoria (opcional)
   * @returns {Promise<Array>} Lista de filmes
   */
  async getVodStreams(categoryId = null) {
    const cacheKey = categoryId || 'all';
    
    if (this.cache.vodStreams.has(cacheKey) && this.isCacheValid()) {
      return this.cache.vodStreams.get(cacheKey);
    }

    try {
      const streams = await xtreamApi.getVodStreams(categoryId);
      
      // Processar e enriquecer dados dos filmes
      const processedStreams = streams.map(stream => ({
        ...stream,
        type: 'vod',
        streamUrl: xtreamApi.buildVodStreamUrl(stream.stream_id, 'mp4'),
        poster: stream.stream_icon || '/placeholder-movie.jpg',
        category: stream.category_name || 'Filmes',
        isLive: false,
        duration: this.formatDuration(stream.duration),
        year: this.extractYear(stream.name),
        rating: stream.rating || 'N/A'
      }));

      this.cache.vodStreams.set(cacheKey, processedStreams);
      return processedStreams;
    } catch (error) {
      console.error('Erro ao carregar filmes:', error);
      throw error;
    }
  }

  /**
   * Carrega séries por categoria
   * @param {string} categoryId - ID da categoria (opcional)
   * @returns {Promise<Array>} Lista de séries
   */
  async getSeries(categoryId = null) {
    const cacheKey = categoryId || 'all';
    
    if (this.cache.series.has(cacheKey) && this.isCacheValid()) {
      return this.cache.series.get(cacheKey);
    }

    try {
      const series = await xtreamApi.getSeries(categoryId);
      
      // Processar e enriquecer dados das séries
      const processedSeries = series.map(serie => ({
        ...serie,
        type: 'series',
        poster: serie.cover || '/placeholder-series.jpg',
        category: serie.category_name || 'Séries',
        isLive: false,
        year: serie.year || this.extractYear(serie.name),
        rating: serie.rating || 'N/A',
        episodeCount: serie.episode_run_time || 'N/A'
      }));

      this.cache.series.set(cacheKey, processedSeries);
      return processedSeries;
    } catch (error) {
      console.error('Erro ao carregar séries:', error);
      throw error;
    }
  }

  /**
   * Obtém informações detalhadas de uma série
   * @param {string} seriesId - ID da série
   * @returns {Promise<Object>} Informações detalhadas
   */
  async getSeriesInfo(seriesId) {
    try {
      const seriesInfo = await xtreamApi.getSeriesInfo(seriesId);
      
      // Processar episódios
      if (seriesInfo.episodes) {
        Object.keys(seriesInfo.episodes).forEach(seasonNumber => {
          seriesInfo.episodes[seasonNumber] = seriesInfo.episodes[seasonNumber].map(episode => ({
            ...episode,
            streamUrl: xtreamApi.buildSeriesStreamUrl(episode.id, 'mp4'),
            poster: episode.info?.movie_image || seriesInfo.info?.movie_image || '/placeholder-episode.jpg'
          }));
        });
      }

      return seriesInfo;
    } catch (error) {
      console.error('Erro ao carregar informações da série:', error);
      throw error;
    }
  }

  /**
   * Obtém informações detalhadas de um filme
   * @param {string} vodId - ID do filme
   * @returns {Promise<Object>} Informações detalhadas
   */
  async getVodInfo(vodId) {
    try {
      const vodInfo = await xtreamApi.getVodInfo(vodId);
      
      // Enriquecer informações do filme
      if (vodInfo.info) {
        vodInfo.streamUrl = xtreamApi.buildVodStreamUrl(vodId, 'mp4');
        vodInfo.poster = vodInfo.info.movie_image || '/placeholder-movie.jpg';
        vodInfo.backdrop = vodInfo.info.backdrop_path || vodInfo.info.movie_image;
        vodInfo.duration = this.formatDuration(vodInfo.info.duration_secs);
        vodInfo.year = vodInfo.info.releasedate ? new Date(vodInfo.info.releasedate).getFullYear() : 'N/A';
      }

      return vodInfo;
    } catch (error) {
      console.error('Erro ao carregar informações do filme:', error);
      throw error;
    }
  }

  /**
   * Busca conteúdo por termo
   * @param {string} query - Termo de busca
   * @param {string} type - Tipo de conteúdo ('live', 'vod', 'series', 'all')
   * @returns {Promise<Object>} Resultados da busca
   */
  async searchContent(query, type = 'all') {
    try {
      const results = await xtreamApi.search(query, type);
      
      // Processar resultados
      const processedResults = {
        live: results.live?.map(stream => ({
          ...stream,
          type: 'live',
          streamUrl: xtreamApi.buildLiveStreamUrl(stream.stream_id, 'm3u8'),
          poster: stream.stream_icon || '/placeholder-tv.jpg'
        })) || [],
        
        vod: results.vod?.map(stream => ({
          ...stream,
          type: 'vod',
          streamUrl: xtreamApi.buildVodStreamUrl(stream.stream_id, 'mp4'),
          poster: stream.stream_icon || '/placeholder-movie.jpg'
        })) || [],
        
        series: results.series?.map(serie => ({
          ...serie,
          type: 'series',
          poster: serie.cover || '/placeholder-series.jpg'
        })) || []
      };

      return processedResults;
    } catch (error) {
      console.error('Erro na busca:', error);
      throw error;
    }
  }

  /**
   * Obtém EPG para um canal
   * @param {string} streamId - ID do canal
   * @returns {Promise<Object>} Dados do EPG
   */
  async getChannelEpg(streamId) {
    try {
      const epg = await xtreamApi.getEpg(streamId);
      
      // Processar dados do EPG
      if (epg.epg_listings) {
        epg.epg_listings = epg.epg_listings.map(program => ({
          ...program,
          startTime: new Date(program.start_timestamp * 1000),
          endTime: new Date(program.stop_timestamp * 1000),
          duration: (program.stop_timestamp - program.start_timestamp) * 1000,
          isLive: this.isProgramLive(program.start_timestamp, program.stop_timestamp)
        }));
      }

      return epg;
    } catch (error) {
      console.error('Erro ao carregar EPG:', error);
      throw error;
    }
  }

  /**
   * Carrega conteúdo para a tela principal
   * @returns {Promise<Object>} Dados organizados para a interface
   */
  async getMainScreenContent() {
    try {
      const [liveCategories, vodCategories, seriesCategories] = await Promise.all([
        this.getLiveCategories(),
        this.getVodCategories(),
        this.getSeriesCategories()
      ]);

      // Carregar conteúdo das principais categorias
      const mainContent = {
        featured: null,
        liveChannels: [],
        movies: [],
        series: [],
        categories: {
          live: liveCategories,
          vod: vodCategories,
          series: seriesCategories
        }
      };

      // Carregar alguns canais em destaque
      if (liveCategories.length > 0) {
        const featuredCategory = liveCategories[0];
        mainContent.liveChannels = await this.getLiveStreams(featuredCategory.category_id);
        mainContent.featured = mainContent.liveChannels[0]; // Primeiro canal como destaque
      }

      // Carregar alguns filmes
      if (vodCategories.length > 0) {
        const movieCategory = vodCategories[0];
        mainContent.movies = await this.getVodStreams(movieCategory.category_id);
      }

      // Carregar algumas séries
      if (seriesCategories.length > 0) {
        const seriesCategory = seriesCategories[0];
        mainContent.series = await this.getSeries(seriesCategory.category_id);
      }

      return mainContent;
    } catch (error) {
      console.error('Erro ao carregar conteúdo principal:', error);
      throw error;
    }
  }

  /**
   * Adiciona conteúdo aos favoritos
   * @param {string} userId - ID do usuário
   * @param {Object} content - Conteúdo a ser favoritado
   */
  async addToFavorites(userId, content) {
    try {
      await databaseService.addFavorite(userId, content);
    } catch (error) {
      console.error('Erro ao adicionar favorito:', error);
      throw error;
    }
  }

  /**
   * Remove conteúdo dos favoritos
   * @param {string} userId - ID do usuário
   * @param {string} contentId - ID do conteúdo
   * @param {string} contentType - Tipo do conteúdo
   */
  async removeFromFavorites(userId, contentId, contentType) {
    try {
      await databaseService.removeFavorite(userId, contentId, contentType);
    } catch (error) {
      console.error('Erro ao remover favorito:', error);
      throw error;
    }
  }

  /**
   * Obtém lista de favoritos do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Lista de favoritos
   */
  async getFavorites(userId) {
    try {
      return await databaseService.getFavorites(userId);
    } catch (error) {
      console.error('Erro ao carregar favoritos:', error);
      return [];
    }
  }

  /**
   * Adiciona item ao histórico
   * @param {string} userId - ID do usuário
   * @param {Object} content - Conteúdo assistido
   * @param {number} position - Posição de reprodução
   * @param {number} duration - Duração total
   */
  async addToHistory(userId, content, position = 0, duration = 0) {
    try {
      await databaseService.addToHistory(userId, content, position, duration);
    } catch (error) {
      console.error('Erro ao adicionar ao histórico:', error);
      throw error;
    }
  }

  /**
   * Obtém histórico do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Lista do histórico
   */
  async getHistory(userId) {
    try {
      return await databaseService.getHistory(userId);
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
      return [];
    }
  }

  // Métodos utilitários privados

  /**
   * Extrai qualidade do nome do stream
   * @private
   */
  extractQuality(name) {
    const qualityRegex = /(4K|UHD|HD|FHD|720p|1080p|SD)/i;
    const match = name.match(qualityRegex);
    return match ? match[1].toUpperCase() : 'SD';
  }

  /**
   * Extrai idioma do nome do stream
   * @private
   */
  extractLanguage(name) {
    const languageRegex = /(PT|BR|EN|ES|FR|DE|IT)/i;
    const match = name.match(languageRegex);
    return match ? match[1].toUpperCase() : 'PT';
  }

  /**
   * Extrai ano do nome
   * @private
   */
  extractYear(name) {
    const yearRegex = /\b(19|20)\d{2}\b/;
    const match = name.match(yearRegex);
    return match ? parseInt(match[0]) : new Date().getFullYear();
  }

  /**
   * Formata duração em segundos para string legível
   * @private
   */
  formatDuration(seconds) {
    if (!seconds || seconds === '0') return 'N/A';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  }

  /**
   * Verifica se um programa está ao vivo
   * @private
   */
  isProgramLive(startTimestamp, endTimestamp) {
    const now = Date.now() / 1000;
    return now >= startTimestamp && now <= endTimestamp;
  }
}

// Instância singleton
const contentService = new ContentService();

export default contentService;

