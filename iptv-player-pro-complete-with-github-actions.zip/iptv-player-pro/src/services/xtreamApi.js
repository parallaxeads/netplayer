import axios from 'axios';

/**
 * Serviço para integração com Xtream Codes API
 * Suporta autenticação, listagem de conteúdo e construção de URLs de stream
 */
class XtreamApiService {
  constructor() {
    this.baseUrl = null;
    this.username = null;
    this.password = null;
    this.serverInfo = null;
    this.userInfo = null;
    this.authToken = null;
    this.isAuthenticated = false;
  }

  /**
   * Configura as credenciais do servidor
   * @param {string} serverUrl - URL do servidor Xtream Codes
   * @param {string} username - Nome de usuário
   * @param {string} password - Senha
   */
  setCredentials(serverUrl, username, password) {
    // Normalizar URL do servidor
    this.baseUrl = serverUrl.replace(/\/+$/, ''); // Remove barras finais
    this.username = username;
    this.password = password;
    this.isAuthenticated = false;
  }

  /**
   * Autentica com o servidor Xtream Codes
   * @returns {Promise<Object>} Informações de autenticação
   */
  async authenticate() {
    if (!this.baseUrl || !this.username || !this.password) {
      throw new Error('Credenciais não configuradas');
    }

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_account_info'
        },
        timeout: 10000
      });

      if (response.data && response.data.user_info) {
        this.userInfo = response.data.user_info;
        this.serverInfo = response.data.server_info;
        this.isAuthenticated = true;
        this.authToken = `${this.username}:${this.password}`;

        return {
          success: true,
          userInfo: this.userInfo,
          serverInfo: this.serverInfo
        };
      } else {
        throw new Error('Resposta inválida do servidor');
      }
    } catch (error) {
      this.isAuthenticated = false;
      
      if (error.response) {
        // Erro HTTP
        throw new Error(`Erro do servidor: ${error.response.status} - ${error.response.statusText}`);
      } else if (error.request) {
        // Erro de rede
        throw new Error('Não foi possível conectar ao servidor. Verifique a URL e sua conexão.');
      } else {
        // Outros erros
        throw new Error(error.message || 'Erro desconhecido durante autenticação');
      }
    }
  }

  /**
   * Verifica se está autenticado
   * @returns {boolean} Status de autenticação
   */
  isAuth() {
    return this.isAuthenticated && this.userInfo && this.serverInfo;
  }

  /**
   * Obtém informações da conta
   * @returns {Object} Informações do usuário e servidor
   */
  getAccountInfo() {
    return {
      userInfo: this.userInfo,
      serverInfo: this.serverInfo,
      isAuthenticated: this.isAuthenticated
    };
  }

  /**
   * Lista todas as categorias de TV ao vivo
   * @returns {Promise<Array>} Lista de categorias
   */
  async getLiveCategories() {
    this.ensureAuthenticated();

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_live_categories'
        },
        timeout: 10000
      });

      return response.data || [];
    } catch (error) {
      throw new Error(`Erro ao carregar categorias de TV: ${error.message}`);
    }
  }

  /**
   * Lista todos os canais de TV ao vivo
   * @param {string} categoryId - ID da categoria (opcional)
   * @returns {Promise<Array>} Lista de canais
   */
  async getLiveStreams(categoryId = null) {
    this.ensureAuthenticated();

    try {
      const params = {
        username: this.username,
        password: this.password,
        action: 'get_live_streams'
      };

      if (categoryId) {
        params.category_id = categoryId;
      }

      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params,
        timeout: 15000
      });

      return response.data || [];
    } catch (error) {
      throw new Error(`Erro ao carregar canais: ${error.message}`);
    }
  }

  /**
   * Lista todas as categorias de VOD (filmes)
   * @returns {Promise<Array>} Lista de categorias
   */
  async getVodCategories() {
    this.ensureAuthenticated();

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_vod_categories'
        },
        timeout: 10000
      });

      return response.data || [];
    } catch (error) {
      throw new Error(`Erro ao carregar categorias de filmes: ${error.message}`);
    }
  }

  /**
   * Lista todos os filmes/VOD
   * @param {string} categoryId - ID da categoria (opcional)
   * @returns {Promise<Array>} Lista de filmes
   */
  async getVodStreams(categoryId = null) {
    this.ensureAuthenticated();

    try {
      const params = {
        username: this.username,
        password: this.password,
        action: 'get_vod_streams'
      };

      if (categoryId) {
        params.category_id = categoryId;
      }

      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params,
        timeout: 15000
      });

      return response.data || [];
    } catch (error) {
      throw new Error(`Erro ao carregar filmes: ${error.message}`);
    }
  }

  /**
   * Lista todas as categorias de séries
   * @returns {Promise<Array>} Lista de categorias
   */
  async getSeriesCategories() {
    this.ensureAuthenticated();

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_series_categories'
        },
        timeout: 10000
      });

      return response.data || [];
    } catch (error) {
      throw new Error(`Erro ao carregar categorias de séries: ${error.message}`);
    }
  }

  /**
   * Lista todas as séries
   * @param {string} categoryId - ID da categoria (opcional)
   * @returns {Promise<Array>} Lista de séries
   */
  async getSeries(categoryId = null) {
    this.ensureAuthenticated();

    try {
      const params = {
        username: this.username,
        password: this.password,
        action: 'get_series'
      };

      if (categoryId) {
        params.category_id = categoryId;
      }

      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params,
        timeout: 15000
      });

      return response.data || [];
    } catch (error) {
      throw new Error(`Erro ao carregar séries: ${error.message}`);
    }
  }

  /**
   * Obtém informações detalhadas de uma série
   * @param {string} seriesId - ID da série
   * @returns {Promise<Object>} Informações da série
   */
  async getSeriesInfo(seriesId) {
    this.ensureAuthenticated();

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_series_info',
          series_id: seriesId
        },
        timeout: 10000
      });

      return response.data || {};
    } catch (error) {
      throw new Error(`Erro ao carregar informações da série: ${error.message}`);
    }
  }

  /**
   * Obtém informações detalhadas de um filme/VOD
   * @param {string} vodId - ID do filme
   * @returns {Promise<Object>} Informações do filme
   */
  async getVodInfo(vodId) {
    this.ensureAuthenticated();

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_vod_info',
          vod_id: vodId
        },
        timeout: 10000
      });

      return response.data || {};
    } catch (error) {
      throw new Error(`Erro ao carregar informações do filme: ${error.message}`);
    }
  }

  /**
   * Obtém EPG (guia de programação) para um canal
   * @param {string} streamId - ID do canal
   * @returns {Promise<Object>} Dados do EPG
   */
  async getEpg(streamId) {
    this.ensureAuthenticated();

    try {
      const response = await axios.get(`${this.baseUrl}/player_api.php`, {
        params: {
          username: this.username,
          password: this.password,
          action: 'get_short_epg',
          stream_id: streamId,
          limit: 10
        },
        timeout: 10000
      });

      return response.data || {};
    } catch (error) {
      throw new Error(`Erro ao carregar EPG: ${error.message}`);
    }
  }

  /**
   * Constrói URL de stream para TV ao vivo
   * @param {string} streamId - ID do canal
   * @param {string} extension - Extensão do stream (ts, m3u8, etc.)
   * @returns {string} URL do stream
   */
  buildLiveStreamUrl(streamId, extension = 'ts') {
    this.ensureAuthenticated();
    return `${this.baseUrl}/live/${this.username}/${this.password}/${streamId}.${extension}`;
  }

  /**
   * Constrói URL de stream para VOD
   * @param {string} streamId - ID do filme
   * @param {string} extension - Extensão do stream (mp4, mkv, etc.)
   * @returns {string} URL do stream
   */
  buildVodStreamUrl(streamId, extension = 'mp4') {
    this.ensureAuthenticated();
    return `${this.baseUrl}/movie/${this.username}/${this.password}/${streamId}.${extension}`;
  }

  /**
   * Constrói URL de stream para episódio de série
   * @param {string} streamId - ID do episódio
   * @param {string} extension - Extensão do stream (mp4, mkv, etc.)
   * @returns {string} URL do stream
   */
  buildSeriesStreamUrl(streamId, extension = 'mp4') {
    this.ensureAuthenticated();
    return `${this.baseUrl}/series/${this.username}/${this.password}/${streamId}.${extension}`;
  }

  /**
   * Busca conteúdo por termo
   * @param {string} query - Termo de busca
   * @param {string} type - Tipo de conteúdo ('live', 'vod', 'series', 'all')
   * @returns {Promise<Object>} Resultados da busca
   */
  async search(query, type = 'all') {
    this.ensureAuthenticated();

    const results = {
      live: [],
      vod: [],
      series: []
    };

    try {
      if (type === 'all' || type === 'live') {
        const liveStreams = await this.getLiveStreams();
        results.live = liveStreams.filter(stream => 
          stream.name && stream.name.toLowerCase().includes(query.toLowerCase())
        );
      }

      if (type === 'all' || type === 'vod') {
        const vodStreams = await this.getVodStreams();
        results.vod = vodStreams.filter(stream => 
          stream.name && stream.name.toLowerCase().includes(query.toLowerCase())
        );
      }

      if (type === 'all' || type === 'series') {
        const series = await this.getSeries();
        results.series = series.filter(serie => 
          serie.name && serie.name.toLowerCase().includes(query.toLowerCase())
        );
      }

      return results;
    } catch (error) {
      throw new Error(`Erro na busca: ${error.message}`);
    }
  }

  /**
   * Verifica se está autenticado, lança erro se não estiver
   * @private
   */
  ensureAuthenticated() {
    if (!this.isAuth()) {
      throw new Error('Não autenticado. Execute authenticate() primeiro.');
    }
  }

  /**
   * Limpa dados de autenticação
   */
  logout() {
    this.baseUrl = null;
    this.username = null;
    this.password = null;
    this.serverInfo = null;
    this.userInfo = null;
    this.authToken = null;
    this.isAuthenticated = false;
  }

  /**
   * Testa conectividade com o servidor
   * @param {string} serverUrl - URL do servidor para testar
   * @returns {Promise<boolean>} Status da conectividade
   */
  static async testConnection(serverUrl) {
    try {
      const normalizedUrl = serverUrl.replace(/\/+$/, '');
      const response = await axios.get(`${normalizedUrl}/player_api.php?action=get_account_info`, {
        timeout: 5000
      });
      
      // Se chegou até aqui, o servidor está respondendo
      return true;
    } catch (error) {
      return false;
    }
  }
}

// Instância singleton
const xtreamApi = new XtreamApiService();

export default xtreamApi;

