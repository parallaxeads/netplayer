/**
 * Serviço de notificações
 * Gerencia notificações dentro do aplicativo
 */
class NotificationService {
  constructor() {
    this.notifications = [];
    this.maxNotifications = 50;
    this.defaultDuration = 5000; // 5 segundos
    this.listeners = new Map();
    this.notificationId = 0;
    this.container = null;
    
    this.types = {
      SUCCESS: 'success',
      ERROR: 'error',
      WARNING: 'warning',
      INFO: 'info'
    };

    this.positions = {
      TOP_RIGHT: 'top-right',
      TOP_LEFT: 'top-left',
      BOTTOM_RIGHT: 'bottom-right',
      BOTTOM_LEFT: 'bottom-left',
      TOP_CENTER: 'top-center',
      BOTTOM_CENTER: 'bottom-center'
    };

    this.defaultPosition = this.positions.TOP_RIGHT;
    this.settings = {
      enabled: true,
      position: this.defaultPosition,
      duration: this.defaultDuration,
      showProgress: true,
      pauseOnHover: true,
      closeOnClick: true,
      maxVisible: 5,
      animations: true,
      sounds: {
        enabled: false,
        success: null,
        error: null,
        warning: null,
        info: null
      }
    };

    this.loadSettings();
    this.createContainer();
  }

  /**
   * Exibe notificação
   * @param {string} message - Mensagem da notificação
   * @param {string} type - Tipo da notificação
   * @param {Object} options - Opções adicionais
   * @returns {string} ID da notificação
   */
  show(message, type = this.types.INFO, options = {}) {
    if (!this.settings.enabled) {
      return null;
    }

    const notification = this.createNotification(message, type, options);
    this.addNotification(notification);
    this.renderNotification(notification);
    this.scheduleRemoval(notification);
    this.playSound(type);

    return notification.id;
  }

  /**
   * Exibe notificação de sucesso
   * @param {string} message - Mensagem
   * @param {Object} options - Opções adicionais
   * @returns {string} ID da notificação
   */
  success(message, options = {}) {
    return this.show(message, this.types.SUCCESS, options);
  }

  /**
   * Exibe notificação de erro
   * @param {string} message - Mensagem
   * @param {Object} options - Opções adicionais
   * @returns {string} ID da notificação
   */
  error(message, options = {}) {
    return this.show(message, this.types.ERROR, {
      duration: 8000, // Erros ficam mais tempo
      ...options
    });
  }

  /**
   * Exibe notificação de aviso
   * @param {string} message - Mensagem
   * @param {Object} options - Opções adicionais
   * @returns {string} ID da notificação
   */
  warning(message, options = {}) {
    return this.show(message, this.types.WARNING, options);
  }

  /**
   * Exibe notificação de informação
   * @param {string} message - Mensagem
   * @param {Object} options - Opções adicionais
   * @returns {string} ID da notificação
   */
  info(message, options = {}) {
    return this.show(message, this.types.INFO, options);
  }

  /**
   * Remove notificação específica
   * @param {string} id - ID da notificação
   */
  remove(id) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      this.removeNotification(notification);
    }
  }

  /**
   * Remove todas as notificações
   */
  clear() {
    [...this.notifications].forEach(notification => {
      this.removeNotification(notification);
    });
  }

  /**
   * Remove notificações por tipo
   * @param {string} type - Tipo das notificações a remover
   */
  clearByType(type) {
    this.notifications
      .filter(n => n.type === type)
      .forEach(notification => {
        this.removeNotification(notification);
      });
  }

  /**
   * Atualiza notificação existente
   * @param {string} id - ID da notificação
   * @param {Object} updates - Atualizações
   */
  update(id, updates) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      Object.assign(notification, updates);
      this.updateNotificationElement(notification);
    }
  }

  /**
   * Pausa notificação (para o timer)
   * @param {string} id - ID da notificação
   */
  pause(id) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification && notification.timer) {
      clearTimeout(notification.timer);
      notification.paused = true;
      notification.remainingTime = notification.expiresAt - Date.now();
    }
  }

  /**
   * Resume notificação pausada
   * @param {string} id - ID da notificação
   */
  resume(id) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification && notification.paused) {
      notification.paused = false;
      notification.expiresAt = Date.now() + notification.remainingTime;
      this.scheduleRemoval(notification);
    }
  }

  /**
   * Configura posição das notificações
   * @param {string} position - Nova posição
   */
  setPosition(position) {
    if (Object.values(this.positions).includes(position)) {
      this.settings.position = position;
      this.updateContainerPosition();
      this.saveSettings();
    }
  }

  /**
   * Configura duração padrão
   * @param {number} duration - Duração em milissegundos
   */
  setDefaultDuration(duration) {
    this.settings.duration = duration;
    this.saveSettings();
  }

  /**
   * Habilita/desabilita notificações
   * @param {boolean} enabled - Se deve habilitar
   */
  setEnabled(enabled) {
    this.settings.enabled = enabled;
    if (!enabled) {
      this.clear();
    }
    this.saveSettings();
  }

  /**
   * Configura sons das notificações
   * @param {Object} soundConfig - Configuração de sons
   */
  setSounds(soundConfig) {
    this.settings.sounds = { ...this.settings.sounds, ...soundConfig };
    this.saveSettings();
  }

  /**
   * Obtém configurações atuais
   * @returns {Object} Configurações
   */
  getSettings() {
    return { ...this.settings };
  }

  /**
   * Obtém notificações ativas
   * @returns {Array} Lista de notificações
   */
  getActiveNotifications() {
    return [...this.notifications];
  }

  /**
   * Obtém estatísticas
   * @returns {Object} Estatísticas das notificações
   */
  getStats() {
    const stats = this.loadStats();
    return {
      totalShown: stats.totalShown || 0,
      byType: stats.byType || {},
      averageDuration: stats.averageDuration || 0,
      lastShown: stats.lastShown ? new Date(stats.lastShown) : null
    };
  }

  /**
   * Adiciona listener para eventos
   * @param {string} event - Nome do evento
   * @param {Function} callback - Função callback
   */
  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push(callback);
  }

  /**
   * Remove listener de evento
   * @param {string} event - Nome do evento
   * @param {Function} callback - Função callback
   */
  off(event, callback) {
    if (this.listeners.has(event)) {
      const callbacks = this.listeners.get(event);
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  // Métodos privados

  createNotification(message, type, options) {
    const id = `notification_${++this.notificationId}`;
    const duration = options.duration ?? this.settings.duration;
    
    return {
      id,
      message,
      type,
      title: options.title || null,
      icon: options.icon || this.getDefaultIcon(type),
      duration,
      persistent: options.persistent || false,
      actions: options.actions || [],
      data: options.data || {},
      createdAt: Date.now(),
      expiresAt: options.persistent ? null : Date.now() + duration,
      paused: false,
      remainingTime: duration,
      timer: null,
      element: null
    };
  }

  addNotification(notification) {
    this.notifications.unshift(notification);
    
    // Limitar número de notificações visíveis
    while (this.notifications.length > this.settings.maxVisible) {
      const oldest = this.notifications.pop();
      this.removeNotificationElement(oldest);
    }

    // Limitar número total de notificações
    if (this.notifications.length > this.maxNotifications) {
      this.notifications = this.notifications.slice(0, this.maxNotifications);
    }

    this.emit('notification-added', notification);
    this.updateStats(notification);
  }

  removeNotification(notification) {
    const index = this.notifications.indexOf(notification);
    if (index > -1) {
      this.notifications.splice(index, 1);
      
      if (notification.timer) {
        clearTimeout(notification.timer);
      }
      
      this.removeNotificationElement(notification);
      this.emit('notification-removed', notification);
    }
  }

  scheduleRemoval(notification) {
    if (notification.persistent) {
      return;
    }

    const timeUntilExpiry = notification.expiresAt - Date.now();
    
    notification.timer = setTimeout(() => {
      this.removeNotification(notification);
    }, timeUntilExpiry);
  }

  createContainer() {
    if (this.container) {
      return;
    }

    this.container = document.createElement('div');
    this.container.id = 'notification-container';
    this.container.className = 'notification-container';
    this.updateContainerPosition();
    
    document.body.appendChild(this.container);
  }

  updateContainerPosition() {
    if (!this.container) return;

    const position = this.settings.position;
    this.container.className = `notification-container notification-${position}`;
    
    // Remover classes de posição antigas
    this.container.classList.remove(
      ...Object.values(this.positions).map(p => `notification-${p}`)
    );
    
    // Adicionar nova classe de posição
    this.container.classList.add(`notification-${position}`);
  }

  renderNotification(notification) {
    const element = this.createNotificationElement(notification);
    notification.element = element;

    if (this.settings.position.includes('top')) {
      this.container.appendChild(element);
    } else {
      this.container.insertBefore(element, this.container.firstChild);
    }

    // Animar entrada
    if (this.settings.animations) {
      requestAnimationFrame(() => {
        element.classList.add('notification-show');
      });
    }

    // Configurar eventos
    this.setupNotificationEvents(notification);
  }

  createNotificationElement(notification) {
    const element = document.createElement('div');
    element.className = `notification notification-${notification.type}`;
    element.setAttribute('data-id', notification.id);

    const iconHtml = notification.icon ? 
      `<div class="notification-icon">${notification.icon}</div>` : '';
    
    const titleHtml = notification.title ? 
      `<div class="notification-title">${notification.title}</div>` : '';
    
    const actionsHtml = notification.actions.length > 0 ? 
      `<div class="notification-actions">
        ${notification.actions.map(action => 
          `<button class="notification-action" data-action="${action.id}">${action.label}</button>`
        ).join('')}
      </div>` : '';

    const progressHtml = this.settings.showProgress && !notification.persistent ? 
      '<div class="notification-progress"><div class="notification-progress-bar"></div></div>' : '';

    element.innerHTML = `
      <div class="notification-content">
        ${iconHtml}
        <div class="notification-text">
          ${titleHtml}
          <div class="notification-message">${notification.message}</div>
        </div>
        <button class="notification-close" aria-label="Fechar notificação">&times;</button>
      </div>
      ${actionsHtml}
      ${progressHtml}
    `;

    return element;
  }

  setupNotificationEvents(notification) {
    const element = notification.element;
    
    // Botão fechar
    const closeBtn = element.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
      this.removeNotification(notification);
    });

    // Clique na notificação
    if (this.settings.closeOnClick) {
      element.addEventListener('click', (e) => {
        if (!e.target.closest('.notification-action') && !e.target.closest('.notification-close')) {
          this.removeNotification(notification);
        }
      });
    }

    // Hover para pausar
    if (this.settings.pauseOnHover && !notification.persistent) {
      element.addEventListener('mouseenter', () => {
        this.pause(notification.id);
      });

      element.addEventListener('mouseleave', () => {
        this.resume(notification.id);
      });
    }

    // Ações
    const actionButtons = element.querySelectorAll('.notification-action');
    actionButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        const actionId = e.target.getAttribute('data-action');
        const action = notification.actions.find(a => a.id === actionId);
        if (action && action.handler) {
          action.handler(notification);
        }
        this.emit('notification-action', { notification, actionId });
      });
    });

    // Barra de progresso
    if (this.settings.showProgress && !notification.persistent) {
      this.animateProgress(notification);
    }
  }

  animateProgress(notification) {
    const progressBar = notification.element.querySelector('.notification-progress-bar');
    if (!progressBar) return;

    const duration = notification.duration;
    const startTime = Date.now();

    const updateProgress = () => {
      if (notification.paused) {
        requestAnimationFrame(updateProgress);
        return;
      }

      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      progressBar.style.width = `${(1 - progress) * 100}%`;

      if (progress < 1 && this.notifications.includes(notification)) {
        requestAnimationFrame(updateProgress);
      }
    };

    requestAnimationFrame(updateProgress);
  }

  updateNotificationElement(notification) {
    if (!notification.element) return;

    const messageEl = notification.element.querySelector('.notification-message');
    const titleEl = notification.element.querySelector('.notification-title');

    if (messageEl) {
      messageEl.textContent = notification.message;
    }

    if (titleEl && notification.title) {
      titleEl.textContent = notification.title;
    }
  }

  removeNotificationElement(notification) {
    if (!notification.element) return;

    if (this.settings.animations) {
      notification.element.classList.add('notification-hide');
      setTimeout(() => {
        if (notification.element && notification.element.parentNode) {
          notification.element.parentNode.removeChild(notification.element);
        }
      }, 300);
    } else {
      if (notification.element.parentNode) {
        notification.element.parentNode.removeChild(notification.element);
      }
    }
  }

  getDefaultIcon(type) {
    const icons = {
      success: '✓',
      error: '✕',
      warning: '⚠',
      info: 'ℹ'
    };
    return icons[type] || icons.info;
  }

  playSound(type) {
    if (!this.settings.sounds.enabled) return;

    const soundUrl = this.settings.sounds[type];
    if (soundUrl) {
      try {
        const audio = new Audio(soundUrl);
        audio.volume = 0.3;
        audio.play().catch(error => {
          console.warn('Erro ao reproduzir som da notificação:', error);
        });
      } catch (error) {
        console.warn('Erro ao criar áudio da notificação:', error);
      }
    }
  }

  emit(event, data) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('Erro no listener de notificação:', error);
        }
      });
    }
  }

  updateStats(notification) {
    const stats = this.loadStats();
    
    stats.totalShown = (stats.totalShown || 0) + 1;
    stats.byType = stats.byType || {};
    stats.byType[notification.type] = (stats.byType[notification.type] || 0) + 1;
    stats.lastShown = Date.now();

    this.saveStats(stats);
  }

  saveSettings() {
    try {
      localStorage.setItem('iptv_notification_settings', JSON.stringify(this.settings));
    } catch (error) {
      console.error('Erro ao salvar configurações de notificação:', error);
    }
  }

  loadSettings() {
    try {
      const saved = localStorage.getItem('iptv_notification_settings');
      if (saved) {
        this.settings = { ...this.settings, ...JSON.parse(saved) };
      }
    } catch (error) {
      console.error('Erro ao carregar configurações de notificação:', error);
    }
  }

  saveStats(stats) {
    try {
      localStorage.setItem('iptv_notification_stats', JSON.stringify(stats));
    } catch (error) {
      console.error('Erro ao salvar estatísticas de notificação:', error);
    }
  }

  loadStats() {
    try {
      const saved = localStorage.getItem('iptv_notification_stats');
      return saved ? JSON.parse(saved) : {};
    } catch (error) {
      console.error('Erro ao carregar estatísticas de notificação:', error);
      return {};
    }
  }
}

// Instância singleton
const notificationService = new NotificationService();

export default notificationService;

