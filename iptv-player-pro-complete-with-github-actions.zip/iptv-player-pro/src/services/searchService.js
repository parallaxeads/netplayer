/**
 * Serviço de busca inteligente
 * Implementa busca avançada com filtros, sugestões e histórico
 */
class SearchService {
  constructor() {
    this.searchHistory = [];
    this.searchSuggestions = [];
    this.searchFilters = {
      type: 'all', // 'all', 'live', 'movies', 'series'
      genre: 'all',
      quality: 'all',
      year: 'all',
      language: 'all'
    };
    this.searchCache = new Map();
    this.maxHistoryItems = 50;
    this.maxSuggestions = 10;
    this.searchTimeout = null;
    this.minSearchLength = 2;
    
    this.loadSearchHistory();
    this.loadSearchSuggestions();
  }

  /**
   * Realiza busca inteligente com filtros
   * @param {string} query - Termo de busca
   * @param {Object} filters - Filtros aplicados
   * @param {Object} contentData - Dados de conteúdo para buscar
   * @returns {Promise<Array>} Resultados da busca
   */
  async search(query, filters = {}, contentData = {}) {
    try {
      // Validar entrada
      if (!query || query.trim().length < this.minSearchLength) {
        return [];
      }

      const normalizedQuery = this.normalizeQuery(query);
      const appliedFilters = { ...this.searchFilters, ...filters };
      
      // Verificar cache
      const cacheKey = this.generateCacheKey(normalizedQuery, appliedFilters);
      if (this.searchCache.has(cacheKey)) {
        return this.searchCache.get(cacheKey);
      }

      // Realizar busca
      const results = await this.performSearch(normalizedQuery, appliedFilters, contentData);
      
      // Ordenar resultados por relevância
      const sortedResults = this.sortByRelevance(results, normalizedQuery);
      
      // Armazenar no cache
      this.searchCache.set(cacheKey, sortedResults);
      
      // Adicionar ao histórico
      this.addToHistory(query);
      
      // Atualizar sugestões
      this.updateSuggestions(query, sortedResults);

      return sortedResults;

    } catch (error) {
      console.error('Erro na busca:', error);
      return [];
    }
  }

  /**
   * Realiza a busca nos dados de conteúdo
   * @private
   */
  async performSearch(query, filters, contentData) {
    const results = [];
    const searchTerms = this.extractSearchTerms(query);

    // Buscar em TV ao vivo
    if (filters.type === 'all' || filters.type === 'live') {
      const liveResults = this.searchInContent(
        contentData.liveTV || [],
        searchTerms,
        'live',
        filters
      );
      results.push(...liveResults);
    }

    // Buscar em filmes
    if (filters.type === 'all' || filters.type === 'movies') {
      const movieResults = this.searchInContent(
        contentData.movies || [],
        searchTerms,
        'movie',
        filters
      );
      results.push(...movieResults);
    }

    // Buscar em séries
    if (filters.type === 'all' || filters.type === 'series') {
      const seriesResults = this.searchInContent(
        contentData.series || [],
        searchTerms,
        'series',
        filters
      );
      results.push(...seriesResults);
    }

    return results;
  }

  /**
   * Busca em uma categoria específica de conteúdo
   * @private
   */
  searchInContent(content, searchTerms, contentType, filters) {
    return content.filter(item => {
      // Verificar se atende aos filtros
      if (!this.matchesFilters(item, filters, contentType)) {
        return false;
      }

      // Verificar se corresponde aos termos de busca
      return this.matchesSearchTerms(item, searchTerms);
    }).map(item => ({
      ...item,
      contentType,
      searchScore: this.calculateSearchScore(item, searchTerms)
    }));
  }

  /**
   * Verifica se o item atende aos filtros
   * @private
   */
  matchesFilters(item, filters, contentType) {
    // Filtro de gênero
    if (filters.genre !== 'all' && item.genre) {
      if (!item.genre.toLowerCase().includes(filters.genre.toLowerCase())) {
        return false;
      }
    }

    // Filtro de qualidade
    if (filters.quality !== 'all' && item.quality) {
      if (item.quality.toLowerCase() !== filters.quality.toLowerCase()) {
        return false;
      }
    }

    // Filtro de ano
    if (filters.year !== 'all' && item.year) {
      if (item.year.toString() !== filters.year.toString()) {
        return false;
      }
    }

    // Filtro de idioma
    if (filters.language !== 'all' && item.language) {
      if (!item.language.toLowerCase().includes(filters.language.toLowerCase())) {
        return false;
      }
    }

    return true;
  }

  /**
   * Verifica se o item corresponde aos termos de busca
   * @private
   */
  matchesSearchTerms(item, searchTerms) {
    const searchableFields = [
      item.name,
      item.title,
      item.description,
      item.genre,
      item.cast,
      item.director,
      item.keywords
    ].filter(Boolean).join(' ').toLowerCase();

    return searchTerms.some(term => 
      searchableFields.includes(term.toLowerCase())
    );
  }

  /**
   * Calcula pontuação de relevância para ordenação
   * @private
   */
  calculateSearchScore(item, searchTerms) {
    let score = 0;
    const name = (item.name || item.title || '').toLowerCase();
    const description = (item.description || '').toLowerCase();

    searchTerms.forEach(term => {
      const lowerTerm = term.toLowerCase();
      
      // Pontuação alta para correspondência exata no título
      if (name === lowerTerm) {
        score += 100;
      }
      // Pontuação média para título que começa com o termo
      else if (name.startsWith(lowerTerm)) {
        score += 50;
      }
      // Pontuação baixa para título que contém o termo
      else if (name.includes(lowerTerm)) {
        score += 25;
      }
      
      // Pontuação para descrição
      if (description.includes(lowerTerm)) {
        score += 10;
      }

      // Pontuação para outros campos
      const otherFields = [item.genre, item.cast, item.director].filter(Boolean).join(' ').toLowerCase();
      if (otherFields.includes(lowerTerm)) {
        score += 5;
      }
    });

    // Bonificação para conteúdo popular ou recente
    if (item.rating && item.rating > 8) {
      score += 10;
    }
    if (item.year && item.year >= new Date().getFullYear() - 2) {
      score += 5;
    }

    return score;
  }

  /**
   * Ordena resultados por relevância
   * @private
   */
  sortByRelevance(results, query) {
    return results.sort((a, b) => {
      // Primeiro por pontuação de busca
      if (b.searchScore !== a.searchScore) {
        return b.searchScore - a.searchScore;
      }
      
      // Depois por tipo de conteúdo (live > movies > series)
      const typeOrder = { live: 3, movie: 2, series: 1 };
      const aTypeScore = typeOrder[a.contentType] || 0;
      const bTypeScore = typeOrder[b.contentType] || 0;
      
      if (bTypeScore !== aTypeScore) {
        return bTypeScore - aTypeScore;
      }
      
      // Por último, ordem alfabética
      return (a.name || a.title || '').localeCompare(b.name || b.title || '');
    });
  }

  /**
   * Busca com sugestões em tempo real
   * @param {string} query - Termo de busca parcial
   * @param {Object} contentData - Dados de conteúdo
   * @returns {Promise<Array>} Sugestões de busca
   */
  async getSuggestions(query, contentData = {}) {
    if (!query || query.length < this.minSearchLength) {
      return this.getPopularSuggestions();
    }

    const suggestions = new Set();
    const normalizedQuery = query.toLowerCase();

    // Sugestões do histórico
    this.searchHistory
      .filter(item => item.toLowerCase().includes(normalizedQuery))
      .slice(0, 5)
      .forEach(item => suggestions.add(item));

    // Sugestões de títulos
    const allContent = [
      ...(contentData.liveTV || []),
      ...(contentData.movies || []),
      ...(contentData.series || [])
    ];

    allContent
      .filter(item => {
        const name = (item.name || item.title || '').toLowerCase();
        return name.includes(normalizedQuery);
      })
      .slice(0, 8)
      .forEach(item => suggestions.add(item.name || item.title));

    return Array.from(suggestions).slice(0, this.maxSuggestions);
  }

  /**
   * Retorna sugestões populares quando não há query
   * @private
   */
  getPopularSuggestions() {
    return this.searchSuggestions.slice(0, this.maxSuggestions);
  }

  /**
   * Busca avançada com múltiplos filtros
   * @param {Object} searchParams - Parâmetros de busca avançada
   * @param {Object} contentData - Dados de conteúdo
   * @returns {Promise<Array>} Resultados filtrados
   */
  async advancedSearch(searchParams, contentData = {}) {
    const {
      query = '',
      type = 'all',
      genre = 'all',
      quality = 'all',
      year = 'all',
      language = 'all',
      rating = 'all',
      sortBy = 'relevance'
    } = searchParams;

    const filters = { type, genre, quality, year, language, rating };
    let results = [];

    if (query.trim()) {
      results = await this.search(query, filters, contentData);
    } else {
      // Busca sem query - retornar tudo com filtros aplicados
      results = await this.performSearch('', filters, contentData);
    }

    // Aplicar ordenação
    return this.applySorting(results, sortBy);
  }

  /**
   * Aplica ordenação aos resultados
   * @private
   */
  applySorting(results, sortBy) {
    switch (sortBy) {
      case 'name':
        return results.sort((a, b) => (a.name || a.title || '').localeCompare(b.name || b.title || ''));
      
      case 'year':
        return results.sort((a, b) => (b.year || 0) - (a.year || 0));
      
      case 'rating':
        return results.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      
      case 'recent':
        return results.sort((a, b) => new Date(b.added || 0) - new Date(a.added || 0));
      
      case 'relevance':
      default:
        return results; // Já ordenado por relevância
    }
  }

  /**
   * Normaliza query de busca
   * @private
   */
  normalizeQuery(query) {
    return query.trim()
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .replace(/\s+/g, ' ');
  }

  /**
   * Extrai termos de busca da query
   * @private
   */
  extractSearchTerms(query) {
    return query.split(' ')
      .filter(term => term.length >= this.minSearchLength)
      .map(term => term.trim());
  }

  /**
   * Gera chave de cache
   * @private
   */
  generateCacheKey(query, filters) {
    return `${query}|${JSON.stringify(filters)}`;
  }

  /**
   * Adiciona termo ao histórico de busca
   * @private
   */
  addToHistory(query) {
    const trimmedQuery = query.trim();
    if (!trimmedQuery || trimmedQuery.length < this.minSearchLength) {
      return;
    }

    // Remover se já existe
    const existingIndex = this.searchHistory.indexOf(trimmedQuery);
    if (existingIndex > -1) {
      this.searchHistory.splice(existingIndex, 1);
    }

    // Adicionar no início
    this.searchHistory.unshift(trimmedQuery);

    // Limitar tamanho
    if (this.searchHistory.length > this.maxHistoryItems) {
      this.searchHistory = this.searchHistory.slice(0, this.maxHistoryItems);
    }

    this.saveSearchHistory();
  }

  /**
   * Atualiza sugestões baseadas nos resultados
   * @private
   */
  updateSuggestions(query, results) {
    // Adicionar termos populares das buscas bem-sucedidas
    if (results.length > 0) {
      const suggestion = query.trim();
      if (!this.searchSuggestions.includes(suggestion)) {
        this.searchSuggestions.unshift(suggestion);
        
        if (this.searchSuggestions.length > this.maxSuggestions * 2) {
          this.searchSuggestions = this.searchSuggestions.slice(0, this.maxSuggestions * 2);
        }
        
        this.saveSearchSuggestions();
      }
    }
  }

  /**
   * Carrega histórico de busca do localStorage
   * @private
   */
  loadSearchHistory() {
    try {
      const saved = localStorage.getItem('iptv_search_history');
      if (saved) {
        this.searchHistory = JSON.parse(saved);
      }
    } catch (error) {
      console.error('Erro ao carregar histórico de busca:', error);
      this.searchHistory = [];
    }
  }

  /**
   * Salva histórico de busca no localStorage
   * @private
   */
  saveSearchHistory() {
    try {
      localStorage.setItem('iptv_search_history', JSON.stringify(this.searchHistory));
    } catch (error) {
      console.error('Erro ao salvar histórico de busca:', error);
    }
  }

  /**
   * Carrega sugestões do localStorage
   * @private
   */
  loadSearchSuggestions() {
    try {
      const saved = localStorage.getItem('iptv_search_suggestions');
      if (saved) {
        this.searchSuggestions = JSON.parse(saved);
      }
    } catch (error) {
      console.error('Erro ao carregar sugestões de busca:', error);
      this.searchSuggestions = [];
    }
  }

  /**
   * Salva sugestões no localStorage
   * @private
   */
  saveSearchSuggestions() {
    try {
      localStorage.setItem('iptv_search_suggestions', JSON.stringify(this.searchSuggestions));
    } catch (error) {
      console.error('Erro ao salvar sugestões de busca:', error);
    }
  }

  /**
   * Limpa histórico de busca
   */
  clearHistory() {
    this.searchHistory = [];
    this.saveSearchHistory();
  }

  /**
   * Limpa cache de busca
   */
  clearCache() {
    this.searchCache.clear();
  }

  /**
   * Remove item do histórico
   */
  removeFromHistory(query) {
    const index = this.searchHistory.indexOf(query);
    if (index > -1) {
      this.searchHistory.splice(index, 1);
      this.saveSearchHistory();
    }
  }

  /**
   * Obtém histórico de busca
   */
  getHistory() {
    return [...this.searchHistory];
  }

  /**
   * Obtém filtros disponíveis baseados no conteúdo
   */
  getAvailableFilters(contentData = {}) {
    const filters = {
      types: ['all', 'live', 'movies', 'series'],
      genres: new Set(['all']),
      qualities: new Set(['all']),
      years: new Set(['all']),
      languages: new Set(['all'])
    };

    const allContent = [
      ...(contentData.liveTV || []),
      ...(contentData.movies || []),
      ...(contentData.series || [])
    ];

    allContent.forEach(item => {
      if (item.genre) filters.genres.add(item.genre);
      if (item.quality) filters.qualities.add(item.quality);
      if (item.year) filters.years.add(item.year.toString());
      if (item.language) filters.languages.add(item.language);
    });

    return {
      types: filters.types,
      genres: Array.from(filters.genres).sort(),
      qualities: Array.from(filters.qualities).sort(),
      years: Array.from(filters.years).sort((a, b) => b.localeCompare(a)),
      languages: Array.from(filters.languages).sort()
    };
  }

  /**
   * Define filtros padrão
   */
  setDefaultFilters(filters) {
    this.searchFilters = { ...this.searchFilters, ...filters };
  }

  /**
   * Obtém estatísticas de busca
   */
  getSearchStats() {
    return {
      totalSearches: this.searchHistory.length,
      cacheSize: this.searchCache.size,
      topSearches: this.searchHistory.slice(0, 10),
      suggestionsCount: this.searchSuggestions.length
    };
  }
}

// Instância singleton
const searchService = new SearchService();

export default searchService;

