/**
 * Serviço de favoritos
 * Gerencia lista de favoritos com SQLite
 */
class FavoritesService {
  constructor() {
    this.db = null;
    this.isInitialized = false;
    this.maxFavorites = 500;
    
    this.initializeDatabase();
  }

  /**
   * Inicializa o banco de dados SQLite
   * @private
   */
  async initializeDatabase() {
    try {
      // Verificar se estamos no Electron
      if (window.electronAPI && window.electronAPI.database) {
        this.db = window.electronAPI.database;
      } else {
        // Fallback para localStorage em ambiente de desenvolvimento
        this.db = new LocalStorageDB();
      }

      await this.createTables();
      
      this.isInitialized = true;
      console.log('FavoritesService inicializado com sucesso');
      
    } catch (error) {
      console.error('Erro ao inicializar FavoritesService:', error);
      // Fallback para localStorage
      this.db = new LocalStorageDB();
      this.isInitialized = true;
    }
  }

  /**
   * Cria tabelas necessárias
   * @private
   */
  async createTables() {
    const createFavoritesTable = `
      CREATE TABLE IF NOT EXISTS favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content_id TEXT NOT NULL,
        content_type TEXT NOT NULL,
        content_name TEXT NOT NULL,
        content_poster TEXT,
        content_description TEXT,
        content_genre TEXT,
        content_year INTEGER,
        content_rating REAL,
        content_duration INTEGER,
        stream_url TEXT,
        user_id TEXT NOT NULL,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(content_id, user_id)
      )
    `;

    const createCategoriesTable = `
      CREATE TABLE IF NOT EXISTS favorite_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        user_id TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(name, user_id)
      )
    `;

    const createCategoryMappingTable = `
      CREATE TABLE IF NOT EXISTS favorite_category_mapping (
        favorite_id INTEGER,
        category_id INTEGER,
        FOREIGN KEY(favorite_id) REFERENCES favorites(id) ON DELETE CASCADE,
        FOREIGN KEY(category_id) REFERENCES favorite_categories(id) ON DELETE CASCADE,
        PRIMARY KEY(favorite_id, category_id)
      )
    `;

    const createIndexes = [
      'CREATE INDEX IF NOT EXISTS idx_favorites_content_id ON favorites(content_id)',
      'CREATE INDEX IF NOT EXISTS idx_favorites_content_type ON favorites(content_type)',
      'CREATE INDEX IF NOT EXISTS idx_favorites_user_id ON favorites(user_id)',
      'CREATE INDEX IF NOT EXISTS idx_favorites_added_at ON favorites(added_at)',
      'CREATE INDEX IF NOT EXISTS idx_categories_user_id ON favorite_categories(user_id)'
    ];

    await this.db.exec(createFavoritesTable);
    await this.db.exec(createCategoriesTable);
    await this.db.exec(createCategoryMappingTable);
    
    for (const index of createIndexes) {
      await this.db.exec(index);
    }

    // Criar categorias padrão
    await this.createDefaultCategories();
  }

  /**
   * Cria categorias padrão
   * @private
   */
  async createDefaultCategories() {
    const defaultCategories = [
      { name: 'Assistir Mais Tarde', description: 'Conteúdo para assistir posteriormente' },
      { name: 'Favoritos', description: 'Meus conteúdos favoritos' },
      { name: 'Filmes', description: 'Filmes favoritos' },
      { name: 'Séries', description: 'Séries favoritas' },
      { name: 'Canais', description: 'Canais de TV favoritos' }
    ];

    for (const category of defaultCategories) {
      try {
        await this.createCategory(category.name, category.description, 'default');
      } catch (error) {
        // Categoria já existe, ignorar erro
      }
    }
  }

  /**
   * Adiciona conteúdo aos favoritos
   * @param {Object} content - Conteúdo a ser adicionado
   * @param {string} userId - ID do usuário
   * @param {string} categoryName - Nome da categoria (opcional)
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async addToFavorites(content, userId = 'default', categoryName = 'Favoritos') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      // Verificar se já está nos favoritos
      const existing = await this.getFavoriteItem(content.id, userId);
      if (existing) {
        return false; // Já está nos favoritos
      }

      // Verificar limite de favoritos
      const count = await this.getFavoritesCount(userId);
      if (count >= this.maxFavorites) {
        throw new Error(`Limite de ${this.maxFavorites} favoritos atingido`);
      }

      // Adicionar aos favoritos
      const favoriteId = await this.createFavoriteItem({
        content_id: content.id,
        content_type: content.type || 'unknown',
        content_name: content.name || content.title,
        content_poster: content.poster,
        content_description: content.description,
        content_genre: content.genre,
        content_year: content.year,
        content_rating: content.rating,
        content_duration: content.duration,
        stream_url: content.streamUrl,
        user_id: userId
      });

      // Adicionar à categoria se especificada
      if (categoryName && favoriteId) {
        const category = await this.getCategoryByName(categoryName, userId);
        if (category) {
          await this.addToCategory(favoriteId, category.id);
        }
      }

      return true;

    } catch (error) {
      console.error('Erro ao adicionar aos favoritos:', error);
      return false;
    }
  }

  /**
   * Remove conteúdo dos favoritos
   * @param {string} contentId - ID do conteúdo
   * @param {string} userId - ID do usuário
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async removeFromFavorites(contentId, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = 'DELETE FROM favorites WHERE content_id = ? AND user_id = ?';
      const result = await this.db.run(query, [contentId, userId]);
      return result.changes > 0;
    } catch (error) {
      console.error('Erro ao remover dos favoritos:', error);
      return false;
    }
  }

  /**
   * Verifica se conteúdo está nos favoritos
   * @param {string} contentId - ID do conteúdo
   * @param {string} userId - ID do usuário
   * @returns {Promise<boolean>} Se está nos favoritos
   */
  async isFavorite(contentId, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const item = await this.getFavoriteItem(contentId, userId);
      return !!item;
    } catch (error) {
      console.error('Erro ao verificar favorito:', error);
      return false;
    }
  }

  /**
   * Obtém todos os favoritos do usuário
   * @param {string} userId - ID do usuário
   * @param {string} contentType - Filtro por tipo (opcional)
   * @param {number} limit - Limite de itens
   * @param {number} offset - Offset para paginação
   * @returns {Promise<Array>} Lista de favoritos
   */
  async getFavorites(userId = 'default', contentType = null, limit = 100, offset = 0) {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      let query = `
        SELECT * FROM favorites 
        WHERE user_id = ?
      `;
      const params = [userId];

      if (contentType) {
        query += ' AND content_type = ?';
        params.push(contentType);
      }

      query += ' ORDER BY added_at DESC LIMIT ? OFFSET ?';
      params.push(limit, offset);

      const results = await this.db.all(query, params);
      return results.map(this.formatFavoriteItem);

    } catch (error) {
      console.error('Erro ao obter favoritos:', error);
      return [];
    }
  }

  /**
   * Obtém favoritos por categoria
   * @param {string} categoryName - Nome da categoria
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Lista de favoritos da categoria
   */
  async getFavoritesByCategory(categoryName, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        SELECT f.* FROM favorites f
        JOIN favorite_category_mapping fcm ON f.id = fcm.favorite_id
        JOIN favorite_categories fc ON fcm.category_id = fc.id
        WHERE fc.name = ? AND f.user_id = ?
        ORDER BY f.added_at DESC
      `;

      const results = await this.db.all(query, [categoryName, userId]);
      return results.map(this.formatFavoriteItem);

    } catch (error) {
      console.error('Erro ao obter favoritos por categoria:', error);
      return [];
    }
  }

  /**
   * Cria nova categoria de favoritos
   * @param {string} name - Nome da categoria
   * @param {string} description - Descrição da categoria
   * @param {string} userId - ID do usuário
   * @returns {Promise<number>} ID da categoria criada
   */
  async createCategory(name, description = '', userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        INSERT INTO favorite_categories (name, description, user_id)
        VALUES (?, ?, ?)
      `;
      const result = await this.db.run(query, [name, description, userId]);
      return result.lastID;
    } catch (error) {
      console.error('Erro ao criar categoria:', error);
      throw error;
    }
  }

  /**
   * Obtém todas as categorias do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Lista de categorias
   */
  async getCategories(userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = `
        SELECT fc.*, COUNT(fcm.favorite_id) as item_count
        FROM favorite_categories fc
        LEFT JOIN favorite_category_mapping fcm ON fc.id = fcm.category_id
        WHERE fc.user_id = ?
        GROUP BY fc.id
        ORDER BY fc.name
      `;

      return await this.db.all(query, [userId]);
    } catch (error) {
      console.error('Erro ao obter categorias:', error);
      return [];
    }
  }

  /**
   * Remove categoria
   * @param {number} categoryId - ID da categoria
   * @param {string} userId - ID do usuário
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async removeCategory(categoryId, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = 'DELETE FROM favorite_categories WHERE id = ? AND user_id = ?';
      const result = await this.db.run(query, [categoryId, userId]);
      return result.changes > 0;
    } catch (error) {
      console.error('Erro ao remover categoria:', error);
      return false;
    }
  }

  /**
   * Move favorito para categoria
   * @param {string} contentId - ID do conteúdo
   * @param {string} categoryName - Nome da categoria
   * @param {string} userId - ID do usuário
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async moveToCategory(contentId, categoryName, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const favorite = await this.getFavoriteItem(contentId, userId);
      const category = await this.getCategoryByName(categoryName, userId);

      if (!favorite || !category) {
        return false;
      }

      // Remover de todas as categorias atuais
      await this.removeFromAllCategories(favorite.id);

      // Adicionar à nova categoria
      await this.addToCategory(favorite.id, category.id);

      return true;
    } catch (error) {
      console.error('Erro ao mover para categoria:', error);
      return false;
    }
  }

  /**
   * Obtém estatísticas dos favoritos
   * @param {string} userId - ID do usuário
   * @returns {Promise<Object>} Estatísticas dos favoritos
   */
  async getFavoritesStats(userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const queries = {
        total: 'SELECT COUNT(*) as count FROM favorites WHERE user_id = ?',
        byType: `
          SELECT content_type, COUNT(*) as count 
          FROM favorites WHERE user_id = ? 
          GROUP BY content_type
        `,
        byGenre: `
          SELECT content_genre, COUNT(*) as count 
          FROM favorites WHERE user_id = ? AND content_genre IS NOT NULL
          GROUP BY content_genre 
          ORDER BY count DESC 
          LIMIT 10
        `,
        recentlyAdded: `
          SELECT DATE(added_at) as date, COUNT(*) as count 
          FROM favorites WHERE user_id = ? 
          AND added_at >= date('now', '-30 days')
          GROUP BY DATE(added_at) 
          ORDER BY date DESC
        `
      };

      const [total, byType, byGenre, recentlyAdded] = await Promise.all([
        this.db.get(queries.total, [userId]),
        this.db.all(queries.byType, [userId]),
        this.db.all(queries.byGenre, [userId]),
        this.db.all(queries.recentlyAdded, [userId])
      ]);

      return {
        totalFavorites: total.count || 0,
        byType: byType || [],
        topGenres: byGenre || [],
        recentActivity: recentlyAdded || []
      };

    } catch (error) {
      console.error('Erro ao obter estatísticas dos favoritos:', error);
      return {
        totalFavorites: 0,
        byType: [],
        topGenres: [],
        recentActivity: []
      };
    }
  }

  /**
   * Busca nos favoritos
   * @param {string} query - Termo de busca
   * @param {string} userId - ID do usuário
   * @returns {Promise<Array>} Resultados da busca
   */
  async searchFavorites(query, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const searchQuery = `
        SELECT * FROM favorites 
        WHERE user_id = ? 
        AND (
          content_name LIKE ? OR 
          content_description LIKE ? OR 
          content_genre LIKE ?
        )
        ORDER BY added_at DESC
      `;

      const searchTerm = `%${query}%`;
      const results = await this.db.all(searchQuery, [userId, searchTerm, searchTerm, searchTerm]);
      return results.map(this.formatFavoriteItem);

    } catch (error) {
      console.error('Erro ao buscar favoritos:', error);
      return [];
    }
  }

  /**
   * Limpa todos os favoritos do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async clearFavorites(userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const query = 'DELETE FROM favorites WHERE user_id = ?';
      await this.db.run(query, [userId]);
      return true;
    } catch (error) {
      console.error('Erro ao limpar favoritos:', error);
      return false;
    }
  }

  /**
   * Exporta favoritos para JSON
   * @param {string} userId - ID do usuário
   * @returns {Promise<string>} JSON dos favoritos
   */
  async exportFavorites(userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const favorites = await this.getFavorites(userId, null, 1000);
      const categories = await this.getCategories(userId);

      const exportData = {
        version: '1.0',
        exportDate: new Date().toISOString(),
        userId,
        favorites,
        categories
      };

      return JSON.stringify(exportData, null, 2);
    } catch (error) {
      console.error('Erro ao exportar favoritos:', error);
      return null;
    }
  }

  /**
   * Importa favoritos de JSON
   * @param {string} jsonData - Dados JSON dos favoritos
   * @param {string} userId - ID do usuário
   * @returns {Promise<boolean>} Sucesso da operação
   */
  async importFavorites(jsonData, userId = 'default') {
    if (!this.isInitialized) {
      await this.waitForInitialization();
    }

    try {
      const data = JSON.parse(jsonData);
      
      if (!data.favorites || !Array.isArray(data.favorites)) {
        throw new Error('Formato de dados inválido');
      }

      // Importar categorias primeiro
      if (data.categories && Array.isArray(data.categories)) {
        for (const category of data.categories) {
          try {
            await this.createCategory(category.name, category.description, userId);
          } catch (error) {
            // Categoria já existe, continuar
          }
        }
      }

      // Importar favoritos
      let imported = 0;
      for (const favorite of data.favorites) {
        const success = await this.addToFavorites({
          id: favorite.id,
          type: favorite.type,
          name: favorite.name,
          poster: favorite.poster,
          description: favorite.description,
          genre: favorite.genre,
          year: favorite.year,
          rating: favorite.rating,
          duration: favorite.duration,
          streamUrl: favorite.streamUrl
        }, userId);

        if (success) {
          imported++;
        }
      }

      console.log(`Importados ${imported} de ${data.favorites.length} favoritos`);
      return true;

    } catch (error) {
      console.error('Erro ao importar favoritos:', error);
      return false;
    }
  }

  // Métodos auxiliares privados

  async createFavoriteItem(data) {
    const query = `
      INSERT INTO favorites (
        content_id, content_type, content_name, content_poster, content_description,
        content_genre, content_year, content_rating, content_duration, stream_url, user_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const params = [
      data.content_id,
      data.content_type,
      data.content_name,
      data.content_poster,
      data.content_description,
      data.content_genre,
      data.content_year,
      data.content_rating,
      data.content_duration,
      data.stream_url,
      data.user_id
    ];

    const result = await this.db.run(query, params);
    return result.lastID;
  }

  async getFavoriteItem(contentId, userId) {
    const query = 'SELECT * FROM favorites WHERE content_id = ? AND user_id = ?';
    return await this.db.get(query, [contentId, userId]);
  }

  async getFavoritesCount(userId) {
    const query = 'SELECT COUNT(*) as count FROM favorites WHERE user_id = ?';
    const result = await this.db.get(query, [userId]);
    return result.count || 0;
  }

  async getCategoryByName(name, userId) {
    const query = 'SELECT * FROM favorite_categories WHERE name = ? AND user_id = ?';
    return await this.db.get(query, [name, userId]);
  }

  async addToCategory(favoriteId, categoryId) {
    const query = 'INSERT OR IGNORE INTO favorite_category_mapping (favorite_id, category_id) VALUES (?, ?)';
    return await this.db.run(query, [favoriteId, categoryId]);
  }

  async removeFromAllCategories(favoriteId) {
    const query = 'DELETE FROM favorite_category_mapping WHERE favorite_id = ?';
    return await this.db.run(query, [favoriteId]);
  }

  formatFavoriteItem(item) {
    return {
      id: item.content_id,
      type: item.content_type,
      name: item.content_name,
      poster: item.content_poster,
      description: item.content_description,
      genre: item.content_genre,
      year: item.content_year,
      rating: item.content_rating,
      duration: item.content_duration,
      streamUrl: item.stream_url,
      addedAt: new Date(item.added_at),
      updatedAt: new Date(item.updated_at)
    };
  }

  async waitForInitialization() {
    while (!this.isInitialized) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
}

/**
 * Implementação de fallback usando localStorage
 * @private
 */
class LocalStorageDB {
  constructor() {
    this.storageKey = 'iptv_favorites';
    this.categoriesKey = 'iptv_favorite_categories';
    this.data = this.loadData();
    this.categories = this.loadCategories();
  }

  loadData() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Erro ao carregar favoritos do localStorage:', error);
      return [];
    }
  }

  loadCategories() {
    try {
      const saved = localStorage.getItem(this.categoriesKey);
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Erro ao carregar categorias do localStorage:', error);
      return [];
    }
  }

  saveData() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.data));
      localStorage.setItem(this.categoriesKey, JSON.stringify(this.categories));
    } catch (error) {
      console.error('Erro ao salvar dados no localStorage:', error);
    }
  }

  async exec(query) {
    return Promise.resolve();
  }

  async run(query, params = []) {
    this.saveData();
    return Promise.resolve({ lastID: Date.now(), changes: 1 });
  }

  async get(query, params = []) {
    const results = await this.all(query, params);
    return results[0] || null;
  }

  async all(query, params = []) {
    // Implementação simplificada
    return Promise.resolve(this.data.filter(item => {
      if (params.length > 0 && params[0]) {
        return item.user_id === params[0];
      }
      return true;
    }));
  }
}

// Instância singleton
const favoritesService = new FavoritesService();

export default favoritesService;

