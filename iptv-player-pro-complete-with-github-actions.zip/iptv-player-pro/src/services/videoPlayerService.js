/**
 * Serviço avançado para reprodução de vídeo
 * Suporta múltiplos formatos e funcionalidades avançadas
 */
class VideoPlayerService {
  constructor() {
    this.player = null;
    this.currentMedia = null;
    this.isPlaying = false;
    this.volume = 1.0;
    this.currentTime = 0;
    this.duration = 0;
    this.playbackRate = 1.0;
    this.subtitles = [];
    this.audioTracks = [];
    this.currentSubtitle = -1;
    this.currentAudioTrack = 0;
    this.isFullscreen = false;
    this.eventListeners = new Map();
    
    // Configurações do player
    this.config = {
      autoplay: true,
      controls: false, // Usar controles customizados
      preload: 'metadata',
      crossOrigin: 'anonymous',
      playsinline: true
    };

    // Formatos suportados
    this.supportedFormats = {
      hls: ['.m3u8'],
      dash: ['.mpd'],
      mp4: ['.mp4', '.mov', '.avi'],
      webm: ['.webm'],
      mkv: ['.mkv'],
      ts: ['.ts'],
      rtmp: ['rtmp://'],
      rtsp: ['rtsp://']
    };

    this.initializePlayer();
  }

  /**
   * Inicializa o player de vídeo
   * @private
   */
  initializePlayer() {
    // Criar elemento de vídeo se não existir
    if (!this.player) {
      this.player = document.createElement('video');
      this.player.id = 'iptv-video-player';
      this.setupPlayerEvents();
    }
  }

  /**
   * Configura eventos do player
   * @private
   */
  setupPlayerEvents() {
    const events = [
      'loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough',
      'play', 'pause', 'ended', 'error', 'timeupdate', 'volumechange',
      'seeking', 'seeked', 'waiting', 'stalled', 'progress', 'durationchange'
    ];

    events.forEach(event => {
      this.player.addEventListener(event, (e) => {
        this.handlePlayerEvent(event, e);
      });
    });

    // Eventos de teclado para controle
    document.addEventListener('keydown', (e) => {
      this.handleKeyboardEvent(e);
    });

    // Eventos de fullscreen
    document.addEventListener('fullscreenchange', () => {
      this.isFullscreen = !!document.fullscreenElement;
      this.emit('fullscreenchange', this.isFullscreen);
    });
  }

  /**
   * Manipula eventos do player
   * @private
   */
  handlePlayerEvent(eventType, event) {
    switch (eventType) {
      case 'loadedmetadata':
        this.duration = this.player.duration;
        this.loadSubtitles();
        this.loadAudioTracks();
        break;
        
      case 'timeupdate':
        this.currentTime = this.player.currentTime;
        break;
        
      case 'play':
        this.isPlaying = true;
        break;
        
      case 'pause':
        this.isPlaying = false;
        break;
        
      case 'ended':
        this.isPlaying = false;
        this.emit('ended', this.currentMedia);
        break;
        
      case 'error':
        this.handlePlayerError(event);
        break;
        
      case 'volumechange':
        this.volume = this.player.volume;
        break;
    }

    // Emitir evento para listeners externos
    this.emit(eventType, event);
  }

  /**
   * Manipula eventos de teclado
   * @private
   */
  handleKeyboardEvent(event) {
    if (!this.player || !this.currentMedia) return;

    switch (event.code) {
      case 'Space':
        event.preventDefault();
        this.togglePlayPause();
        break;
        
      case 'ArrowLeft':
        event.preventDefault();
        this.seek(this.currentTime - 10);
        break;
        
      case 'ArrowRight':
        event.preventDefault();
        this.seek(this.currentTime + 10);
        break;
        
      case 'ArrowUp':
        event.preventDefault();
        this.setVolume(Math.min(1, this.volume + 0.1));
        break;
        
      case 'ArrowDown':
        event.preventDefault();
        this.setVolume(Math.max(0, this.volume - 0.1));
        break;
        
      case 'KeyF':
        event.preventDefault();
        this.toggleFullscreen();
        break;
        
      case 'KeyM':
        event.preventDefault();
        this.toggleMute();
        break;
        
      case 'Escape':
        if (this.isFullscreen) {
          event.preventDefault();
          this.exitFullscreen();
        }
        break;
    }
  }

  /**
   * Carrega e reproduz mídia
   * @param {Object} media - Objeto com informações da mídia
   * @param {HTMLElement} container - Container onde inserir o player
   */
  async loadMedia(media, container) {
    try {
      this.currentMedia = media;
      
      // Inserir player no container
      if (container && !container.contains(this.player)) {
        container.appendChild(this.player);
      }

      // Determinar tipo de mídia e carregar
      const mediaType = this.detectMediaType(media.streamUrl || media.url);
      
      switch (mediaType) {
        case 'hls':
          await this.loadHLS(media.streamUrl || media.url);
          break;
          
        case 'dash':
          await this.loadDASH(media.streamUrl || media.url);
          break;
          
        case 'rtmp':
        case 'rtsp':
          await this.loadRTMP(media.streamUrl || media.url);
          break;
          
        default:
          await this.loadNative(media.streamUrl || media.url);
          break;
      }

      // Configurar player
      this.player.poster = media.poster || '';
      
      // Auto-play se configurado
      if (this.config.autoplay) {
        await this.play();
      }

      this.emit('mediaLoaded', media);
      
    } catch (error) {
      console.error('Erro ao carregar mídia:', error);
      this.emit('error', { type: 'load_error', error, media });
      throw error;
    }
  }

  /**
   * Detecta o tipo de mídia baseado na URL
   * @private
   */
  detectMediaType(url) {
    if (!url) return 'unknown';
    
    const urlLower = url.toLowerCase();
    
    if (urlLower.includes('.m3u8') || urlLower.includes('hls')) {
      return 'hls';
    }
    
    if (urlLower.includes('.mpd') || urlLower.includes('dash')) {
      return 'dash';
    }
    
    if (urlLower.startsWith('rtmp://')) {
      return 'rtmp';
    }
    
    if (urlLower.startsWith('rtsp://')) {
      return 'rtsp';
    }
    
    return 'native';
  }

  /**
   * Carrega stream HLS
   * @private
   */
  async loadHLS(url) {
    if (this.player.canPlayType('application/vnd.apple.mpegurl')) {
      // Suporte nativo a HLS
      this.player.src = url;
    } else {
      // Usar HLS.js para navegadores que não suportam HLS nativamente
      if (window.Hls && window.Hls.isSupported()) {
        if (this.hls) {
          this.hls.destroy();
        }
        
        this.hls = new window.Hls({
          enableWorker: true,
          lowLatencyMode: true,
          backBufferLength: 90
        });
        
        this.hls.loadSource(url);
        this.hls.attachMedia(this.player);
        
        this.hls.on(window.Hls.Events.ERROR, (event, data) => {
          console.error('HLS Error:', data);
          this.emit('error', { type: 'hls_error', data });
        });
        
      } else {
        throw new Error('HLS não suportado neste navegador');
      }
    }
  }

  /**
   * Carrega stream DASH
   * @private
   */
  async loadDASH(url) {
    if (window.dashjs) {
      if (this.dashPlayer) {
        this.dashPlayer.reset();
      }
      
      this.dashPlayer = window.dashjs.MediaPlayer().create();
      this.dashPlayer.initialize(this.player, url, this.config.autoplay);
      
      this.dashPlayer.on('error', (error) => {
        console.error('DASH Error:', error);
        this.emit('error', { type: 'dash_error', error });
      });
      
    } else {
      throw new Error('DASH.js não está disponível');
    }
  }

  /**
   * Carrega stream RTMP/RTSP
   * @private
   */
  async loadRTMP(url) {
    // Para RTMP/RTSP, seria necessário usar WebRTC ou um plugin
    // Por enquanto, tentar carregar nativamente
    this.player.src = url;
  }

  /**
   * Carrega mídia nativa (MP4, WebM, etc.)
   * @private
   */
  async loadNative(url) {
    this.player.src = url;
  }

  /**
   * Inicia reprodução
   */
  async play() {
    try {
      await this.player.play();
      this.isPlaying = true;
      this.emit('play');
    } catch (error) {
      console.error('Erro ao iniciar reprodução:', error);
      this.emit('error', { type: 'play_error', error });
      throw error;
    }
  }

  /**
   * Pausa reprodução
   */
  pause() {
    this.player.pause();
    this.isPlaying = false;
    this.emit('pause');
  }

  /**
   * Alterna entre play/pause
   */
  togglePlayPause() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  /**
   * Para reprodução
   */
  stop() {
    this.pause();
    this.seek(0);
    this.emit('stop');
  }

  /**
   * Navega para posição específica
   * @param {number} time - Tempo em segundos
   */
  seek(time) {
    if (this.player && this.duration > 0) {
      this.player.currentTime = Math.max(0, Math.min(time, this.duration));
      this.currentTime = this.player.currentTime;
      this.emit('seek', this.currentTime);
    }
  }

  /**
   * Define volume
   * @param {number} volume - Volume de 0 a 1
   */
  setVolume(volume) {
    const newVolume = Math.max(0, Math.min(1, volume));
    this.player.volume = newVolume;
    this.volume = newVolume;
    this.emit('volumechange', newVolume);
  }

  /**
   * Alterna mudo
   */
  toggleMute() {
    this.player.muted = !this.player.muted;
    this.emit('mutechange', this.player.muted);
  }

  /**
   * Define velocidade de reprodução
   * @param {number} rate - Taxa de reprodução (0.5, 1, 1.5, 2, etc.)
   */
  setPlaybackRate(rate) {
    this.player.playbackRate = rate;
    this.playbackRate = rate;
    this.emit('ratechange', rate);
  }

  /**
   * Entra em tela cheia
   */
  async enterFullscreen() {
    try {
      if (this.player.requestFullscreen) {
        await this.player.requestFullscreen();
      } else if (this.player.webkitRequestFullscreen) {
        await this.player.webkitRequestFullscreen();
      } else if (this.player.msRequestFullscreen) {
        await this.player.msRequestFullscreen();
      }
      this.isFullscreen = true;
    } catch (error) {
      console.error('Erro ao entrar em tela cheia:', error);
    }
  }

  /**
   * Sai da tela cheia
   */
  async exitFullscreen() {
    try {
      if (document.exitFullscreen) {
        await document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        await document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) {
        await document.msExitFullscreen();
      }
      this.isFullscreen = false;
    } catch (error) {
      console.error('Erro ao sair da tela cheia:', error);
    }
  }

  /**
   * Alterna tela cheia
   */
  toggleFullscreen() {
    if (this.isFullscreen) {
      this.exitFullscreen();
    } else {
      this.enterFullscreen();
    }
  }

  /**
   * Carrega legendas disponíveis
   * @private
   */
  loadSubtitles() {
    this.subtitles = [];
    
    // Carregar legendas do elemento de vídeo
    const tracks = this.player.textTracks;
    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];
      if (track.kind === 'subtitles' || track.kind === 'captions') {
        this.subtitles.push({
          index: i,
          label: track.label || `Legenda ${i + 1}`,
          language: track.language || 'unknown',
          track: track
        });
      }
    }

    this.emit('subtitlesLoaded', this.subtitles);
  }

  /**
   * Carrega faixas de áudio disponíveis
   * @private
   */
  loadAudioTracks() {
    this.audioTracks = [];
    
    // Para HLS, as faixas de áudio são gerenciadas pelo HLS.js
    if (this.hls && this.hls.audioTracks) {
      this.audioTracks = this.hls.audioTracks.map((track, index) => ({
        index,
        label: track.name || `Áudio ${index + 1}`,
        language: track.lang || 'unknown',
        track
      }));
    }

    this.emit('audioTracksLoaded', this.audioTracks);
  }

  /**
   * Define legenda ativa
   * @param {number} index - Índice da legenda (-1 para desabilitar)
   */
  setSubtitle(index) {
    // Desabilitar todas as legendas
    for (let i = 0; i < this.player.textTracks.length; i++) {
      this.player.textTracks[i].mode = 'disabled';
    }

    if (index >= 0 && index < this.subtitles.length) {
      this.subtitles[index].track.mode = 'showing';
      this.currentSubtitle = index;
    } else {
      this.currentSubtitle = -1;
    }

    this.emit('subtitleChange', this.currentSubtitle);
  }

  /**
   * Define faixa de áudio ativa
   * @param {number} index - Índice da faixa de áudio
   */
  setAudioTrack(index) {
    if (this.hls && index >= 0 && index < this.audioTracks.length) {
      this.hls.currentLevel = index;
      this.currentAudioTrack = index;
      this.emit('audioTrackChange', this.currentAudioTrack);
    }
  }

  /**
   * Manipula erros do player
   * @private
   */
  handlePlayerError(event) {
    const error = this.player.error;
    let errorMessage = 'Erro desconhecido';

    if (error) {
      switch (error.code) {
        case error.MEDIA_ERR_ABORTED:
          errorMessage = 'Reprodução abortada';
          break;
        case error.MEDIA_ERR_NETWORK:
          errorMessage = 'Erro de rede';
          break;
        case error.MEDIA_ERR_DECODE:
          errorMessage = 'Erro de decodificação';
          break;
        case error.MEDIA_ERR_SRC_NOT_SUPPORTED:
          errorMessage = 'Formato não suportado';
          break;
      }
    }

    console.error('Player Error:', errorMessage, error);
    this.emit('error', { type: 'player_error', message: errorMessage, error });
  }

  /**
   * Adiciona listener de evento
   * @param {string} event - Nome do evento
   * @param {Function} callback - Função callback
   */
  on(event, callback) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(callback);
  }

  /**
   * Remove listener de evento
   * @param {string} event - Nome do evento
   * @param {Function} callback - Função callback
   */
  off(event, callback) {
    if (this.eventListeners.has(event)) {
      const listeners = this.eventListeners.get(event);
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }

  /**
   * Emite evento
   * @private
   */
  emit(event, data) {
    if (this.eventListeners.has(event)) {
      this.eventListeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('Erro no listener de evento:', error);
        }
      });
    }
  }

  /**
   * Obtém estado atual do player
   */
  getState() {
    return {
      isPlaying: this.isPlaying,
      currentTime: this.currentTime,
      duration: this.duration,
      volume: this.volume,
      playbackRate: this.playbackRate,
      isFullscreen: this.isFullscreen,
      currentMedia: this.currentMedia,
      subtitles: this.subtitles,
      audioTracks: this.audioTracks,
      currentSubtitle: this.currentSubtitle,
      currentAudioTrack: this.currentAudioTrack
    };
  }

  /**
   * Limpa recursos do player
   */
  destroy() {
    if (this.hls) {
      this.hls.destroy();
      this.hls = null;
    }

    if (this.dashPlayer) {
      this.dashPlayer.reset();
      this.dashPlayer = null;
    }

    if (this.player) {
      this.player.pause();
      this.player.src = '';
      this.player.load();
      
      if (this.player.parentNode) {
        this.player.parentNode.removeChild(this.player);
      }
    }

    this.eventListeners.clear();
    this.currentMedia = null;
    this.isPlaying = false;
  }
}

// Instância singleton
const videoPlayerService = new VideoPlayerService();

export default videoPlayerService;

