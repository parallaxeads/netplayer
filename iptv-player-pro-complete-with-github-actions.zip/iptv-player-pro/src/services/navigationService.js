/**
 * Serviço de navegação avançado
 * Gerencia navegação via mouse, teclado e controle remoto
 */
class NavigationService {
  constructor() {
    this.currentFocus = null;
    this.focusableElements = [];
    this.navigationMode = 'mouse'; // 'mouse', 'keyboard', 'remote'
    this.keyboardNavigation = true;
    this.remoteNavigation = true;
    this.eventListeners = new Map();
    this.navigationHistory = [];
    this.shortcuts = new Map();
    
    // Configurações de navegação
    this.config = {
      focusClass: 'nav-focused',
      focusVisibleClass: 'nav-focus-visible',
      scrollIntoView: true,
      scrollBehavior: 'smooth',
      wrapNavigation: true,
      rememberLastFocus: true
    };

    // Elementos focáveis por padrão
    this.focusableSelectors = [
      'button:not([disabled])',
      'input:not([disabled])',
      'select:not([disabled])',
      'textarea:not([disabled])',
      'a[href]',
      '[tabindex]:not([tabindex="-1"])',
      '.focusable:not(.disabled)',
      '.nav-item:not(.disabled)'
    ];

    this.initializeNavigation();
  }

  /**
   * Inicializa o sistema de navegação
   * @private
   */
  initializeNavigation() {
    this.setupKeyboardListeners();
    this.setupMouseListeners();
    this.setupRemoteListeners();
    this.setupDefaultShortcuts();
    this.updateFocusableElements();
    
    // Atualizar elementos focáveis quando o DOM muda
    this.observeDOM();
  }

  /**
   * Configura listeners de teclado
   * @private
   */
  setupKeyboardListeners() {
    document.addEventListener('keydown', (event) => {
      this.handleKeyboardEvent(event);
    });

    document.addEventListener('keyup', (event) => {
      this.handleKeyboardUpEvent(event);
    });

    // Detectar quando o usuário começa a usar o teclado
    document.addEventListener('keydown', () => {
      if (this.navigationMode !== 'keyboard') {
        this.setNavigationMode('keyboard');
      }
    });
  }

  /**
   * Configura listeners de mouse
   * @private
   */
  setupMouseListeners() {
    document.addEventListener('mousemove', () => {
      if (this.navigationMode !== 'mouse') {
        this.setNavigationMode('mouse');
      }
    });

    document.addEventListener('click', (event) => {
      this.handleMouseClick(event);
    });

    // Hover para elementos focáveis
    document.addEventListener('mouseover', (event) => {
      if (this.navigationMode === 'mouse') {
        const focusable = this.findFocusableElement(event.target);
        if (focusable && focusable !== this.currentFocus) {
          this.setFocus(focusable, false);
        }
      }
    });
  }

  /**
   * Configura listeners para controle remoto
   * @private
   */
  setupRemoteListeners() {
    // Listeners para eventos do Electron (controle remoto via USB/Bluetooth)
    if (window.electronAPI) {
      window.electronAPI.onRemoteKey((keyCode) => {
        this.handleRemoteKey(keyCode);
      });
    }

    // Gamepad API para controles de jogo
    window.addEventListener('gamepadconnected', (event) => {
      console.log('Controle conectado:', event.gamepad.id);
      this.startGamepadPolling();
    });

    window.addEventListener('gamepaddisconnected', (event) => {
      console.log('Controle desconectado:', event.gamepad.id);
      this.stopGamepadPolling();
    });
  }

  /**
   * Configura atalhos padrão
   * @private
   */
  setupDefaultShortcuts() {
    // Atalhos globais da aplicação
    this.addShortcut('Escape', () => this.handleEscape());
    this.addShortcut('F11', () => this.toggleFullscreen());
    this.addShortcut('Control+F', () => this.focusSearch());
    this.addShortcut('Control+H', () => this.goHome());
    this.addShortcut('Control+S', () => this.openSettings());
    this.addShortcut('Control+Q', () => this.quit());
    
    // Atalhos de navegação
    this.addShortcut('Tab', () => this.navigateNext());
    this.addShortcut('Shift+Tab', () => this.navigatePrevious());
    this.addShortcut('Enter', () => this.activateCurrentFocus());
    this.addShortcut('Space', () => this.activateCurrentFocus());
    
    // Navegação direcional
    this.addShortcut('ArrowUp', () => this.navigateUp());
    this.addShortcut('ArrowDown', () => this.navigateDown());
    this.addShortcut('ArrowLeft', () => this.navigateLeft());
    this.addShortcut('ArrowRight', () => this.navigateRight());
    
    // Atalhos do player
    this.addShortcut('MediaPlayPause', () => this.emit('player-toggle'));
    this.addShortcut('MediaStop', () => this.emit('player-stop'));
    this.addShortcut('MediaTrackNext', () => this.emit('player-next'));
    this.addShortcut('MediaTrackPrevious', () => this.emit('player-previous'));
    this.addShortcut('VolumeUp', () => this.emit('volume-up'));
    this.addShortcut('VolumeDown', () => this.emit('volume-down'));
    this.addShortcut('VolumeMute', () => this.emit('volume-mute'));
  }

  /**
   * Observa mudanças no DOM
   * @private
   */
  observeDOM() {
    const observer = new MutationObserver(() => {
      this.updateFocusableElements();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['disabled', 'tabindex', 'class']
    });

    this.domObserver = observer;
  }

  /**
   * Atualiza lista de elementos focáveis
   */
  updateFocusableElements() {
    const selector = this.focusableSelectors.join(', ');
    this.focusableElements = Array.from(document.querySelectorAll(selector))
      .filter(el => this.isElementVisible(el) && !this.isElementDisabled(el));
    
    // Organizar por posição na tela para navegação direcional
    this.organizeFocusableElements();
  }

  /**
   * Organiza elementos focáveis por posição
   * @private
   */
  organizeFocusableElements() {
    this.focusableElements.forEach(el => {
      const rect = el.getBoundingClientRect();
      el._navRect = {
        top: rect.top,
        left: rect.left,
        right: rect.right,
        bottom: rect.bottom,
        centerX: rect.left + rect.width / 2,
        centerY: rect.top + rect.height / 2
      };
    });
  }

  /**
   * Verifica se elemento está visível
   * @private
   */
  isElementVisible(element) {
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    
    return rect.width > 0 && 
           rect.height > 0 && 
           style.visibility !== 'hidden' && 
           style.display !== 'none' &&
           element.offsetParent !== null;
  }

  /**
   * Verifica se elemento está desabilitado
   * @private
   */
  isElementDisabled(element) {
    return element.disabled || 
           element.classList.contains('disabled') ||
           element.getAttribute('aria-disabled') === 'true';
  }

  /**
   * Manipula eventos de teclado
   * @private
   */
  handleKeyboardEvent(event) {
    const key = this.getKeyString(event);
    
    // Verificar atalhos primeiro
    if (this.shortcuts.has(key)) {
      const shortcut = this.shortcuts.get(key);
      if (shortcut.condition ? shortcut.condition() : true) {
        event.preventDefault();
        shortcut.action();
        return;
      }
    }

    // Navegação direcional
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) {
      if (this.keyboardNavigation) {
        event.preventDefault();
        this.handleDirectionalNavigation(event.key);
      }
    }

    // Tab navigation
    if (event.key === 'Tab' && this.keyboardNavigation) {
      event.preventDefault();
      if (event.shiftKey) {
        this.navigatePrevious();
      } else {
        this.navigateNext();
      }
    }

    // Enter/Space para ativar
    if (['Enter', ' '].includes(event.key) && this.currentFocus) {
      event.preventDefault();
      this.activateElement(this.currentFocus);
    }

    this.emit('keydown', { event, key });
  }

  /**
   * Manipula eventos de teclado (keyup)
   * @private
   */
  handleKeyboardUpEvent(event) {
    const key = this.getKeyString(event);
    this.emit('keyup', { event, key });
  }

  /**
   * Manipula cliques do mouse
   * @private
   */
  handleMouseClick(event) {
    const focusable = this.findFocusableElement(event.target);
    if (focusable) {
      this.setFocus(focusable, false);
    }
  }

  /**
   * Manipula teclas do controle remoto
   * @private
   */
  handleRemoteKey(keyCode) {
    if (!this.remoteNavigation) return;

    const keyMap = {
      37: 'ArrowLeft',    // Left
      38: 'ArrowUp',      // Up
      39: 'ArrowRight',   // Right
      40: 'ArrowDown',    // Down
      13: 'Enter',        // OK/Select
      27: 'Escape',       // Back
      32: 'Space',        // Play/Pause
      179: 'MediaPlayPause',
      178: 'MediaStop',
      176: 'MediaTrackNext',
      177: 'MediaTrackPrevious'
    };

    const key = keyMap[keyCode];
    if (key) {
      this.handleVirtualKey(key);
    }
  }

  /**
   * Manipula tecla virtual
   * @private
   */
  handleVirtualKey(key) {
    const event = new KeyboardEvent('keydown', { key });
    this.handleKeyboardEvent(event);
  }

  /**
   * Obtém string da tecla pressionada
   * @private
   */
  getKeyString(event) {
    const modifiers = [];
    if (event.ctrlKey) modifiers.push('Control');
    if (event.altKey) modifiers.push('Alt');
    if (event.shiftKey) modifiers.push('Shift');
    if (event.metaKey) modifiers.push('Meta');
    
    modifiers.push(event.key);
    return modifiers.join('+');
  }

  /**
   * Manipula navegação direcional
   * @private
   */
  handleDirectionalNavigation(direction) {
    if (!this.currentFocus) {
      this.setFocus(this.focusableElements[0]);
      return;
    }

    const nextElement = this.findNextElementInDirection(this.currentFocus, direction);
    if (nextElement) {
      this.setFocus(nextElement);
    }
  }

  /**
   * Encontra próximo elemento na direção especificada
   * @private
   */
  findNextElementInDirection(currentElement, direction) {
    if (!currentElement._navRect) return null;

    const current = currentElement._navRect;
    let bestElement = null;
    let bestDistance = Infinity;

    this.focusableElements.forEach(element => {
      if (element === currentElement || !element._navRect) return;

      const rect = element._navRect;
      let isInDirection = false;
      let distance = 0;

      switch (direction) {
        case 'ArrowUp':
          isInDirection = rect.centerY < current.centerY;
          distance = current.centerY - rect.centerY + Math.abs(current.centerX - rect.centerX) * 0.3;
          break;
        case 'ArrowDown':
          isInDirection = rect.centerY > current.centerY;
          distance = rect.centerY - current.centerY + Math.abs(current.centerX - rect.centerX) * 0.3;
          break;
        case 'ArrowLeft':
          isInDirection = rect.centerX < current.centerX;
          distance = current.centerX - rect.centerX + Math.abs(current.centerY - rect.centerY) * 0.3;
          break;
        case 'ArrowRight':
          isInDirection = rect.centerX > current.centerX;
          distance = rect.centerX - current.centerX + Math.abs(current.centerY - rect.centerY) * 0.3;
          break;
      }

      if (isInDirection && distance < bestDistance) {
        bestDistance = distance;
        bestElement = element;
      }
    });

    return bestElement;
  }

  /**
   * Navega para o próximo elemento
   */
  navigateNext() {
    if (this.focusableElements.length === 0) return;

    let nextIndex = 0;
    if (this.currentFocus) {
      const currentIndex = this.focusableElements.indexOf(this.currentFocus);
      nextIndex = (currentIndex + 1) % this.focusableElements.length;
    }

    this.setFocus(this.focusableElements[nextIndex]);
  }

  /**
   * Navega para o elemento anterior
   */
  navigatePrevious() {
    if (this.focusableElements.length === 0) return;

    let prevIndex = this.focusableElements.length - 1;
    if (this.currentFocus) {
      const currentIndex = this.focusableElements.indexOf(this.currentFocus);
      prevIndex = currentIndex === 0 ? this.focusableElements.length - 1 : currentIndex - 1;
    }

    this.setFocus(this.focusableElements[prevIndex]);
  }

  /**
   * Navega para cima
   */
  navigateUp() {
    this.handleDirectionalNavigation('ArrowUp');
  }

  /**
   * Navega para baixo
   */
  navigateDown() {
    this.handleDirectionalNavigation('ArrowDown');
  }

  /**
   * Navega para a esquerda
   */
  navigateLeft() {
    this.handleDirectionalNavigation('ArrowLeft');
  }

  /**
   * Navega para a direita
   */
  navigateRight() {
    this.handleDirectionalNavigation('ArrowRight');
  }

  /**
   * Define foco em um elemento
   */
  setFocus(element, scrollIntoView = true) {
    if (!element || element === this.currentFocus) return;

    // Remover foco anterior
    if (this.currentFocus) {
      this.currentFocus.classList.remove(this.config.focusClass);
      this.currentFocus.classList.remove(this.config.focusVisibleClass);
      this.currentFocus.blur();
    }

    // Definir novo foco
    this.currentFocus = element;
    element.classList.add(this.config.focusClass);
    
    if (this.navigationMode === 'keyboard' || this.navigationMode === 'remote') {
      element.classList.add(this.config.focusVisibleClass);
    }

    element.focus();

    // Scroll para o elemento se necessário
    if (scrollIntoView && this.config.scrollIntoView) {
      element.scrollIntoView({
        behavior: this.config.scrollBehavior,
        block: 'nearest',
        inline: 'nearest'
      });
    }

    // Adicionar ao histórico
    this.navigationHistory.push(element);
    if (this.navigationHistory.length > 50) {
      this.navigationHistory.shift();
    }

    this.emit('focus-change', { element, previousElement: this.currentFocus });
  }

  /**
   * Ativa o elemento com foco atual
   */
  activateCurrentFocus() {
    if (this.currentFocus) {
      this.activateElement(this.currentFocus);
    }
  }

  /**
   * Ativa um elemento
   */
  activateElement(element) {
    if (element.click) {
      element.click();
    } else if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
      element.focus();
    }

    this.emit('element-activated', { element });
  }

  /**
   * Encontra elemento focável mais próximo
   * @private
   */
  findFocusableElement(element) {
    while (element && element !== document.body) {
      if (this.focusableElements.includes(element)) {
        return element;
      }
      element = element.parentElement;
    }
    return null;
  }

  /**
   * Define modo de navegação
   */
  setNavigationMode(mode) {
    if (this.navigationMode === mode) return;

    this.navigationMode = mode;
    
    // Atualizar classes CSS baseadas no modo
    document.body.classList.remove('nav-mouse', 'nav-keyboard', 'nav-remote');
    document.body.classList.add(`nav-${mode}`);

    // Atualizar foco visual
    if (this.currentFocus) {
      if (mode === 'mouse') {
        this.currentFocus.classList.remove(this.config.focusVisibleClass);
      } else {
        this.currentFocus.classList.add(this.config.focusVisibleClass);
      }
    }

    this.emit('navigation-mode-change', { mode });
  }

  /**
   * Adiciona atalho de teclado
   */
  addShortcut(key, action, condition = null) {
    this.shortcuts.set(key, { action, condition });
  }

  /**
   * Remove atalho de teclado
   */
  removeShortcut(key) {
    this.shortcuts.delete(key);
  }

  /**
   * Manipuladores de atalhos padrão
   */
  handleEscape() {
    this.emit('escape');
  }

  toggleFullscreen() {
    this.emit('toggle-fullscreen');
  }

  focusSearch() {
    const searchInput = document.querySelector('input[type="search"], input[placeholder*="buscar" i], input[placeholder*="search" i]');
    if (searchInput) {
      this.setFocus(searchInput);
    }
  }

  goHome() {
    this.emit('go-home');
  }

  openSettings() {
    this.emit('open-settings');
  }

  quit() {
    this.emit('quit');
  }

  /**
   * Polling para gamepad
   * @private
   */
  startGamepadPolling() {
    if (this.gamepadInterval) return;

    this.gamepadInterval = setInterval(() => {
      const gamepads = navigator.getGamepads();
      for (let i = 0; i < gamepads.length; i++) {
        const gamepad = gamepads[i];
        if (gamepad) {
          this.handleGamepadInput(gamepad);
        }
      }
    }, 100);
  }

  stopGamepadPolling() {
    if (this.gamepadInterval) {
      clearInterval(this.gamepadInterval);
      this.gamepadInterval = null;
    }
  }

  /**
   * Manipula entrada do gamepad
   * @private
   */
  handleGamepadInput(gamepad) {
    // Implementar lógica do gamepad conforme necessário
    // Por exemplo, mapear botões para ações de navegação
  }

  /**
   * Adiciona listener de evento
   */
  on(event, callback) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(callback);
  }

  /**
   * Remove listener de evento
   */
  off(event, callback) {
    if (this.eventListeners.has(event)) {
      const listeners = this.eventListeners.get(event);
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }

  /**
   * Emite evento
   * @private
   */
  emit(event, data) {
    if (this.eventListeners.has(event)) {
      this.eventListeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('Erro no listener de evento:', error);
        }
      });
    }
  }

  /**
   * Obtém elemento com foco atual
   */
  getCurrentFocus() {
    return this.currentFocus;
  }

  /**
   * Obtém modo de navegação atual
   */
  getNavigationMode() {
    return this.navigationMode;
  }

  /**
   * Habilita/desabilita navegação por teclado
   */
  setKeyboardNavigation(enabled) {
    this.keyboardNavigation = enabled;
  }

  /**
   * Habilita/desabilita navegação por controle remoto
   */
  setRemoteNavigation(enabled) {
    this.remoteNavigation = enabled;
  }

  /**
   * Limpa recursos
   */
  destroy() {
    if (this.domObserver) {
      this.domObserver.disconnect();
    }

    if (this.gamepadInterval) {
      clearInterval(this.gamepadInterval);
    }

    this.eventListeners.clear();
    this.shortcuts.clear();
    this.focusableElements = [];
    this.currentFocus = null;
  }
}

// Instância singleton
const navigationService = new NavigationService();

export default navigationService;

