/**
 * Serviço para parsing e processamento de playlists M3U/M3U8
 * Suporta tanto playlists locais quanto URLs remotas
 */
class M3UService {
  constructor() {
    this.supportedExtensions = ['.m3u', '.m3u8'];
  }

  /**
   * Carrega e faz parse de uma playlist M3U/M3U8
   * @param {string} source - URL ou conteúdo da playlist
   * @returns {Promise<Object>} Dados parseados da playlist
   */
  async parsePlaylist(source) {
    try {
      let content;
      
      // Verificar se é URL ou conteúdo
      if (this.isUrl(source)) {
        content = await this.fetchPlaylist(source);
      } else {
        content = source;
      }

      const parsedData = this.parseM3UContent(content);
      return {
        success: true,
        data: parsedData,
        source: this.isUrl(source) ? source : 'local'
      };
    } catch (error) {
      console.error('Erro ao fazer parse da playlist:', error);
      throw new Error(`Erro ao processar playlist: ${error.message}`);
    }
  }

  /**
   * Baixa playlist de uma URL
   * @param {string} url - URL da playlist
   * @returns {Promise<string>} Conteúdo da playlist
   * @private
   */
  async fetchPlaylist(url) {
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const content = await response.text();
      
      if (!content.trim()) {
        throw new Error('Playlist vazia ou inválida');
      }

      return content;
    } catch (error) {
      throw new Error(`Erro ao baixar playlist: ${error.message}`);
    }
  }

  /**
   * Faz parse do conteúdo M3U
   * @param {string} content - Conteúdo da playlist
   * @returns {Object} Dados parseados
   * @private
   */
  parseM3UContent(content) {
    const lines = content.split('\n').map(line => line.trim()).filter(line => line);
    
    if (!lines[0] || !lines[0].startsWith('#EXTM3U')) {
      throw new Error('Formato de playlist inválido - cabeçalho #EXTM3U não encontrado');
    }

    const channels = [];
    const categories = new Set();
    let currentChannel = null;

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];

      if (line.startsWith('#EXTINF:')) {
        // Parse da linha EXTINF
        currentChannel = this.parseExtInfLine(line);
      } else if (line.startsWith('http') || line.startsWith('rtmp') || line.startsWith('rtsp')) {
        // URL do stream
        if (currentChannel) {
          currentChannel.url = line;
          currentChannel.id = this.generateChannelId(currentChannel);
          
          // Adicionar categoria ao set
          if (currentChannel.category) {
            categories.add(currentChannel.category);
          }
          
          channels.push(currentChannel);
          currentChannel = null;
        }
      } else if (line.startsWith('#EXTGRP:')) {
        // Categoria alternativa
        if (currentChannel) {
          currentChannel.category = line.replace('#EXTGRP:', '').trim();
        }
      }
    }

    // Organizar por categorias
    const categorizedChannels = this.organizeByCategories(channels);

    return {
      totalChannels: channels.length,
      categories: Array.from(categories).sort(),
      channels: channels,
      categorizedChannels: categorizedChannels,
      metadata: this.extractMetadata(content)
    };
  }

  /**
   * Faz parse da linha EXTINF
   * @param {string} line - Linha EXTINF
   * @returns {Object} Dados do canal
   * @private
   */
  parseExtInfLine(line) {
    // Formato: #EXTINF:duration,title
    // Pode conter atributos: #EXTINF:duration tvg-id="id" tvg-name="name" tvg-logo="logo" group-title="category",title
    
    const channel = {
      duration: -1,
      name: '',
      logo: '',
      category: 'Geral',
      tvgId: '',
      tvgName: '',
      language: '',
      country: '',
      type: 'live'
    };

    // Extrair duração
    const durationMatch = line.match(/#EXTINF:([^,\s]+)/);
    if (durationMatch) {
      channel.duration = parseFloat(durationMatch[1]) || -1;
    }

    // Extrair atributos
    const attributes = this.extractAttributes(line);
    
    if (attributes['tvg-id']) channel.tvgId = attributes['tvg-id'];
    if (attributes['tvg-name']) channel.tvgName = attributes['tvg-name'];
    if (attributes['tvg-logo']) channel.logo = attributes['tvg-logo'];
    if (attributes['group-title']) channel.category = attributes['group-title'];
    if (attributes['tvg-language']) channel.language = attributes['tvg-language'];
    if (attributes['tvg-country']) channel.country = attributes['tvg-country'];

    // Extrair nome do canal (após a última vírgula)
    const nameMatch = line.match(/,(.+)$/);
    if (nameMatch) {
      channel.name = nameMatch[1].trim();
    }

    // Determinar tipo baseado no nome ou categoria
    channel.type = this.determineContentType(channel.name, channel.category);

    return channel;
  }

  /**
   * Extrai atributos da linha EXTINF
   * @param {string} line - Linha EXTINF
   * @returns {Object} Atributos extraídos
   * @private
   */
  extractAttributes(line) {
    const attributes = {};
    const attributeRegex = /(\w+(?:-\w+)*)="([^"]+)"/g;
    let match;

    while ((match = attributeRegex.exec(line)) !== null) {
      attributes[match[1]] = match[2];
    }

    return attributes;
  }

  /**
   * Organiza canais por categorias
   * @param {Array} channels - Lista de canais
   * @returns {Object} Canais organizados por categoria
   * @private
   */
  organizeByCategories(channels) {
    const categorized = {};

    channels.forEach(channel => {
      const category = channel.category || 'Geral';
      
      if (!categorized[category]) {
        categorized[category] = [];
      }
      
      categorized[category].push(channel);
    });

    // Ordenar canais dentro de cada categoria
    Object.keys(categorized).forEach(category => {
      categorized[category].sort((a, b) => a.name.localeCompare(b.name));
    });

    return categorized;
  }

  /**
   * Determina o tipo de conteúdo baseado no nome e categoria
   * @param {string} name - Nome do canal/conteúdo
   * @param {string} category - Categoria
   * @returns {string} Tipo de conteúdo
   * @private
   */
  determineContentType(name, category) {
    const lowerName = name.toLowerCase();
    const lowerCategory = category.toLowerCase();

    // Verificar se é filme
    if (lowerCategory.includes('filme') || lowerCategory.includes('movie') || 
        lowerName.includes('filme') || lowerName.includes('movie')) {
      return 'vod';
    }

    // Verificar se é série
    if (lowerCategory.includes('série') || lowerCategory.includes('series') ||
        lowerName.includes('série') || lowerName.includes('series') ||
        lowerName.includes('temporada') || lowerName.includes('season')) {
      return 'series';
    }

    // Por padrão, considerar como TV ao vivo
    return 'live';
  }

  /**
   * Gera ID único para o canal
   * @param {Object} channel - Dados do canal
   * @returns {string} ID único
   * @private
   */
  generateChannelId(channel) {
    if (channel.tvgId) {
      return channel.tvgId;
    }
    
    // Gerar ID baseado no nome
    return channel.name
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '');
  }

  /**
   * Extrai metadados da playlist
   * @param {string} content - Conteúdo da playlist
   * @returns {Object} Metadados
   * @private
   */
  extractMetadata(content) {
    const metadata = {
      version: '1.0',
      generator: 'Unknown',
      url: '',
      refreshInterval: null
    };

    const lines = content.split('\n');
    
    for (const line of lines) {
      if (line.startsWith('#EXTM3U')) {
        // Extrair atributos do cabeçalho
        const attributes = this.extractAttributes(line);
        if (attributes.url) metadata.url = attributes.url;
        if (attributes.refresh) metadata.refreshInterval = parseInt(attributes.refresh);
      }
    }

    return metadata;
  }

  /**
   * Converte dados parseados para formato compatível com Xtream Codes
   * @param {Object} parsedData - Dados parseados da playlist M3U
   * @returns {Object} Dados no formato Xtream Codes
   */
  convertToXtreamFormat(parsedData) {
    const { channels, categories } = parsedData;

    // Criar categorias no formato Xtream
    const xtreamCategories = categories.map((category, index) => ({
      category_id: (index + 1).toString(),
      category_name: category,
      parent_id: 0
    }));

    // Criar mapa de categoria para ID
    const categoryMap = {};
    categories.forEach((category, index) => {
      categoryMap[category] = (index + 1).toString();
    });

    // Converter canais para formato Xtream
    const xtreamChannels = channels.map((channel, index) => ({
      num: index + 1,
      name: channel.name,
      stream_type: channel.type,
      stream_id: index + 1,
      stream_icon: channel.logo,
      epg_channel_id: channel.tvgId,
      added: new Date().toISOString(),
      category_name: channel.category,
      category_id: categoryMap[channel.category] || '1',
      tv_archive: 0,
      direct_source: channel.url,
      tv_archive_duration: 0,
      custom_sid: channel.id,
      is_adult: this.isAdultContent(channel.name, channel.category) ? '1' : '0'
    }));

    return {
      categories: xtreamCategories,
      channels: xtreamChannels,
      totalChannels: channels.length,
      source: 'M3U'
    };
  }

  /**
   * Verifica se o conteúdo é adulto
   * @param {string} name - Nome do conteúdo
   * @param {string} category - Categoria
   * @returns {boolean} Se é conteúdo adulto
   * @private
   */
  isAdultContent(name, category) {
    const adultKeywords = ['adult', 'xxx', '+18', 'adulto', 'erótico', 'sexy'];
    const lowerName = name.toLowerCase();
    const lowerCategory = category.toLowerCase();

    return adultKeywords.some(keyword => 
      lowerName.includes(keyword) || lowerCategory.includes(keyword)
    );
  }

  /**
   * Verifica se uma string é uma URL
   * @param {string} str - String para verificar
   * @returns {boolean} Se é uma URL
   * @private
   */
  isUrl(str) {
    try {
      new URL(str);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Valida formato de playlist M3U
   * @param {string} content - Conteúdo da playlist
   * @returns {Object} Resultado da validação
   */
  validatePlaylist(content) {
    const errors = [];
    const warnings = [];

    // Verificar cabeçalho
    if (!content.startsWith('#EXTM3U')) {
      errors.push('Cabeçalho #EXTM3U não encontrado');
    }

    // Verificar se há canais
    const extinfCount = (content.match(/#EXTINF:/g) || []).length;
    const urlCount = (content.match(/^https?:\/\//gm) || []).length;

    if (extinfCount === 0) {
      errors.push('Nenhum canal encontrado na playlist');
    }

    if (extinfCount !== urlCount) {
      warnings.push(`Número de canais (${extinfCount}) não corresponde ao número de URLs (${urlCount})`);
    }

    // Verificar URLs válidas
    const lines = content.split('\n');
    let invalidUrls = 0;
    
    for (const line of lines) {
      if (line.startsWith('http')) {
        try {
          new URL(line.trim());
        } catch {
          invalidUrls++;
        }
      }
    }

    if (invalidUrls > 0) {
      warnings.push(`${invalidUrls} URLs inválidas encontradas`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      stats: {
        totalChannels: extinfCount,
        validUrls: urlCount - invalidUrls,
        invalidUrls
      }
    };
  }

  /**
   * Gera playlist M3U a partir de dados
   * @param {Array} channels - Lista de canais
   * @param {Object} options - Opções de geração
   * @returns {string} Conteúdo da playlist M3U
   */
  generatePlaylist(channels, options = {}) {
    const { 
      includeLogos = true, 
      includeCategories = true,
      includeEpgIds = true 
    } = options;

    let content = '#EXTM3U\n\n';

    channels.forEach(channel => {
      let extinf = `#EXTINF:${channel.duration || -1}`;
      
      if (includeEpgIds && channel.tvgId) {
        extinf += ` tvg-id="${channel.tvgId}"`;
      }
      
      if (channel.tvgName) {
        extinf += ` tvg-name="${channel.tvgName}"`;
      }
      
      if (includeLogos && channel.logo) {
        extinf += ` tvg-logo="${channel.logo}"`;
      }
      
      if (includeCategories && channel.category) {
        extinf += ` group-title="${channel.category}"`;
      }
      
      extinf += `,${channel.name}\n`;
      
      content += extinf;
      content += `${channel.url}\n\n`;
    });

    return content;
  }

  /**
   * Filtra canais por critérios
   * @param {Array} channels - Lista de canais
   * @param {Object} filters - Filtros a aplicar
   * @returns {Array} Canais filtrados
   */
  filterChannels(channels, filters = {}) {
    let filtered = [...channels];

    if (filters.category) {
      filtered = filtered.filter(channel => 
        channel.category.toLowerCase().includes(filters.category.toLowerCase())
      );
    }

    if (filters.name) {
      filtered = filtered.filter(channel =>
        channel.name.toLowerCase().includes(filters.name.toLowerCase())
      );
    }

    if (filters.type) {
      filtered = filtered.filter(channel => channel.type === filters.type);
    }

    if (filters.language) {
      filtered = filtered.filter(channel =>
        channel.language && channel.language.toLowerCase() === filters.language.toLowerCase()
      );
    }

    if (filters.country) {
      filtered = filtered.filter(channel =>
        channel.country && channel.country.toLowerCase() === filters.country.toLowerCase()
      );
    }

    return filtered;
  }
}

// Instância singleton
const m3uService = new M3UService();

export default m3uService;

