import xtreamApi from './xtreamApi';
import databaseService from './databaseService';

/**
 * Serviço de autenticação com suporte a múltiplos métodos
 * Gerencia login via credenciais, QR Code e persistência segura
 */
class AuthService {
  constructor() {
    this.currentUser = null;
    this.sessionToken = null;
    this.loginMethod = null;
    this.isAuthenticated = false;
  }

  /**
   * Autentica usuário via credenciais Xtream Codes
   * @param {Object} credentials - Credenciais de login
   * @returns {Promise<Object>} Resultado da autenticação
   */
  async loginWithCredentials(credentials) {
    const { serverUrl, username, password } = credentials;

    try {
      // Validar credenciais
      this.validateCredentials(credentials);

      // Testar conectividade primeiro
      const isConnected = await xtreamApi.constructor.testConnection(serverUrl);
      if (!isConnected) {
        throw new Error('Não foi possível conectar ao servidor. Verifique a URL.');
      }

      // Configurar e autenticar com Xtream API
      xtreamApi.setCredentials(serverUrl, username, password);
      const authResult = await xtreamApi.authenticate();

      if (authResult.success) {
        // Gerar token de sessão
        this.sessionToken = this.generateSessionToken();
        
        // Configurar usuário atual
        this.currentUser = {
          username,
          serverUrl,
          userInfo: authResult.userInfo,
          serverInfo: authResult.serverInfo,
          loginMethod: 'credentials',
          loginTime: new Date().toISOString()
        };

        this.loginMethod = 'credentials';
        this.isAuthenticated = true;

        // Salvar sessão no banco de dados
        await this.saveSession();

        return {
          success: true,
          user: this.currentUser,
          sessionToken: this.sessionToken
        };
      } else {
        throw new Error('Falha na autenticação com o servidor');
      }
    } catch (error) {
      this.clearSession();
      throw error;
    }
  }

  /**
   * Autentica usuário via QR Code
   * @param {string} qrData - Dados do QR Code
   * @returns {Promise<Object>} Resultado da autenticação
   */
  async loginWithQRCode(qrData) {
    try {
      // Parse dos dados do QR Code
      const qrInfo = this.parseQRCode(qrData);
      
      if (!qrInfo.serverUrl || !qrInfo.credentials) {
        throw new Error('QR Code inválido ou incompleto');
      }

      // Usar credenciais do QR Code para autenticar
      const credentials = {
        serverUrl: qrInfo.serverUrl,
        username: qrInfo.credentials.username,
        password: qrInfo.credentials.password
      };

      const result = await this.loginWithCredentials(credentials);
      
      if (result.success) {
        // Atualizar método de login
        this.currentUser.loginMethod = 'qrcode';
        this.loginMethod = 'qrcode';
        
        // Atualizar sessão
        await this.saveSession();
        
        return {
          ...result,
          loginMethod: 'qrcode'
        };
      }

      return result;
    } catch (error) {
      throw new Error(`Erro no login via QR Code: ${error.message}`);
    }
  }

  /**
   * Autentica usuário via MAC Address (se suportado pelo servidor)
   * @param {string} macAddress - Endereço MAC
   * @param {string} serverUrl - URL do servidor
   * @returns {Promise<Object>} Resultado da autenticação
   */
  async loginWithMAC(macAddress, serverUrl) {
    try {
      // Normalizar MAC address
      const normalizedMAC = macAddress.replace(/[:-]/g, '').toUpperCase();
      
      if (normalizedMAC.length !== 12) {
        throw new Error('Endereço MAC inválido');
      }

      // Tentar autenticar usando MAC como username e password
      const credentials = {
        serverUrl,
        username: normalizedMAC,
        password: normalizedMAC
      };

      const result = await this.loginWithCredentials(credentials);
      
      if (result.success) {
        // Atualizar método de login
        this.currentUser.loginMethod = 'mac';
        this.currentUser.macAddress = macAddress;
        this.loginMethod = 'mac';
        
        // Atualizar sessão
        await this.saveSession();
        
        return {
          ...result,
          loginMethod: 'mac'
        };
      }

      return result;
    } catch (error) {
      throw new Error(`Erro no login via MAC: ${error.message}`);
    }
  }

  /**
   * Restaura sessão salva
   * @returns {Promise<boolean>} Sucesso na restauração
   */
  async restoreSession() {
    try {
      const savedSession = await databaseService.getSession();
      
      if (!savedSession) {
        return false;
      }

      // Verificar se a sessão não expirou
      const sessionAge = Date.now() - new Date(savedSession.loginTime).getTime();
      const maxAge = 24 * 60 * 60 * 1000; // 24 horas
      
      if (sessionAge > maxAge) {
        await this.clearSession();
        return false;
      }

      // Restaurar dados da sessão
      this.currentUser = savedSession.user;
      this.sessionToken = savedSession.sessionToken;
      this.loginMethod = savedSession.loginMethod;
      this.isAuthenticated = true;

      // Reconfigurar Xtream API
      if (this.currentUser.serverUrl && this.currentUser.username) {
        xtreamApi.setCredentials(
          this.currentUser.serverUrl,
          this.currentUser.username,
          savedSession.password || ''
        );
        
        // Tentar reautenticar para validar credenciais
        try {
          await xtreamApi.authenticate();
        } catch (error) {
          // Se falhar, limpar sessão
          await this.clearSession();
          return false;
        }
      }

      return true;
    } catch (error) {
      console.error('Erro ao restaurar sessão:', error);
      return false;
    }
  }

  /**
   * Salva sessão atual no banco de dados
   * @private
   */
  async saveSession() {
    if (!this.isAuthenticated || !this.currentUser) {
      return;
    }

    try {
      const sessionData = {
        user: this.currentUser,
        sessionToken: this.sessionToken,
        loginMethod: this.loginMethod,
        password: xtreamApi.password, // Salvar para reautenticação
        savedAt: new Date().toISOString()
      };

      await databaseService.saveSession(sessionData);
    } catch (error) {
      console.error('Erro ao salvar sessão:', error);
    }
  }

  /**
   * Limpa sessão atual
   */
  async clearSession() {
    this.currentUser = null;
    this.sessionToken = null;
    this.loginMethod = null;
    this.isAuthenticated = false;
    
    // Limpar Xtream API
    xtreamApi.logout();
    
    // Limpar do banco de dados
    try {
      await databaseService.clearSession();
    } catch (error) {
      console.error('Erro ao limpar sessão:', error);
    }
  }

  /**
   * Faz logout do usuário
   */
  async logout() {
    await this.clearSession();
  }

  /**
   * Verifica se o usuário está autenticado
   * @returns {boolean} Status de autenticação
   */
  isAuth() {
    return this.isAuthenticated && this.currentUser && this.sessionToken;
  }

  /**
   * Obtém informações do usuário atual
   * @returns {Object|null} Dados do usuário
   */
  getCurrentUser() {
    return this.currentUser;
  }

  /**
   * Obtém token da sessão atual
   * @returns {string|null} Token da sessão
   */
  getSessionToken() {
    return this.sessionToken;
  }

  /**
   * Obtém método de login usado
   * @returns {string|null} Método de login
   */
  getLoginMethod() {
    return this.loginMethod;
  }

  /**
   * Valida credenciais de login
   * @param {Object} credentials - Credenciais para validar
   * @private
   */
  validateCredentials(credentials) {
    const { serverUrl, username, password } = credentials;

    if (!serverUrl || !serverUrl.trim()) {
      throw new Error('URL do servidor é obrigatória');
    }

    if (!username || !username.trim()) {
      throw new Error('Nome de usuário é obrigatório');
    }

    if (!password || !password.trim()) {
      throw new Error('Senha é obrigatória');
    }

    // Validar formato da URL
    try {
      new URL(serverUrl);
    } catch {
      throw new Error('URL do servidor inválida');
    }
  }

  /**
   * Gera token de sessão único
   * @returns {string} Token da sessão
   * @private
   */
  generateSessionToken() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2);
    return `${timestamp}-${random}`;
  }

  /**
   * Faz parse dos dados do QR Code
   * @param {string} qrData - Dados do QR Code
   * @returns {Object} Dados parseados
   * @private
   */
  parseQRCode(qrData) {
    try {
      const data = JSON.parse(qrData);
      
      // Validar estrutura do QR Code
      if (!data.serverUrl || !data.credentials) {
        throw new Error('Estrutura do QR Code inválida');
      }

      return data;
    } catch (error) {
      throw new Error('QR Code inválido ou corrompido');
    }
  }

  /**
   * Gera QR Code para login
   * @param {Object} credentials - Credenciais para incluir no QR
   * @returns {string} Dados do QR Code
   */
  generateQRCode(credentials) {
    const qrData = {
      app: 'IPTV Player Pro',
      version: '1.0.0',
      serverUrl: credentials.serverUrl,
      credentials: {
        username: credentials.username,
        password: credentials.password
      },
      timestamp: Date.now(),
      expiresAt: Date.now() + (5 * 60 * 1000) // 5 minutos
    };

    return JSON.stringify(qrData);
  }

  /**
   * Verifica se as credenciais ainda são válidas
   * @returns {Promise<boolean>} Status da validade
   */
  async validateCurrentSession() {
    if (!this.isAuth()) {
      return false;
    }

    try {
      // Tentar fazer uma requisição simples para validar
      await xtreamApi.authenticate();
      return true;
    } catch (error) {
      // Se falhar, limpar sessão
      await this.clearSession();
      return false;
    }
  }

  /**
   * Atualiza informações do usuário
   * @returns {Promise<Object>} Informações atualizadas
   */
  async refreshUserInfo() {
    if (!this.isAuth()) {
      throw new Error('Usuário não autenticado');
    }

    try {
      const authResult = await xtreamApi.authenticate();
      
      if (authResult.success) {
        // Atualizar informações do usuário
        this.currentUser.userInfo = authResult.userInfo;
        this.currentUser.serverInfo = authResult.serverInfo;
        this.currentUser.lastRefresh = new Date().toISOString();
        
        // Salvar sessão atualizada
        await this.saveSession();
        
        return this.currentUser;
      } else {
        throw new Error('Falha ao atualizar informações do usuário');
      }
    } catch (error) {
      throw new Error(`Erro ao atualizar usuário: ${error.message}`);
    }
  }
}

// Instância singleton
const authService = new AuthService();

export default authService;

