const { contextBridge, ipcRenderer } = require('electron');

// Expor APIs seguras para o renderer process
contextBridge.exposeInMainWorld('electronAPI', {
  // Informações do aplicativo
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  
  // Diálogos do sistema
  showMessageBox: (options) => ipcRenderer.invoke('show-message-box', options),
  showOpenDialog: (options) => ipcRenderer.invoke('show-open-dialog', options),
  showSaveDialog: (options) => ipcRenderer.invoke('show-save-dialog', options),
  
  // Controles da janela
  windowMinimize: () => ipcRenderer.invoke('window-minimize'),
  windowMaximize: () => ipcRenderer.invoke('window-maximize'),
  windowClose: () => ipcRenderer.invoke('window-close'),
  windowFullscreen: () => ipcRenderer.invoke('window-fullscreen'),
  
  // Eventos do menu
  onOpenSettings: (callback) => ipcRenderer.on('open-settings', callback),
  onPlayerToggle: (callback) => ipcRenderer.on('player-toggle', callback),
  onPlayerStop: (callback) => ipcRenderer.on('player-stop', callback),
  onPlayerVolumeUp: (callback) => ipcRenderer.on('player-volume-up', callback),
  onPlayerVolumeDown: (callback) => ipcRenderer.on('player-volume-down', callback),
  
  // Remover listeners
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel),
});

// Expor APIs para SQLite (será implementado posteriormente)
contextBridge.exposeInMainWorld('databaseAPI', {
  // Placeholder para APIs do banco de dados
  // Será implementado quando integrarmos o SQLite
});

// Expor APIs para o player de vídeo (será implementado posteriormente)
contextBridge.exposeInMainWorld('playerAPI', {
  // Placeholder para APIs do player
  // Será implementado quando integrarmos o libVLC
});

